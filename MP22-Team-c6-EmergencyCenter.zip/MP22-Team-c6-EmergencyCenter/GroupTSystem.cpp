#include "EmergencyCenter.h"

int main() {
    auto * emergencyCenter = EmergencyCenter::getInstance();

    std::shared_ptr<Space> groupT = std::make_shared<Space>("GroupT", "Building");
    std::shared_ptr<Space> module = std::make_shared<Space>("Module10", "Module");
    std::shared_ptr<Space> alma = std::make_shared<Space>("Alma Kitchen 1.03", "Room");
    std::shared_ptr<Space> chem_lab = std::make_shared<Space>("Chemistry Lab 5.01", "Room");
    std::shared_ptr<Space> electronics_01 = std::make_shared<Space>("Electronics Lab 10.01", "Room");
    std::shared_ptr<Space> electronics_02 = std::make_shared<Space>("Electronics Lab 10.02", "Room");

    std::shared_ptr<ToxicGasSensor> gas_Nox = std::make_shared<ToxicGasSensor>("Nox Gas sensor", "Gas Sensor", "GasSense", false, 0);
    std::shared_ptr<ToxicGasSensor> co_gas = std::make_shared<ToxicGasSensor>("CO Gas Sensor", "Toxic Gas Sensor", "GasSense", false, 0);

    std::shared_ptr<SmokeSensor> sensor_solution_smoke_electronics = std::make_shared<SmokeSensor>("Smoke Sensor electronics", "Smoke Sensor", "Sensor Solution", false, 0);
    std::shared_ptr<SmokeSensor> sensor_solution_smoke_chemlab = std::make_shared<SmokeSensor>("Smoke Sensor chemistry", "Smoke Sensor", "Sensor Solution", false, 0);

    std::shared_ptr<SmokeSensor> kitchen_safe = std::make_shared<SmokeSensor>("Kitchen safe Smoke Sensor", "Smoke Sensor", "Kitchen Safe", false, 0);

    std::shared_ptr<MotionSensor> got_you_01 = std::make_shared<MotionSensor>("Motion Sensor in lab 01", "Motion Sensor", "Got You", false, 22, 7, 10);
    std::shared_ptr<MotionSensor> got_you_02 = std::make_shared<MotionSensor>("Motion Sensor in lab 02", "Motion Sensor", "Got You", false, 22, 7, 10);

    std::shared_ptr<MotionSensor> big_brother = std::make_shared<MotionSensor>("Big Brother Motion Sensor", "Motion Sensor", "Big Brother is watching you", false, 0, 24, 10);

    std::shared_ptr<Actuator> building_alarm = std::make_shared<Actuator>("Building Alarm", "Alarm");
    std::shared_ptr<Actuator> local_alarm  = std::make_shared<Actuator>("Local Alarm", "Alarm");
    std::shared_ptr<Actuator> room_alarm = std::make_shared<Actuator>("Chemistry Lab room alarm", "Alarm");
    std::shared_ptr<Actuator> automatic_extinction = std::make_shared<Actuator>("Automatic extinction system", "Extinction system");

    std::shared_ptr<Message> message_KUL = std::make_shared<Message>("message", "KULeuven Central Dispatch");
    std::shared_ptr<Message> send_mail = std::make_shared<Message>("E-Mail", "donny.dhondt@kuleuven.be");
    std::shared_ptr<Message> sms = std::make_shared<Message>("SMS", "Gert Vanloock");
    std::shared_ptr<Message> message_alarm = std::make_shared<Message>("message", "Alarm dispatch");
    std::shared_ptr<Message> warning_police = std::make_shared<Message>("warning", "police");
    std::shared_ptr<Message> warning_security = std::make_shared<Message>("warning", "KUL security");



    emergencyCenter -> addChildComponent(groupT, 0);

    emergencyCenter ->addChildComponent(module, groupT);

    emergencyCenter ->addChildComponent(alma, groupT);
    emergencyCenter ->addChildComponent(chem_lab, groupT);


    emergencyCenter ->addChildComponent(electronics_01, module);
    emergencyCenter ->addChildComponent(electronics_02, module);

    emergencyCenter ->addChildComponent(sensor_solution_smoke_electronics, electronics_01);
    emergencyCenter ->addChildComponent(sensor_solution_smoke_chemlab, chem_lab);

    emergencyCenter -> addChildComponent(gas_Nox, chem_lab);

    emergencyCenter ->addChildComponent(got_you_01, electronics_01);
    emergencyCenter ->addChildComponent(got_you_02, electronics_02);

    emergencyCenter ->addChildComponent(co_gas, alma);
    emergencyCenter ->addChildComponent(big_brother, alma);
    emergencyCenter ->addChildComponent(kitchen_safe, alma);


    gas_Nox ->addSensorResponse(room_alarm);
    gas_Nox ->addSensorResponse(send_mail);

    sensor_solution_smoke_chemlab -> addSensorResponse(building_alarm);
    sensor_solution_smoke_chemlab -> addSensorResponse(message_KUL);

    sensor_solution_smoke_electronics ->addSensorResponse(building_alarm);
    sensor_solution_smoke_electronics ->addSensorResponse(message_KUL);
    got_you_01 ->addSensorResponse(sms);

    got_you_02 -> addSensorResponse(sms);

    kitchen_safe -> addSensorResponse(automatic_extinction);
    kitchen_safe ->addSensorResponse(message_alarm);

    co_gas ->addSensorResponse(local_alarm);

    big_brother->addSensorResponse(warning_security);
    big_brother->addSensorResponse(warning_police);



    ++(*sensor_solution_smoke_chemlab);
    sensor_solution_smoke_chemlab->trigger();
    ++(*chem_lab);
    chem_lab->trigger();

    groupT->trigger();
    ++(*groupT);
    groupT->trigger();

    std::cout << "-------------------------------------------------" << std::endl;
    emergencyCenter->printSensorsByVendor();

    delete emergencyCenter;

    return 0;
}
