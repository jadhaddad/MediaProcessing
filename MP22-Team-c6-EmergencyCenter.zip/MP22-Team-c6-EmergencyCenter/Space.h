#ifndef SPACE_H
#define SPACE_H

#include <vector>
#include <string>
#include <memory>
#include <iostream>

#include "Component.h"

class Space : public Component {

private:
    std::vector<std::shared_ptr<Component>> children;

public:
    Space(std::string name, std::string type);

    ~Space();

    bool addChild(std::shared_ptr<Component> component);

    std::string showDetails() const override;

    void trigger() const override;

    void setActive(bool active) override;

    bool operator== (const Space &space) const;
};

#endif
