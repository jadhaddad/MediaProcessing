#include <string>
#include <iostream>
#include <sstream>
#include "Actuator.h"

Actuator::Actuator(const std::string & name, const std::string & type)
    : Responder(name), status{false} , type{type} { }

void Actuator::call() {
    status = true;
    std::cout << showDetails();
}


const std::string &Actuator::getType() const {
    return type;
}

void Actuator::deactivate() {
    status = false;
    std::cout << showDetails();
}

std::string Actuator::getStatus() const {
    return (status)? "on" : "off";
}

std::string Actuator::showDetails() const {
    std::stringstream result;
    result << getName() << ", actuator of type " << type << " is turned " << getStatus() << std::endl;
    return result.str();
}
