#include "ToxicGasSensor.h"
#include <iostream>
#include <sstream>

ToxicGasSensor::ToxicGasSensor(std::string name,std::string type,std::string vendor, bool permanent, long gasConcentration)
    : Sensor(name, type, vendor, permanent), gasConcentrationLimit{gasConcentration}
{
}


std::string ToxicGasSensor::showDetails() const {
    // change the active message later
    std::stringstream result;
    result << "The toxic gas sensor " << getName() <<
            " of the type " << getType() <<
            " with sensorID " << getSensorID() <<
              " from " << getVendor() <<
            getAlphaActive() << std::endl << printResponders();
    
    return result.str();
}


