#include <sstream>
#include <algorithm>

#include "Space.h"
#include "Sensor.h"

Space::Space(std::string name, std::string type): Component(name, type)
{

}

Space::~Space()
{
    children.clear();
}

bool Space::addChild(std::shared_ptr<Component> component) {
    for (const auto &compare : children) {
		if (component == compare) {
			std::cout << "Child already added." << std::endl;
			return false;
		}
	}

	children.push_back(component);
	return true;
}

/**
 * compare sensors by ID in alphabetical order
*/
bool compareSensorByName(const std::shared_ptr<Sensor> sensor1, const std::shared_ptr<Sensor> sensor2) {
    return sensor1->getName().compare(sensor2->getName()) < 0;
}

std::string Space::showDetails() const {

	std::stringstream result;
    result << "-------------Space of name " << getName() << ", type " << getType() << "-------------" << std::endl
           << "Sensors:" << std::endl;

    std::vector<std::shared_ptr<Sensor>> sensors;

    for (const auto &child : children) {
        if (auto sensor = std::dynamic_pointer_cast<Sensor>(child))
            sensors.push_back(sensor);
    }

    std::sort(sensors.begin(), sensors.end(), compareSensorByName);

    for (const auto &sensor : sensors) {
        result << *sensor;
    }

    result << "------------------------------------------------------------------" << std::endl;
	return result.str();
}

void Space::trigger() const {
    for (const auto &child : children) {
		child->trigger();
    }
}

void Space::setActive(bool active) {
	for (auto child : children) {
		child->setActive(active);
	}
}

bool Space::operator==(const Space &space) const {
	return name == space.getName()
		&& type == space.getType();
}
