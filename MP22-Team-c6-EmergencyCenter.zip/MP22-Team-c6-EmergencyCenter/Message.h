#ifndef MESSAGE_H
#define MESSAGE_H

#include <string>
#include "Responder.h"

class Message : public Responder {

public:
    std::string contactDetails;

    Message(const std::string & name, const std::string & contactDetails);

     const std::string &getcontactDetails() const;

    void call() override;

    std::string showDetails() const override;
};

#endif
