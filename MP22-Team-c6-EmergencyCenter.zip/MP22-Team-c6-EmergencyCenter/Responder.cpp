#include "Responder.h"

Responder::Responder(const std::string & name) : name{name} {
	
}

std::string Responder::getName() const {
	return name;
}