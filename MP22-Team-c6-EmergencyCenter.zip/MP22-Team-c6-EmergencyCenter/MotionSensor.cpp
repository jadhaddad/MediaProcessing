#include "MotionSensor.h"
#include <iostream>
#include <sstream>

MotionSensor::MotionSensor(std::string name, std::string type, std::string vendor, bool permanent, int onTime, int offTime, int range):
    Sensor{name, type, vendor, permanent}, onTime{onTime}, offTime{offTime}, range{range}
{
}

std::string MotionSensor::showDetails() const {
    std::stringstream result;
    result << "The Motion sensor " << getName() <<
            " of the type " << getType() <<
            " with sensorID " << getSensorID() <<
             " from " << getVendor() <<
             getAlphaActive() << std::endl << printResponders();
    return result.str();
}

