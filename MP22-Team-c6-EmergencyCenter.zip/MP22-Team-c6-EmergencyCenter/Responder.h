#ifndef RESPONDER_H
#define RESPONDER_H

#include <string>

class Responder {

private:
    std::string name;

public:
	Responder(const std::string & name);

    virtual void call() = 0;

    std::string getName() const;

    virtual std::string showDetails() const = 0;
};

#endif
