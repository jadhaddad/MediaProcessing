#ifndef COMPONENT_H
#define COMPONENT_H
#include <string>
#include <memory>

class Sensor;
class Space;

class Component {

protected:
    std::string name;
    std::string type;

public:
    Component(std::string name, std::string type);

    virtual ~Component() = 0;

    const std::string getName() const;

    void setName(std::string name);

    const std::string getType() const;

    void setType(std::string type);

    virtual std::string showDetails() const = 0;

    virtual void trigger() const = 0;

	virtual void setActive(bool active) = 0;

    virtual Component & operator++();

    virtual Component & operator--();
};

bool operator== (const std::shared_ptr<Component> & comp1, const std::shared_ptr<Component> & comp2);

std::ostream & operator<<(std::ostream & os, const Component &component);

#endif
