#include "Alarm.h"
#include <string>
#include <iostream>
#include <sstream>

Alarm::Alarm(const std::string & name) : Responder(name), status{false} {
    
}

void Alarm::call() {
        status = true;
        std::cout << showDetails();
}

std::string Alarm::getStatus() const {
        return (status)? "on" : "off";
}

void Alarm::deactivate() {
        status = false;
        std::cout << showDetails();
}

std::string Alarm::showDetails() const {
        std::stringstream result;
        result << getName() << ", an alarm is turned " << getStatus() << std::endl;
        return result.str();
}
