#ifndef MOTIONSENSOR_H
#define MOTIONSENSOR_H

#include <string>
#include "Sensor.h"

class MotionSensor : public Sensor {

private:
    int onTime;
    int offTime;
	int range;

public:
    MotionSensor(std::string name, std::string type, std::string vendor, bool permanent, int onTime, int offTime, int range);

    std::string showDetails() const override;

};

#endif
