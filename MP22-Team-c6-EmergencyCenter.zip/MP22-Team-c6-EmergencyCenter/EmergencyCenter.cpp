#include <iostream>
#include <algorithm>
#include <string>

#include "EmergencyCenter.h"
#include "Space.h"
#include "Sensor.h"

EmergencyCenter * EmergencyCenter::instance = 0;

EmergencyCenter::EmergencyCenter() {
    components.reserve(20);
}

EmergencyCenter::~EmergencyCenter() {
    components.clear();
}

EmergencyCenter * EmergencyCenter::getInstance() {
    if (instance == 0) {
        instance = new EmergencyCenter();
    }
    return instance;
}

/**
 * compare sensors by ID in ascending order
*/
bool compareSensorByID(const std::shared_ptr<Sensor> sensor1, const std::shared_ptr<Sensor> sensor2) {
    return sensor1->getSensorID() < sensor2->getSensorID();
}

/**
 * compare sensors by vendor, then by ID
*/
bool compareSensorByVendor(const std::shared_ptr<Sensor> sensor1, const std::shared_ptr<Sensor> sensor2) {
    int comparison = sensor1->getVendor().compare(sensor2->getVendor());
    if (comparison == 0)    // same vendor sort by ID
        return compareSensorByID(sensor1, sensor2);
    else                    // different vendor
        return comparison < 0;
}

void EmergencyCenter::printSensorsByVendor() const {
	std::vector<std::shared_ptr <Sensor>> sensors;

    for (const std::shared_ptr<Component> &component : components) {
        if (std::shared_ptr<Sensor> sensor = std::dynamic_pointer_cast<Sensor> (component)) {
            auto newSensor = sensor;    // new shared pointer
            sensors.push_back(newSensor);
        }
    }

    std::sort(sensors.begin(), sensors.end(), compareSensorByVendor);

    for (const std::shared_ptr<Sensor> &sensor : sensors) {
        std::cout << *(sensor.get());
    }

    // don't delete the objects pointed by the pointers
    sensors.clear();
}

void EmergencyCenter::printSensorsBySpace() const {
    for (const std::shared_ptr<Component> &component : components) {
        if (std::shared_ptr<Space> space = std::dynamic_pointer_cast<Space> (component)) {
            std::cout << *(space.get());
        }
    }
}

void EmergencyCenter::printSensorsByID() const {
    std::vector<std::shared_ptr <Sensor>> sensors;

    for (const std::shared_ptr<Component> &component : components) {
        if (std::shared_ptr<Sensor> sensor = std::dynamic_pointer_cast<Sensor> (component)) {
            auto newSensor = sensor;    // new shared pointer
            sensors.push_back(newSensor);
        }
    }

    std::sort(sensors.begin(), sensors.end(), compareSensorByID);

    for (const std::shared_ptr<Sensor> &sensor : sensors) {
        std::cout << *(sensor.get());
    }

    // don't delete the objects pointed by the pointers
    sensors.clear();
}

bool EmergencyCenter::addChildComponent(std::shared_ptr<Component> childComponent, std::shared_ptr<Component> parentComponent) {
    if (childComponent == 0) {
        std::cout << "Child component is null." << std::endl;
        return false;
    } else if (checkComponentInList(childComponent)) {
        std::cout << "Child component already added." << std::endl;
        return false;
    }
    
    if (parentComponent != 0) { // add to a parent
        if (!checkComponentInList(parentComponent)) {
            std::cout << "Parent component not added yet." << std::endl;
            return false;
        } else if (std::shared_ptr<Space> space = std::dynamic_pointer_cast<Space> (parentComponent)) {
            if (space->addChild(childComponent) == false) {
                std::cout << "Unable to add to parent component." << std::endl;
                return false;
            }
        } else {
            std::cout << "Cannot add a child component to a sensor." << std::endl;
            return false;
        }
    }

    components.push_back(childComponent);
    return true;
}

bool EmergencyCenter::checkComponentInList(const std::shared_ptr<Component> component) {
    for (const std::shared_ptr<Component> &compare_ptr : components) {
        if (compare_ptr.get() == component.get()) return true;
    }
    return false;
}

void EmergencyCenter::testSensorsInComponent(const std::shared_ptr<Component> component) const {
    component->trigger();
}
