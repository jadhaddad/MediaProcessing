
#include "EmergencyCenter.h"
#include "Sensor.h"
#include "ToxicGasSensor.h"
#include "MotionSensor.h"
#include "SmokeSensor.h"
#include <memory>
#include "Space.h"
#include "Component.h"
#include "Actuator.h"
#include "Message.h"

//scenreio2
int main(){

    auto * emergencyCenter = EmergencyCenter::getInstance();

    std::shared_ptr<Space> neighborhood = std::make_shared<Space>("Neighborhood", "Residential Area");

    std::shared_ptr<Space> johnHouse = std::make_shared<Space>("John's House", "House");
    std::shared_ptr<Space> shed = std::make_shared<Space>("John's Shed", "Room");
    std::shared_ptr<Space> kitchen = std::make_shared<Space>("John's kitchen", "Room");

    std::shared_ptr<Space> daveHouse = std::make_shared<Space>("Dave's house", "House");
    std::shared_ptr<Space> livingRoom = std::make_shared<Space>("Dave's LivingRoom", "Room");

    std::shared_ptr<Space> katelineHouse = std::make_shared<Space>("Mad scientist's house", "House");
    std::shared_ptr<Space> lab = std::make_shared<Space>("Mad scientist's lab", "Room");

    std::shared_ptr<SmokeSensor> smoke_shed = std::make_shared<SmokeSensor>("Smoke Sensor John's shed", "Smoke Sensor", "Smokey", false, 0);
    std::shared_ptr<SmokeSensor> smoke_kitchen = std::make_shared<SmokeSensor>("Smoke Sensor John's kitchen", "Smoke Sensor", "Smokey", false, 0);
    std::shared_ptr<SmokeSensor> smoke_living = std::make_shared<SmokeSensor>("Smoke Sensor Dave's living", "Smoke Sensor", "BurningInc", false, 0);

    std::shared_ptr<ToxicGasSensor> toxicgas_living = std::make_shared<ToxicGasSensor>("Co Gas sensor living", "Gas Sensor", "Breathlabs", false, 0);
    std::shared_ptr<ToxicGasSensor> toxicgas_lab = std::make_shared<ToxicGasSensor>("toxic Gas sensor lab", "Gas Sensor", "TN2S", false, 0);



    std::shared_ptr<MotionSensor> icancu_shed = std::make_shared<MotionSensor>("Motion Sensor in john's shed", "Motion Sensor", "IcanCU", false, 22, 7, 10);
    std::shared_ptr<MotionSensor> icancu_kitchen = std::make_shared<MotionSensor>("Motion Sensor in john's kitchen", "Motion Sensor", "IcanCU", false, 22, 7, 10);
    std::shared_ptr<MotionSensor> icancu_lab = std::make_shared<MotionSensor>("Motion Sensor in mad scientist's lab", "Motion Sensor", "IcanCU", false, 4, 9, 10);

    std::shared_ptr<Actuator> johnhouse_alarm = std::make_shared<Actuator>("John House Alarm", "Alarm");
    std::shared_ptr<Actuator> davehouse_alarm = std::make_shared<Actuator>("Dave House Alarm", "Alarm");
    std::shared_ptr<Actuator> katelinhouse_alarm = std::make_shared<Actuator>("Katelin House Alarm", "Alarm");

    std::shared_ptr<Message> fireDepartment = std::make_shared<Message>("message", "Fire Department");
    std::shared_ptr<Message> email_vick = std::make_shared<Message>("email", "vicky.cooke@gmail.com");
    std::shared_ptr<Message> email_katelin = std::make_shared<Message>("email", "katelin@gmail.com");

    std::shared_ptr<Actuator> sprinkle = std::make_shared<Actuator>("Start Sprinkle system", "Sprinkle system");
    std::shared_ptr<Actuator> turnon_lights = std::make_shared<Actuator>("Turn on light", "light system");
    std::shared_ptr<Actuator> ac_on = std::make_shared<Actuator>("Trun AC ON", "AC system");

     emergencyCenter -> addChildComponent(neighborhood, 0);
     emergencyCenter -> addChildComponent(johnHouse, neighborhood);
     emergencyCenter -> addChildComponent(daveHouse, neighborhood);
     emergencyCenter -> addChildComponent(katelineHouse, neighborhood);

     emergencyCenter -> addChildComponent(shed, johnHouse);
     emergencyCenter -> addChildComponent(kitchen, johnHouse);
     emergencyCenter -> addChildComponent(livingRoom, daveHouse);
     emergencyCenter -> addChildComponent(lab, katelineHouse);

     emergencyCenter -> addChildComponent(smoke_shed, shed);
     emergencyCenter -> addChildComponent(icancu_shed, shed);

     emergencyCenter -> addChildComponent(smoke_kitchen, kitchen);
     emergencyCenter -> addChildComponent(icancu_kitchen, kitchen);

     emergencyCenter -> addChildComponent(smoke_living, livingRoom);
     emergencyCenter -> addChildComponent(toxicgas_living, livingRoom);

     emergencyCenter -> addChildComponent(icancu_lab, lab);
     emergencyCenter -> addChildComponent(toxicgas_lab, lab);

     smoke_shed ->addSensorResponse(johnhouse_alarm);
     smoke_shed ->addSensorResponse(fireDepartment);

     icancu_shed ->addSensorResponse(turnon_lights);
     icancu_shed ->addSensorResponse(ac_on);

     smoke_kitchen -> addSensorResponse(johnhouse_alarm);
     smoke_kitchen ->addSensorResponse(fireDepartment);

     icancu_kitchen ->addSensorResponse(email_vick);

     smoke_living ->addSensorResponse(fireDepartment);
     smoke_living ->addSensorResponse(sprinkle);

     toxicgas_living->addSensorResponse(davehouse_alarm);

     icancu_lab ->addSensorResponse(email_katelin);

     toxicgas_lab ->addSensorResponse(davehouse_alarm);
     toxicgas_lab ->addSensorResponse(johnhouse_alarm);
     toxicgas_lab ->addSensorResponse(katelinhouse_alarm);

    //activating and triggering smoke sensor in john's shed
     ++(*smoke_shed);
     smoke_shed->trigger();

     //activating and triggering all sensor in john's house
     ++(*johnHouse);
     johnHouse->trigger();

     //activating and triggering all sensor in dave's house

     ++(*daveHouse);
     daveHouse->trigger();

     //triggering all sensor in all neighborhood
     neighborhood ->trigger();

     //activating and triggering sensor in all neighborhood

     ++(*neighborhood);
     neighborhood->trigger();

     //activating and triggering smoke sensor in mad scientists house

     katelineHouse->trigger();

    //printing sensor by id

     emergencyCenter->printSensorsByID();

     delete emergencyCenter;

     return 0;


}

