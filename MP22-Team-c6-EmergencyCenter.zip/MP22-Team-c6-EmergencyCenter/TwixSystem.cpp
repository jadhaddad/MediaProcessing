#include "EmergencyCenter.h"

int main() {
    EmergencyCenter * emergencyCenter = EmergencyCenter::getInstance();

    // spaces
    std::shared_ptr<Space> twix = std::make_shared<Space> ("Twix", "Galaxy");

    std::shared_ptr<Space> x_AE_A_12= std::make_shared<Space> ("X AE A-12", "Planet");
    std::shared_ptr<Space> lv_426 = std::make_shared<Space> ("LV-426", "Planet");

    std::shared_ptr<Space> redstone = std::make_shared<Space> ("Redstone", "Supervolcano");
    std::shared_ptr<Space> orangestone = std::make_shared<Space> ("Orangestone", "Supervolcano");

    std::shared_ptr<Space> moon_unit = std::make_shared<Space> ("Moon Unit", "Site");
    std::shared_ptr<Space> dweezil = std::make_shared<Space> ("Dweezil", "Site");

    // sensors
    std::shared_ptr<MotionSensor> twix_motion = std::make_shared<MotionSensor> ("Motion Sensor Twix", "Motion Sensor", "Disney", true, 0, 24, 1000);

    std::shared_ptr<ToxicGasSensor> musk_kid_gas = std::make_shared<ToxicGasSensor> ("Sulphur Gas Sensor", "Toxic Gas Sensor", "Disney", false, 1000000000);

    std::shared_ptr<SmokeSensor> redstone_smoke = std::make_shared<SmokeSensor> ("Resdstone Smoke Sensor", "Smoke Sensor", "Disney", false, 1000);
    std::shared_ptr<SmokeSensor> orangestone_smoke = std::make_shared<SmokeSensor> ("Orangestone Smoke Sensor", "Smoke Sensor", "Disney", false, 1000);

    std::shared_ptr<ToxicGasSensor> oxygen_LV = std::make_shared<ToxicGasSensor> ("Oxygen Level", "Smoke Sensor", "Disney", false, 1200000000);
    std::shared_ptr<MotionSensor> motion_LV = std::make_shared<MotionSensor> ("Motion Sensor LV-426", "Motion Sensor", "Disney", true, 0, 24, 1000);

    std::shared_ptr<MotionSensor> motion_moon = std::make_shared<MotionSensor> ("Moon Unit Hatching Sensor", "Motion Sensor", "Disney", false, 20, 8, 10);
    std::shared_ptr<SmokeSensor> smoke_moon = std::make_shared<SmokeSensor> ("Moon Unit Smoke Sensor", "Smoke Sensor", "Disney", false, 10);

    std::shared_ptr<MotionSensor> motion_dweezil = std::make_shared<MotionSensor> ("Dweezil Hatching Sensor", "Motion Sensor", "Disney", false, 20, 8, 10);
    std::shared_ptr<SmokeSensor> smoke_dweezil = std::make_shared<SmokeSensor> ("Dweezil Smoke Sensor", "Smoke Sensor", "Disney", false, 10);

    // responders
    std::shared_ptr<EmergencyService> peace_keeping = std::make_shared<EmergencyService> ("Peace Keeping", "Peace Keeping", 911);
    std::shared_ptr<Message> scientists = std::make_shared<Message>("electronic message", "scientists");

    std::shared_ptr<Actuator> sprinklers = std::make_shared<Actuator> ("Magma Cooling", "Sprinkers");
    std::shared_ptr<Alarm> sulfur_alarm = std::make_shared<Alarm> ("Too much sulfur");

    std::shared_ptr<Alarm> low_oxy_alarm = std::make_shared<Alarm> ("Low oxygen");

    std::shared_ptr<EmergencyService> firefighter = std::make_shared<EmergencyService> ("Firefighters", "Firefighters", 112);
    std::shared_ptr<Alarm> egg_hatching = std::make_shared<Alarm> ("Hatching eggs");

    // adding responders to sensors
    twix_motion->addSensorResponse(peace_keeping);

    musk_kid_gas->addSensorResponse(sulfur_alarm);
    musk_kid_gas->addSensorResponse(scientists);

    orangestone_smoke->addSensorResponse(sprinklers);
    redstone_smoke->addSensorResponse(sprinklers);

    motion_LV->addSensorResponse(peace_keeping);
    motion_LV->addSensorResponse(scientists);
    oxygen_LV->addSensorResponse(low_oxy_alarm);

    motion_moon->addSensorResponse(egg_hatching);
    smoke_moon->addSensorResponse(firefighter);

    motion_dweezil->addSensorResponse(egg_hatching);
    smoke_dweezil->addSensorResponse(firefighter);

    // building tree
    emergencyCenter->addChildComponent(twix, 0);
    emergencyCenter->addChildComponent(twix_motion, twix);

    emergencyCenter->addChildComponent(x_AE_A_12, twix);
    emergencyCenter->addChildComponent(musk_kid_gas, x_AE_A_12);

    emergencyCenter->addChildComponent(redstone, x_AE_A_12);
    emergencyCenter->addChildComponent(redstone_smoke, redstone);

    emergencyCenter->addChildComponent(orangestone, x_AE_A_12);
    emergencyCenter->addChildComponent(orangestone_smoke, orangestone);

    emergencyCenter->addChildComponent(lv_426, twix);
    emergencyCenter->addChildComponent(motion_LV, lv_426);
    emergencyCenter->addChildComponent(oxygen_LV, lv_426);

    emergencyCenter->addChildComponent(moon_unit, lv_426);
    emergencyCenter->addChildComponent(motion_moon, moon_unit);
    emergencyCenter->addChildComponent(smoke_moon, moon_unit);

    emergencyCenter->addChildComponent(dweezil, lv_426);
    emergencyCenter->addChildComponent(motion_dweezil, dweezil);
    emergencyCenter->addChildComponent(smoke_dweezil, dweezil);

    // testing
    std::cout << "--------Activate and test atmospheric sensors--------" << std::endl;
    ++(*musk_kid_gas);
    ++(*oxygen_LV);
    ++(*motion_LV);
    musk_kid_gas->trigger();
    oxygen_LV->trigger();
    motion_LV->trigger();

    std::cout << std::endl << "--------Activate X AE A-12--------" << std::endl;
    ++(*x_AE_A_12);
    x_AE_A_12->trigger();

    std::cout << std::endl << "--------Deactivate and test--------" << std::endl;
    --(*lv_426);
    std::cout << std::endl << "-Testing-" << std::endl;
    lv_426->trigger();

    std::cout << std::endl << "--------Reactivate and test--------" << std::endl;
    ++(*lv_426);
    std::cout << std::endl << "-Testing LV-" << std::endl;
    lv_426->trigger();
    std::cout << std::endl << "-Testing Moon Unit-" << std::endl;
    moon_unit->trigger();
    std::cout << std::endl << "-Testing Dweezil-" << std::endl;
    dweezil->trigger();

    std::cout << std::endl << "--------Print by space--------" << std::endl;
    emergencyCenter->printSensorsBySpace();

    delete emergencyCenter;

    return 0;
}
