#ifndef SMOKESENSOR_H
#define SMOKESENSOR_H

#include "Sensor.h"

class SmokeSensor : public Sensor {

public:
	long smokeConcentration;

    SmokeSensor(std::string name, std::string type, std::string vendor, bool permanent, long smokeConcentration);

    std::string showDetails() const override;

};

#endif
