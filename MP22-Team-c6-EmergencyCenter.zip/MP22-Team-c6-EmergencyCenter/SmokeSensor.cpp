#include "SmokeSensor.h"
#include <iostream>
#include <sstream>

SmokeSensor::SmokeSensor(std::string name, std::string type, std::string vendor, bool permanent, long smokeConcentration):
    Sensor(name, type, vendor, permanent), smokeConcentration{smokeConcentration}
{
}

std::string SmokeSensor::showDetails() const {
    std::stringstream result;
    result << "The smoke sensor " << getName() <<
                 " of the type " << getType() <<
                 " with sensorID " << getSensorID() <<
                 " from " << getVendor() <<
                 getAlphaActive() << std::endl << printResponders();
    return result.str();
}

