#include <string>
#include <iostream>
#include <sstream>

#include "EmergencyService.h"

EmergencyService::EmergencyService(const std::string & name, const std::string & serviceType, int phoneNo) : 
        Responder(name), serviceType{serviceType} ,phoneNo{phoneNo} {
    
}

void EmergencyService::call() {
    std::cout << "Contacting " << serviceType << " at this number "<< phoneNo << std::endl;
}

std::string EmergencyService::showDetails() const {
    std::stringstream result;
    result << "If triggered, will call " << phoneNo << " for " << serviceType << std::endl;
    return result.str();
}