#include <string>
#include <iostream>
#include "Component.h"
#include "Sensor.h"
#include "Space.h"

Component::Component(std::string name, std::string type):
    name{name}, type{type}
{

}

Component::~Component() {

}

const std::string Component::getName() const {
    return name;

}

void Component::setName(std::string name) {
	this->name = name;
}

const std::string Component::getType() const {
    return type;
}

void Component::setType(std::string type) {
	this->type = type;
}


std::ostream &operator<<(std::ostream &os, const Component &component)
{
  os << component.showDetails() << std::endl;
  return os;
}

Component &Component::operator++()
{
    setActive(true);
    return *this;
}

Component &Component::operator--()
{
    setActive(false);
    return *this;
}

bool operator== (const std::shared_ptr<Component> & comp1, const std::shared_ptr<Component> & comp2) {
    if (auto sensor1 = std::dynamic_pointer_cast<Sensor> (comp1)) {
        if (auto sensor2 = std::dynamic_pointer_cast<Sensor> (comp2))
            return sensor1.get() == sensor2.get();
        else
            return false;
    } else if (auto space1 = std::dynamic_pointer_cast<Space> (comp1)) {
        if (auto space2 = std::dynamic_pointer_cast<Space> (comp2))
            return space1.get() == space2.get();
        else
            return false;
    } else return false;
}

