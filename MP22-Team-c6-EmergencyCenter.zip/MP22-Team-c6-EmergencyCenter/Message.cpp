#include <string>
#include <iostream>
#include <sstream>

#include "Message.h"

Message::Message(const std::string & name, const std::string & contactDetails) :
        Responder(name), contactDetails(contactDetails){

}

void Message::call() {
     std::cout << "Sending a(n) " << getName() << " to " << contactDetails << std::endl;
}

const std::string &Message::getcontactDetails() const {
    return contactDetails;
}

std::string Message::showDetails() const {
    std::stringstream result;
    result << "If triggered, will send " << getName() << " to " << contactDetails << std::endl;
    return result.str();
}
