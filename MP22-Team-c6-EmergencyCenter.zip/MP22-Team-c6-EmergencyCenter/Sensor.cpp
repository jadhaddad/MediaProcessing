#include "Responder.h"
#include "Sensor.h"

#include <string>
#include <sstream>
#include <iostream>

int Sensor::sensorCounter = 0;

Sensor::Sensor(std::string name, std::string type, std::string vendor, bool permanent):
   Component(name, type), sensorID{++sensorCounter}, vendor{vendor}, permanent{permanent}
{

}

Sensor::~Sensor()
{
    responders.clear();
}

int Sensor::getSensorID() const {
    return sensorID;
}

bool Sensor::getActive() const {
    return false;
}

void Sensor::setActive(bool active) {
    this->active = active;
    std::cout << getName() << getAlphaActive() << std::endl;
}

void Sensor::addSensorResponse(std::shared_ptr<Responder> responder) {
    for (const auto &current : responders) {
        if (current == responder) {
            std::cout << "Response already exists" << std::endl;
            return;
        }
    }

    responders.push_back(responder);
}

std::string Sensor::printResponders() const {
    std::stringstream result;
    result << "Responders:" << std::endl;

    for(const std::shared_ptr<Responder> &current : responders) {
        result << current->showDetails();
    }

    result << "---------------------------------";
    return result.str();
}

std::string Sensor::getAlphaActive() const {
    return (active)? " is active." : " is not active.";
}

const std::string Sensor::getVendor() const{
    return vendor;
}


void Sensor::setVendor(std::string vendor) {
    this->vendor = vendor;
}

bool Sensor::operator==(const Sensor &sensor) const {
    return sensorID == sensor.sensorID;
}

void Sensor::trigger() const {
    if (active) {
        std::cout << "The sensor " << Component::getName() << " has been triggered." << std::endl;
        for (auto current : responders)
        {
            current->call();
        }
        std::cout << "----" << std::endl;
    }
}



