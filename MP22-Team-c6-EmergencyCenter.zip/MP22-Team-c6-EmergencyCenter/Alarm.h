#ifndef ALARM_H
#define ALARM_H

#include "Responder.h"

class Alarm : public Responder {

private:
	bool status;

public:
	Alarm(const std::string & name);

    void call() override;

    std::string getStatus() const;

    void deactivate();

    std::string showDetails() const override;
};

#endif
