#ifndef SENSOR_H
#define SENSOR_H

#include <string>
#include <memory>
#include <vector>
#include <iostream>

#include "Component.h"

class Responder;

class Sensor : public Component {

private:
    int sensorID;

protected:
    static int sensorCounter;
    std::string vendor;
    bool active = false;
	bool permanent;
    std::vector<std::shared_ptr<Responder>> responders;

public:
    Sensor(std::string name, std::string type, std::string vendor, bool permanent);

    ~Sensor();

    int getSensorID() const;

    bool getActive() const;

    void setActive(bool active) override;

    void setVendor(std::string vendor);

    const std::string getVendor() const;

	void addSensorResponse(std::shared_ptr<Responder> responder);

    std::string printResponders() const;

    std::string getAlphaActive() const;

    void trigger() const override;

    bool operator== (const Sensor &sensor) const;
};


#endif
