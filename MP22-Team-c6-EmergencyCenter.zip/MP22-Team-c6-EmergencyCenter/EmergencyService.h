#ifndef EMERGENCYSERVICE_H
#define EMERGENCYSERVICE_H

#include <string>
#include "Responder.h"

class EmergencyService : public Responder {

private:
    std::string serviceType;
	int phoneNo;

public:
    EmergencyService(const std::string & name, const std::string & serviceType, int phoneNo);

    void call() override;

    std::string showDetails() const override;
};

#endif
