#ifndef EMERGENCYCENTER_H
#define EMERGENCYCENTER_H

#include <vector>
#include <memory>

#include "Actuator.h"
#include "Alarm.h"
#include "Component.h"
#include "EmergencyService.h"
#include "Message.h"
#include "MotionSensor.h"
#include "Responder.h"
#include "Sensor.h"
#include "SmokeSensor.h"
#include "Space.h"
#include "ToxicGasSensor.h"

class EmergencyCenter {

private:
    static EmergencyCenter * instance;

	EmergencyCenter();
    bool checkComponentInList(const std::shared_ptr<Component> component);

    std::vector<std::shared_ptr<Component>> components;

public:
    ~EmergencyCenter();

    static EmergencyCenter * getInstance();

    void printSensorsByVendor() const;

    void printSensorsBySpace() const;

    void printSensorsByID() const;

    /**
     * Also add to the vector components
     * @param childComponent component to be added to the parentComponent
     * @param parentComponent if null, childComponent has no parent and becomes root. Cannot be a sensor
     * @return true if addition is sucessful
    */
    bool addChildComponent(std::shared_ptr<Component> childComponent, std::shared_ptr<Component> parentComponent);

    void testSensorsInComponent(const std::shared_ptr<Component> component) const;
};

#endif
