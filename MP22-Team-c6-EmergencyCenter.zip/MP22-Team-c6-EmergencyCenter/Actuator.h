#ifndef ACTUATOR_H
#define ACTUATOR_H

#include <string>
#include "Responder.h"

class Actuator : public Responder {

private:
	bool status;
    std::string type;

public:
    Actuator(const std::string & name, const std::string & type);

    void call() override;

    const std::string &getType() const;

    std::string getStatus() const;

    void deactivate();

    std::string showDetails() const override;

};

#endif
