#ifndef TOXICGASSENSOR_H
#define TOXICGASSENSOR_H

#include "Sensor.h"

class ToxicGasSensor : public Sensor {
private:
    long gasConcentrationLimit;


public:

    std::string showDetails() const override;

    ToxicGasSensor(std::string name, std::string type, std::string vendor, bool permanent, long gasConcentration);
};



#endif
