#include "book.h"
#include <iostream>

Book::Book(const std::string& myTitle, float myPrice,  std::shared_ptr<Book> req):
  title{myTitle}, price{myPrice}, required{req}
{

}
Book::Book(const Book & other):title{other.getTitle()},price{other.getPrice()}
{
  std::cout << "calling copy ctor of Book" << std::endl;
}

std::string Book::getTitle() const
{
  return title;
}

float Book::getPrice() const
{
  return price;
}

void Book::setPrice(float value)
{
  price = value;
}

std::shared_ptr<Book> Book::getRequired() const
{
  return required;
}

void Book::setRequired(const std::shared_ptr<Book> &value)
{
  required = value;
}

bool Book::operator==(const Book &rhs)
{
  return rhs.getTitle() == getTitle();
}

