#include "student.h"
#include <iostream>
#include <sstream>

Student::Student(const std::string &myName, Stage myStage):name{myName},stage{myStage}
{
  std::cout << "constructing student with name " << name << std::endl;
}

Student::~Student()
{
  std::cout << "destructing student with name " << name << std::endl;
}

std::string Student::getName() const
{
  return name;
}

Stage Student::getStage() const
{
  return stage;
}

void Student::setStage(const Stage &newStage)
{
  stage = newStage;
}

void Student::printInfo() const
{
  std::cout << "Name : " << name << std::endl;
  std::cout << "Ordered " << myBooks.size() << " books" << std::endl;
}

int Student::addBook(const std::shared_ptr<Book> newBook)
{
  bool found = false;
  for (auto & b : myBooks)
    if (b == newBook)
      {
      found = true;
      break;
      }
  if (!found)
    {
    myBooks.push_back(newBook);
    if (newBook->getRequired() != nullptr)
        addBook((newBook->getRequired()));
    }
  return myBooks.size();
}

std::string Student::listBooks() const
{
  float totalPrice{0.0f};
  std::stringstream result;
  for (auto & b : myBooks)
    {
    result << b->getTitle() << std::endl;
    totalPrice += b->getPrice();
    }
  result << "For a total price of " << totalPrice << std::endl;
  return result.str();
}
