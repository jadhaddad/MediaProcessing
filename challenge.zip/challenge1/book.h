#ifndef BOOK_H
#define BOOK_H
#include <string>
#include <memory>

class Book
  {
  public:
    Book(const std::string & myTitle, float myPrice, std::shared_ptr<Book> req=nullptr);
    Book(const Book & other);

    std::string getTitle() const;
    float getPrice() const;
    void setPrice(float value);
    std::shared_ptr<Book> getRequired() const;
    void setRequired(const std::shared_ptr<Book> &value);

    bool operator==(const Book & rhs);
private:
    const std::string title;
    float price;
    std::shared_ptr<Book> required;
};

#endif // BOOK_H
