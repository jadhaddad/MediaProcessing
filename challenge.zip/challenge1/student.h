#ifndef STUDENT_H
#define STUDENT_H
#include <string>
#include <vector>
#include "book.h"

enum class Stage {starter, inbetween, graduating};

class Student
{
public:
  Student(const std::string & myName, Stage myStage= Stage::starter);
  ~Student();

  std::string getName() const;

  Stage getStage() const;
  void setStage(const Stage & newStage);
  void printInfo() const;
  int addBook(const std::shared_ptr<Book> newBook);
  std::string listBooks() const;

private:
  const std::string name;
  Stage stage;
  std::vector<std::shared_ptr<Book>> myBooks;
};

#endif // STUDENT_H
