#include <iostream>
#include <memory>
#include "student.h"

int main()
{
  Student s{"Yuri", Stage::starter};
  s.printInfo();
  auto pS = std::make_unique<const Student>("Ann", Stage::inbetween);
  pS->printInfo();
  auto b = std::make_shared<Book>("C++ for dummies", 25.25f);
  std::cout << s.addBook(b) << std::endl;
  auto b2 = std::make_shared<Book>("Advanced C++", 35.0f, std::make_shared<Book>("C in a nutshell", 20.0f));
  b2->setRequired(b);
  std::cout << s.addBook(b2) << std::endl;
  std::cout << s.listBooks();
  std::cout << s.addBook(b) << std::endl;
  s.printInfo();
  Student & rS{s};
  rS.setStage(Stage::inbetween);
  rS.printInfo();
}
