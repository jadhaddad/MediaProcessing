#ifndef ORDER_H
#define ORDER_H
#include <string>
#include <memory>
#include <vector>

class Order;
using orderCollection = std::vector<std::unique_ptr<const Order>>;

class Order
  {
  public:
    explicit Order(const std::string & aTitle, float aPrice = 0.0f, std::shared_ptr<const Order> req=nullptr);
    Order(const Order & other);
    virtual ~Order()= default;

    std::string getTitle() const;
    float getPrice() const;
    void setPrice(float value);
    std::shared_ptr<const Order> getRequired() const;
    void setRequired(const std::shared_ptr<const Order> &value);
    virtual std::string getDescription() const;

    bool operator==(const Order & other);

    static void addToNeedRequired(std::unique_ptr<const Order> o);
private:
    const std::string title;
    float price;
    std::shared_ptr<const Order> required;
    static std::vector<std::unique_ptr<const Order>> needRequired;
};

std::stringstream & operator<<(std::stringstream & ss, std::shared_ptr<const Order> other);

class compOrderByTitle
{
public:
  bool operator()(std::shared_ptr<const Order> first, std::shared_ptr<const Order> second)
  {
    return first->getTitle() < second->getTitle();
  }
};
class compOrderByPrice
{
public:
  bool operator()(std::shared_ptr<const Order> first, std::shared_ptr<const Order> second)
  {
    return first->getPrice() < second->getPrice();
  }
};

#endif // BOOK_H
