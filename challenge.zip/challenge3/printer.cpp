#include "printer.h"
#include "student.h"
#include <fstream>

bool Printer::scheduleJob(const std::string & filename, const Student &owner)
{
  std::ofstream of{filename};
  of << static_cast<Student>(owner).listOrders();
  return true;
}
