#ifndef STUDENT_H
#define STUDENT_H
#include <string>
#include <vector>
#include <memory>
#include "order.h"
#include "printer.h"

enum class Stage {starter, inbetween, graduating};


class Student
{
public:
  Student(const std::string & myName, Stage myStage= Stage::starter);
  ~Student();

  std::string getName() const;

  Stage getStage() const;
  void setStage(const Stage &value);

  void addOrder(std::shared_ptr<const Order> newBook);
  std::string listOrders(); //no longer const since we are reordering myOrders
  std::string listOrders(Printer & myPrinter) const;
  Student & operator+=(Student & other);
private:
  const std::string name;
  Stage stage;
  std::vector<std::shared_ptr<const Order>> myOrders;
};

#endif // STUDENT_H
