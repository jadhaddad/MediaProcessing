#include "student.h"
#include <iostream>
#include <sstream>
#include <algorithm>

Student::Student(const std::string &myName, Stage myStage):name{myName},stage{myStage}
{
  std::cout << "constructing student with name " << name << std::endl;
}

Student::~Student()
{
  std::cout << "destructing student with name " << name << std::endl;
}

std::string Student::getName() const
{
  return name;
}

Stage Student::getStage() const
{
  return stage;
}

void Student::setStage(const Stage &value)
{
  stage = value;
}

void Student::addOrder(std::shared_ptr<const Order> newBook)
{
  bool found{false};
  for (auto & book : myOrders)
    {
      if (book == newBook)
        {
          found = true;
          break;
        }
    }
  if (!found)
    {
      myOrders.push_back(newBook);
      if (newBook->getRequired() != nullptr)
        addOrder(newBook->getRequired());

    }
}

std::string Student::listOrders()
{
  std::sort(std::begin(myOrders), std::end(myOrders), compOrderByPrice());
  float totalPrice{0.0f};
  std::stringstream result;
  for (auto & b : myOrders)
    {
      result << b;
      totalPrice += b->getPrice();
    }
  result << "For a total price of " << totalPrice << std::endl;
  return result.str();
}

std::string Student::listOrders(Printer &myPrinter) const
{
  myPrinter.scheduleJob("test.txt", *this);
  return "printed";
}

Student &Student::operator+=(Student &other)
{
   this->listOrders() += other.listOrders();
    listOrders().clear();
    return *this;
}

