#include "activity.h"
#include <sstream>

Activity::Activity(const std::string &aTitle, float aPrice,
                   std::shared_ptr<const Order> req, QDateTime start,
                   QDateTime end, int maximum):
  Order(aTitle, aPrice, req), startMoment{start}, endMoment{end}, maxParticipants{maximum}
{

}

std::string Activity::getDescription() const
{
  std::stringstream result;
  result << Order::getDescription();
  result << "starting on " << startMoment.toString().toStdString() << std::endl;
  result << "ending on " << endMoment.toString().toStdString() << std::endl;
  result << "with a maximum number of " << maxParticipants << " participants" << std::endl;
  return result.str();
}
