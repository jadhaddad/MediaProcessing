#ifndef PRINTER_H
#define PRINTER_H
#include <string>

class Student;
class Printer
{
public:
  Printer() = default;
  bool scheduleJob(const std::string & filename, const Student & owner);
};

#endif // PRINTER_H
