#include <iostream>
#include <memory>
#include "student.h"
#include "book.h"
#include "activity.h"

//the construction of this code can be followed in coursetext pp. 47-49
int main()
{
  Student s{"Yuri", Stage::starter};
  auto pS = std::make_unique<Student>("Ann", Stage::inbetween);
  auto b = std::make_shared<const Book>("C++ for dummies", 25.25f);
//  s.addBook(b);
  s.addOrder(b);
  s += s;
  std::cout << s.listOrders();
  auto b2 = std::make_shared<const Book>("Advanced C++", 35.0f, b);
  //copy since we have no idea how long b2 object will exist
  Order::addToNeedRequired(std::make_unique<const Order>(*b2));
  s.addOrder(b2);
  auto a1 = std::make_shared<const Activity>("Trip to Antwerp", 20.0f, nullptr,
                                       QDateTime(QDate(2018,9,27), QTime(12, 15)),
                                       QDateTime(QDate(2018, 9, 28), QTime(16, 0)), 55);
  std::cout << s.listOrders();
}
