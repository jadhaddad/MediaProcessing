#include "book.h"

Book::Book(const std::string &aTitle, float aPrice, std::shared_ptr<const Order> req):
  Order(aTitle, aPrice, req)
{

}
