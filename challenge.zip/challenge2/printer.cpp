#include "printer.h"
#include <fstream>
#include "student.h"

Printer::Printer()
{

}

bool Printer::scheduleJob(const std::string &filename, const Student &owner)
{
  std::ofstream of{filename};
  of << owner.listOrders();
  return true;
}
