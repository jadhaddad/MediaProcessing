#include "student.h"
#include <iostream>
#include <sstream>

Student::Student(const std::string &myName, Stage myStage):name{myName},stage{myStage}
{
  std::cout << "constructing student with name " << name << std::endl;
}

Student::~Student()
{
  std::cout << "destructing student with name " << name << std::endl;
}

std::string Student::getName() const
{
  return name;
}

Stage Student::getStage() const
{
  return stage;
}

void Student::setStage(const Stage &value)
{
  stage = value;
}

int Student::addOrder(std::shared_ptr<const Order> newBook)
{
  bool found{false};
  for (auto & book : myOrders)
    {
      if (book == newBook)
        {
          found = true;
          break;
        }
    }
  if (!found)
    {
      myOrders.push_back(newBook);
      if (newBook->getRequired() != nullptr)
        addOrder(newBook->getRequired());

    }
  return myOrders.size();
}

std::string Student::listOrders() const
{
  float totalPrice{0.0f};
  std::stringstream result;
  for (auto & anOrder : myOrders)
    {
      result << anOrder->getDescription();
      totalPrice += anOrder->getPrice();
    }
  result << "For a total price of " << totalPrice << std::endl;
  return result.str();
}

std::string Student::listOrders(Printer &myPrinter) const
{
  myPrinter.scheduleJob("test.txt", *this);
  return "printed";
}
