#ifndef BOOK_H
#define BOOK_H
#include "order.h"

class Book : public Order
{
public:
  Book(const std::string & aTitle, float aPrice, std::shared_ptr<const Order> req=nullptr);
  std::string getDescription() const override;
};

#endif // BOOK_H
