#ifndef PRINTER_H
#define PRINTER_H
#include <string>
//#include "student.h"
class Student;
class Printer
{
public:
  Printer();
  bool scheduleJob(const std::string & filename, const Student & owner);
};

#endif // PRINTER_H
