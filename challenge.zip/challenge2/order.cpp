#include "order.h"
#include <iostream>
#include <sstream>

Order::Order(const std::string& aTitle, float aPrice, std::shared_ptr<const Order> req):
  title{aTitle}, price{aPrice}, required{req}
{

}
Order::Order(const Order & other):title{other.getTitle()},price{other.getPrice()}
{
  std::cout << "calling copy ctor of Book" << std::endl;
}

std::string Order::getTitle() const
{
  return title;
}

float Order::getPrice() const
{
  return price;
}

void Order::setPrice(float value)
{
  price = value;
}

std::shared_ptr<const Order> Order::getRequired() const
{
    return required;
}

void Order::setRequired(const std::shared_ptr<const Order> &value)
{
  required = value;
}

bool Order::operator==(const Order &other)
{
  return title == other.getTitle();
}


