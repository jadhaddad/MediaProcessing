#ifndef STUDENT_H
#define STUDENT_H
#include <string>
#include <vector>
#include <memory>
#include "order.h"
#include "printer.h"

enum class Stage {starter, inbetween, graduating};

class Student
{
public:
    Student(const std::string & myName, Stage myStage= Stage::starter);
    ~Student();

    std::string getName() const;

    Stage getStage() const;
    void setStage(const Stage &value);

    int addOrder(std::shared_ptr<const Order> newBook);
    std::string listOrders() const;
    std::string listOrders(Printer &myPrinter) const;

private:
    const std::string name;
    Stage stage;
    std::vector<std::shared_ptr<const Order>> myOrders;
};

#endif // STUDENT_H
