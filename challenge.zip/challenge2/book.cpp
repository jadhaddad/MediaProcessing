#include "book.h"
#include <sstream>

Book::Book(const std::string &aTitle, float aPrice, std::shared_ptr<const Order> req):
  Order(aTitle, aPrice, req)
{

}

std::string Book::getDescription() const
{
  std::stringstream result;
  result << getTitle() << " for the price of " << getPrice() << std::endl;
  return result.str();
}
