#include <iostream>
#include <memory>
#include "student.h"
#include "book.h"
#include "activity.h"
#include "printer.h"

int main()
{
  Student s{"Yuri", Stage::starter};
  auto pS = std::make_unique<Student>("Ann", Stage::inbetween);
  auto b = std::make_shared<const Book>("C++ for dummies", 25.25f);
  auto b2 = std::make_shared<const Book>("Advanced C++", 35.0f, b);
  std::cout << s.addOrder(b2) << std::endl;;
  auto a1 = std::make_shared<const Activity>("Trip to ??", 20.0f, nullptr,
                            QDateTime(QDate(2019,9,26), QTime(12, 15)),
                            QDateTime(QDate(2019, 9, 2), QTime(16, 0)), 55);
  std::cout << s.addOrder(a1) << std::endl;;
  std::cout << s.listOrders();
  Printer test;
  s.listOrders(test);
}
