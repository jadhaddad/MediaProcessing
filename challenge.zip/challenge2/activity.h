#ifndef ACTIVITY_H
#define ACTIVITY_H
#include "order.h"
#include <QDateTime>

class Activity : public Order
{
public:
  Activity(const std::string & aTitle, float aPrice, std::shared_ptr<const Order> req=nullptr,
           QDateTime start = QDateTime::currentDateTime(),
           QDateTime end = QDateTime::currentDateTime(), int maximum = 0);
  std::string getDescription() const override;

private:
  QDateTime startMoment;
  QDateTime endMoment;
  int maxParticipants;
};

#endif // ACTIVITY_H
