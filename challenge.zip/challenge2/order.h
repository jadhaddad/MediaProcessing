#ifndef ORDER_H
#define ORDER_H
#include <string>
#include <memory>

class Order
  {
  public:
    Order(const std::string & aTitle, float aPrice, std::shared_ptr<const Order> req=nullptr);
    Order(const Order & other);
    virtual ~Order()= default;
    std::string getTitle() const;

    float getPrice() const;
    void setPrice(float value);

    std::shared_ptr<const Order> getRequired() const;
    void setRequired(const std::shared_ptr<const Order> &value);
    bool operator==(const Order & other);

    virtual std::string getDescription() const = 0;


private:
    const std::string title;
    float price;
    std::shared_ptr<const Order> required;
};

#endif // BOOK_H
