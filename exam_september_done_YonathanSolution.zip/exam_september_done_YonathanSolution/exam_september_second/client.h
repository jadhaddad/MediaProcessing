#ifndef CLIENT_H
#define CLIENT_H

#include <string>
#include <memory>

class Client
{

public:
    Client(std::string email);
    void addCredit(float amount);
    bool executePayment(float amount);
    float getCredit() const;
    const std::string &getEmail() const;

private:
    const std::string email;
    float credit;

};

#endif // CLIENT_H
