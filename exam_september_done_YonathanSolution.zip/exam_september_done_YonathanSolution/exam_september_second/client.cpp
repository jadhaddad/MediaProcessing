#include "client.h"

Client::Client(std::string email) :
    email{std::move(email)}, credit{0.0f}
{

}

void Client::addCredit(float amount)
{
    credit += amount;
}

bool Client::executePayment(float amount)
{
    credit -= amount;
    if (amount > credit)    // cannot afford
        return false;
    else
        return true;
}

float Client::getCredit() const
{
    return credit;
}

const std::string &Client::getEmail() const
{
    return email;
}
