﻿#ifndef MANAGEMENT_H
#define MANAGEMENT_H
#include <string>
#include <memory>
#include <vector>
#include <set>

using GPSPos = std::pair<std::string, std::string>;

class Scooter;
class Management
{
public:
  Management(unsigned int refreshTime);
  bool registerClient(std::string email);
  bool addScooter(GPSPos place);
  static bool addPreferredLocation(const GPSPos & place);
  bool isPreferredLocation(const GPSPos & place) const;
  std::vector<std::shared_ptr<Scooter>> giveAvailableScooters(GPSPos where, int distance = 10);
  std::shared_ptr<Scooter> rentOne(GPSPos where, std::string who);

private:
  unsigned int updateTime;
  std::vector<std::string> registeredClients;
  std::set<std::shared_ptr<Scooter>> scooters;
  static std::set<GPSPos> preferredLocations;
};

std::ostream & operator<<(std::ostream & os, GPSPos & gps);

int calcDistance(const GPSPos & pos1, const GPSPos & pos2);
#endif // MANAGEMENT_H
