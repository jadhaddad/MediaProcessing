﻿#include "scooter.h"
#include <cmath>
#include <iostream>

Scooter::Scooter(GPSPos where, const Management &comp):
  batteryLevel{100.0f}, currentPosition{where}, startRent{nullptr}, company{comp}
{

}

void Scooter::updateLevel(float newLevel)
{
  batteryLevel = newLevel;
}

void Scooter::updatePosition(GPSPos newPos)
{
  currentPosition = newPos;
}

bool Scooter::startRenting(QDateTime startMoment)
{
  if (startRent == nullptr && batteryLevel >= 0.75f)
    {
    startRent = new QDateTime(startMoment);
    return true;
    }
  return false;
}

float Scooter::endRenting(QDateTime endMoment)
{
  if (startRent)
    {
      //calculate totalRenting price
      float price = 0.0f;
      unsigned int secs = startRent->secsTo(endMoment);
      //fixed price for 1st hour
      price += 2.0f;
      // 20 cents/15 min for the rest
      if (secs - 3600 > 0)
        {
          auto nrQuarters = std::ceil((secs-3600)/900.0f);
          price += nrQuarters * 0.2f;
        }
      //20% discount if returned on preferred location
      if (company.isPreferredLocation(currentPosition))
        price *= 0.8;

      //clean up renting
      delete  startRent;
      startRent = nullptr;
      return price;
    }
  return 0.0f;
}

float Scooter::getBatteryLevel() const
{
  return batteryLevel;
}

GPSPos & Scooter::getCurrentPosition()
{
  return currentPosition;
}

std::ostream &operator<<(std::ostream &os, std::shared_ptr<Scooter> scoot)
{
  os << "Current status of scooter: ";
  if (scoot->startRent)
    os << "(NOT AVAILABLE)" << std::endl;
  else
    os << "(AVAILABLE)" << std::endl;
  os << "\t" << "battery level : " << scoot->getBatteryLevel() << std::endl;
  os << "\t" << "curent position : [" << scoot->getCurrentPosition() <<  "]" << std::endl;
  return os;
}
