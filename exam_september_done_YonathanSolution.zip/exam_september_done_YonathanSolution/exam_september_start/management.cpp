﻿#include "management.h"
#include "scooter.h"
#include <algorithm>
#include <stdexcept>
#include <iostream>

std::set<GPSPos> Management::preferredLocations;

Management::Management(unsigned int refreshTime): updateTime{refreshTime}
{

}

bool Management::registerClient(std::string email)
{
  if (std::find(registeredClients.begin(), registeredClients.end(), email) == registeredClients.end())
    {
      registeredClients.push_back(email);
      return true;
    }
  return false;

}

bool Management::isPreferredLocation(const GPSPos &place) const
{
  return preferredLocations.find(place) != preferredLocations.end();
}

std::vector<std::shared_ptr<Scooter>> Management::giveAvailableScooters(GPSPos where, int distance)
{
  std::vector<std::shared_ptr<Scooter>> result;
  for (auto & s : scooters)
    {
      if (calcDistance(where, s->getCurrentPosition()) <= distance && s->getBatteryLevel() > 10.0f)
         result.push_back(s);
    }
  return result;
}

std::shared_ptr<Scooter> Management::rentOne(GPSPos where, std::string who)
{
  auto candidates = giveAvailableScooters(where);
  if (!candidates.empty())
    {
      if (std::find(registeredClients.begin(), registeredClients.end(), who) != registeredClients.end())
        {
          if (candidates[0]->startRenting())
            return candidates[0];
        }
    }
  throw std::runtime_error("no scooter available");
}


bool Management::addScooter(GPSPos place)
{
  auto [it, res] = scooters.insert(std::make_shared<Scooter>(place, *this));
  return res;
}

bool Management::addPreferredLocation(const GPSPos &place)
{
  auto [it, res] = preferredLocations.insert(place);
  return res;
}



int calcDistance(const GPSPos &pos1, const GPSPos &pos2)
  {
     double deltaLat = (std::stod(pos1.first) - std::stod(pos2.first))*M_PI/180;
     double deltaLong = (std::stod(pos1.second) - std::stod(pos2.second))*M_PI/180;
     double sumLong = std::stod(pos1.second) + std::stod(pos2.second);

     double res1 = deltaLat * std::cos(sumLong*M_PI/360.0);
     double res2 = std::sqrt(res1*res1 + deltaLong*deltaLong) * 6371000;
     return std::round(res2);
    }

std::ostream & operator<<(std::ostream & os, GPSPos & gps)
{
    return os << gps.first << ", " << gps.second;
}
