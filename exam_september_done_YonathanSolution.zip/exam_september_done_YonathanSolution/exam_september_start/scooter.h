﻿#ifndef SCOOTER_H
#define SCOOTER_H
#include <string>
#include <QDateTime>
#include "management.h"


class Scooter
{
public:
  Scooter(GPSPos where, const Management & comp);
  void updateLevel(float newLevel);
  void updatePosition(GPSPos newPos);
  bool startRenting(QDateTime startMoment = QDateTime::currentDateTime());
  float endRenting(QDateTime endMoment = QDateTime::currentDateTime());

  float getBatteryLevel() const;
  GPSPos & getCurrentPosition();
  friend std::ostream & operator<<(std::ostream & os, std::shared_ptr<Scooter> scoot);

private:
  float batteryLevel;
  GPSPos currentPosition;
  QDateTime * startRent;
  const Management & company;
};

#endif // SCOOTER_H
