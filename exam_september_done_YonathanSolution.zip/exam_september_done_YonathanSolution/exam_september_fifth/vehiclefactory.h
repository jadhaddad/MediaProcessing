#ifndef VEHICLEFACTORY_H
#define VEHICLEFACTORY_H

#include <map>
#include "vehicle.h"

template<typename T>
Vehicle * createVehicle(GPSPos pos, const Management & management)
{
    return new T(pos, management);
}

class VehicleFactory
{
    typedef std::map<std::string, Vehicle* (*)(GPSPos, const Management &)> map_type;

public:
    static Vehicle * createInstance(std::string, GPSPos, const Management &);
    static map_type * map;

};

template<typename T>
class VehicleRegister : VehicleFactory
{
public:
    VehicleRegister(std::string type)
    {
        map->insert(std::make_pair(type, &createVehicle<T>));
    };
};

#endif // VEHICLEFACTORY_H
