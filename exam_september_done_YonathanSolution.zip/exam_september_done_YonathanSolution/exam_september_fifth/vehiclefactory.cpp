#include "vehiclefactory.h"

VehicleFactory::map_type * VehicleFactory::map = new VehicleFactory::map_type;

Vehicle *VehicleFactory::createInstance(std::string type, GPSPos pos, const Management & management)
{
    map_type::iterator iter = map->find(type);
    if (iter == map->end())
        return 0;
    else
        return iter->second(pos, management);
}
