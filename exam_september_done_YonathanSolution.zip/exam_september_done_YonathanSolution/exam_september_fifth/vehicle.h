#ifndef VEHICLE_H
#define VEHICLE_H

#include <string>
#include <QDateTime>

#include "management.h"

class Vehicle
{
public:
    Vehicle(GPSPos where, const Management & comp);
    void updateLevel(float newLevel);
    void updatePosition(GPSPos newPos);

    virtual bool isType(std::string) = 0;

    virtual bool startRenting(std::shared_ptr<Client> & rentedBy,
                              QDateTime startMoment = QDateTime::currentDateTime()) = 0;
    virtual float endRenting(QDateTime endMoment = QDateTime::currentDateTime()) = 0;

    virtual std::string printDetail() = 0;

    float getBatteryLevel() const;
    const GPSPos & getCurrentPosition() const ;

protected:
    float batteryLevel;
    GPSPos currentPosition;
    QDateTime * startRent;
    std::shared_ptr<Client> rentedBy;
    const Management & company;
};

std::ostream & operator<<(std::ostream & os, std::shared_ptr<Vehicle> vehicle);

#endif // VEHICLE_H
