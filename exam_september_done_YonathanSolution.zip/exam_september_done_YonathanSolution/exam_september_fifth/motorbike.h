#ifndef MOTORBIKE_H
#define MOTORBIKE_H

#include "vehicle.h"
#include "vehiclefactory.h"

class MotorBike : public Vehicle
{
public:
    static std::string TYPE;

    MotorBike(GPSPos where, const Management & comp, bool categoryA = false);

    virtual bool isType(std::string) override;

    virtual bool startRenting(std::shared_ptr<Client> & rentedBy,
                              QDateTime startMoment = QDateTime::currentDateTime()) override;
    virtual float endRenting(QDateTime endMoment = QDateTime::currentDateTime()) override;

    friend std::ostream & operator<<(std::ostream & os, std::shared_ptr<MotorBike> motorbike);

    bool getCategoryA() const;

    virtual std::string printDetail() override;

private:
    static VehicleRegister<MotorBike> reg;
    const bool categoryA;
    bool checkClientOldEnough(std::shared_ptr<Client>);
};

#endif // MOTORBIKE_H
