#include "motorbike.h"
#include "client.h"
#include <iostream>
#include <sstream>

std::string MotorBike::TYPE = "MOTORBIKE";
VehicleRegister<MotorBike> MotorBike::reg(TYPE);

MotorBike::MotorBike(GPSPos where, const Management & comp, bool categoryA) :
    Vehicle(where, comp), categoryA{categoryA}
{

}

bool MotorBike::isType(std::string type)
{
    return type == TYPE;
}

bool MotorBike::startRenting(std::shared_ptr<Client> &rentedBy, QDateTime startMoment)
{
    if (startRent == nullptr && batteryLevel >= 0.75f)
    {
        if (!checkClientOldEnough(rentedBy))
        {
            std::cout << "Client not old enough to drive non Category A motorbike" << std::endl;
            return false;
        }

        this->rentedBy = rentedBy;
        startRent = new QDateTime(startMoment);
        return true;
    }
    return false;
}

float MotorBike::endRenting(QDateTime endMoment)
{
    if (startRent)
      {
        //calculate totalRenting price
        float price = 0.0f;
        unsigned int secs = startRent->secsTo(endMoment);
        //fixed price for 1st hour
        price += 4.0f;
        // 30 cents/15 min for the rest
        if (secs - 3600 > 0)
          {
            auto nrQuarters = std::ceil((secs-3600)/900.0f);
            price += nrQuarters * 0.3f;
          }
        //20% discount if returned on preferred location
        if (company.isPreferredLocation(currentPosition))
          price *= 0.8;

        //clean up renting
        delete  startRent;
        startRent = nullptr;

        //remove client
        if (!rentedBy->executePayment(price))
        {
            std::cout << "Client " << rentedBy->getEmail() << " has not enough credit..." << std::endl;
        }
        rentedBy.reset();

        return price;
      }
    return 0.0f;
}

std::ostream & operator<<(std::ostream & os, std::shared_ptr<MotorBike> motorbike)
{
    return os << motorbike->printDetail();
}

bool MotorBike::getCategoryA() const
{
    return categoryA;
}

std::string MotorBike::printDetail()
{
    std::stringstream ss;
    ss << "Current status of motorbike: ";
    if (startRent)
      ss << "(NOT AVAILABLE)" << std::endl;
    else
      ss << "(AVAILABLE)" << std::endl;
    ss << "\t" << "fuel level : " << getBatteryLevel() << std::endl;
    ss << "\t" << "curent position : [" << getCurrentPosition() <<  "]" << std::endl;
    return ss.str();
}

bool MotorBike::checkClientOldEnough(std::shared_ptr<Client> client)
{
    if (categoryA) return true; // don't need to check for age
    else
    {
        int age = client->getDOB().daysTo(QDate::currentDate()) / 365;

        std::cout << "age " << age << std::endl;

        return age >= 18;
    }
}
