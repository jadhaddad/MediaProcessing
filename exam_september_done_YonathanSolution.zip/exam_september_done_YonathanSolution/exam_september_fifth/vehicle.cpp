#include "vehicle.h"

Vehicle::Vehicle(GPSPos where, const Management &comp) :
    batteryLevel{100.0f}, currentPosition{where}, startRent{nullptr}, company{comp}
{

}

void Vehicle::updateLevel(float newLevel)
{
  batteryLevel = newLevel;
}

void Vehicle::updatePosition(GPSPos newPos)
{
    currentPosition = newPos;
}

float Vehicle::getBatteryLevel() const
{
  return batteryLevel;
}

const GPSPos & Vehicle::getCurrentPosition() const
{
  return currentPosition;
}

std::ostream & operator<<(std::ostream & os, std::shared_ptr<Vehicle> vehicle)
{
    return os << vehicle->printDetail();
}
