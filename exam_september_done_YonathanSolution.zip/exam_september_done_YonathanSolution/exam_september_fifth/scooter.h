﻿#ifndef SCOOTER_H
#define SCOOTER_H

#include "vehicle.h"
#include "vehiclefactory.h"

class Scooter : public Vehicle
{
public:
  static std::string TYPE;

  Scooter(GPSPos where, const Management & comp);

  virtual bool isType(std::string) override;

  virtual bool startRenting(std::shared_ptr<Client> & rentedBy,
                            QDateTime startMoment = QDateTime::currentDateTime()) override;
  virtual float endRenting(QDateTime endMoment = QDateTime::currentDateTime()) override;

  friend std::ostream & operator<<(std::ostream & os, std::shared_ptr<Scooter> scoot);

  virtual std::string printDetail() override;

private:
  static VehicleRegister<Scooter> reg;
};

#endif // SCOOTER_H
