﻿#ifndef MANAGEMENT_H
#define MANAGEMENT_H
#include <string>
#include <memory>
#include <vector>
#include <set>

using GPSPos = std::pair<std::string, std::string>;

class Vehicle;
class Client;

class Management
{
public:
  Management(unsigned int refreshTime);
  bool registerClient(std::shared_ptr<Client> email);
  bool addVehicle(GPSPos place, std::string type);
  static bool addPreferredLocation(const GPSPos & place);
  bool isPreferredLocation(const GPSPos & place) const;
  std::vector<std::shared_ptr<Vehicle>> giveAvailableVehicles(GPSPos & where,
                                                              int distance = 10);
  std::shared_ptr<Vehicle> rentOne(GPSPos & where,
                                   std::shared_ptr<Client> who,
                                   std::string type);

private:
  unsigned int updateTime;
  std::vector<std::shared_ptr<Client>> registeredClients;
  std::set<std::shared_ptr<Vehicle>> vehicles;
  static std::set<GPSPos> preferredLocations;

  bool clientExists(std::shared_ptr<Client> client);
};

std::ostream & operator<<(std::ostream & os, const GPSPos & gps);

int calcDistance(const GPSPos & pos1, const GPSPos & pos2);
#endif // MANAGEMENT_H
