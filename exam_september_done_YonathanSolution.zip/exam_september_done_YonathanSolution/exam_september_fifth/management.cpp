﻿#include "management.h"
#include "client.h"
#include "vehiclefactory.h"
#include <algorithm>
#include <stdexcept>
#include <iostream>
#include <regex>

std::set<GPSPos> Management::preferredLocations;

bool Management::clientExists(std::shared_ptr<Client> client)
{
    for (const auto & registered : registeredClients)
    {
        if (registered->getEmail() == client->getEmail())
            return true;
    }

    return false;
}

Management::Management(unsigned int refreshTime): updateTime{refreshTime}
{

}

bool Management::registerClient(std::shared_ptr<Client> client)
{
    std::regex filter(R"([a-z|\.|\d]+[^\.]@[a-z]+\.[a-z]+)");

    if (std::regex_match(client->getEmail(), filter) && !clientExists(client))
    { 
      registeredClients.emplace_back(client);
      return true;
    }

    return false;
}

bool Management::isPreferredLocation(const GPSPos &place) const
{
  return preferredLocations.find(place) != preferredLocations.end();
}

std::vector<std::shared_ptr<Vehicle>> Management::giveAvailableVehicles(GPSPos & where, int distance)
{
  std::vector<std::shared_ptr<Vehicle>> result;
  for (auto & s : vehicles)
    {
      if (calcDistance(where, s->getCurrentPosition()) <= distance && s->getBatteryLevel() > 10.0f)
         result.push_back(s);
    }

  std::sort(result.begin(), result.end(), [] (auto & scooter1, auto & scooter2)
  {
      return scooter1->getBatteryLevel() > scooter2->getBatteryLevel();
  });
  return result;        // compiler optimise using move elision
}

std::shared_ptr<Vehicle> Management::rentOne(GPSPos & where,
                                             std::shared_ptr<Client> who,
                                             std::string type)
{
  auto candidates = giveAvailableVehicles(where);
  if (!candidates.empty())
    {
      if (std::find(registeredClients.begin(), registeredClients.end(), who) != registeredClients.end())
        {
          for (auto candidate : candidates)
          {
            if (candidate->isType(type) &&
                    candidates[0]->startRenting(who))
                return candidates[0];
          }
        }
    }
  std::stringstream error;
  error << "no vehicle type "
        << type
        <<  " available";

  throw std::runtime_error(error.str());
}


bool Management::addVehicle(GPSPos place, std::string type)
{
    Vehicle * vehicle = VehicleFactory::createInstance(type, place, *this);
    if (!vehicle) return false;
    std::shared_ptr<Vehicle> pV{vehicle};
    auto [it, res] = vehicles.insert(std::move(pV));
    return res;
}

bool Management::addPreferredLocation(const GPSPos &place)
{
  auto [it, res] = preferredLocations.insert(place);
  return res;
}



int calcDistance(const GPSPos &pos1, const GPSPos &pos2)
  {
     double deltaLat = (std::stod(pos1.first) - std::stod(pos2.first))*M_PI/180;
     double deltaLong = (std::stod(pos1.second) - std::stod(pos2.second))*M_PI/180;
     double sumLong = std::stod(pos1.second) + std::stod(pos2.second);

     double res1 = deltaLat * std::cos(sumLong*M_PI/360.0);
     double res2 = std::sqrt(res1*res1 + deltaLong*deltaLong) * 6371000;
     return std::round(res2);
    }

std::ostream & operator<<(std::ostream & os, const GPSPos & gps)
{
    return os << gps.first << ", " << gps.second;
}
