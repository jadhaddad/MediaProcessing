#ifndef CLIENT_H
#define CLIENT_H

#include <string>
#include <memory>
#include <QDate>

class Client
{

public:
    Client(std::string email, QDate dob = QDate(2000, 1, 1));
    void addCredit(float amount);
    bool executePayment(float amount);
    float getCredit() const;
    const std::string &getEmail() const;
    const QDate &getDOB() const;

private:
    const std::string email;
    float credit;
    const QDate dob;

};

#endif // CLIENT_H
