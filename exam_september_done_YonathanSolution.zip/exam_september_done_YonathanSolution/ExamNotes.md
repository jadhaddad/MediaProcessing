# Fix errors (exam_september_start)
- `main.cpp` line 45: change . to -> as `exc` is a pointer.
- `Management::isPreferredLocation()` remove dereference `find()`, may cause a segmentation fault.
- `std::ostream & operator<<(std::ostream & os, std::shared_ptr<Scooter> scoot)`
  - Need `#include <iostream>`
  - Created an operator method of << with a `GPSPos`
- Return reference of GPSPos for `Scooter::getCurrentPosition()` to prevent copy.
- `Scooter::endRenting()` move clean up renting after calculations.
- Initialise static member variable `Management::preferredLocations`.

# Add Client (exam_september_second)
- Implemented client.
- Changed management to include client.
- Changed scooter to include client.
- Add function to prevent adding same client.

# Sort by battery (exam_september_third_fourth)
- Use `std::sort`

# Filter emails (exam_september_third_fourth)
- Use regex.
- Before @
  - `[...]+` 1 or more characters
  - `a-z` and `\d` for alphanumeric OR (`|`)
  - `\.` to allow dots.
- `[^\.]`no dot before @
- After @
  - Any lowercase ASCII alphabet, with dot in the middle.

```C++
std::regex filter(R"([a-z|\.|\d]+[^\.]@[a-z]+\.[a-z]+)");

bool match = std::regex_match(client->getEmail(), filter);
```

# The fucked part (exam_september_fifth)

![UML](UML_part_5.jpg)

- Adding/renting vehicles pass on a public static string `TYPE` stored in each vehicle.
- `Management` uses `VehicleFactory` to initialise the vehicle depending on the type.
- `VehicleFactory` Uses a map as dictionary, with `TYPE` as key and a function pointer `createVehicle`. This function
- `VehicleFactory` overriden by template class `VehicleRegister<T>`. This is used by each vehicle to add their key to the map and give a reference of the class's constructor.
- Main reason to do this:
  - New vehicles may be added in the future
  - When registering/renting a vehicle, a switch case on `TYPE` can be used
  - This is not a good solution as the switch case can grow rather large
  - And adding a new vehicle also need to add more cases, making code hard to maintain.