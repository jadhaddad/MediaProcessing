﻿#include <iostream>
#include "scooter.h"
#include "client.h"

/* main for part 1
int main()
{
  Management happyScooters(600);
  GPSPos GTBuilding = std::make_pair<std::string, std::string>("50.8760969","4.705526");
  GPSPos Stuk = std::make_pair<std::string, std::string>("50.8757496","4.6990844");
  GPSPos ESAT = std::make_pair<std::string, std::string>("50.8636907","4.6886372");
  happyScooters.addPreferredLocation(GTBuilding);
  happyScooters.addPreferredLocation(Stuk);
  happyScooters.addPreferredLocation(ESAT);
  happyScooters.addScooter(GTBuilding);
  happyScooters.addScooter(GTBuilding);
  happyScooters.addScooter(Stuk);
  auto candidates = happyScooters.giveAvailableScooters(GTBuilding, 100);
  std::cout << candidates.size() << " possible scooters found" << std::endl;
  for (auto & s : candidates)
    std::cout << s;
  try
  {
    std::cout << std::boolalpha << happyScooters.registerClient("lone.biker@gmail.com") << std::endl;
    auto scoot1 = happyScooters.rentOne(GTBuilding, "lone.biker@gmail.com");
    QDateTime momentInFuture = QDateTime::currentDateTime().addSecs(4600);
    scoot1->updateLevel(0.9f);
    scoot1->updatePosition(Stuk);
    std::cout << scoot1;
    std::cout << scoot1->endRenting(momentInFuture) << std::endl;
    std::cout << happyScooters.giveAvailableScooters(GTBuilding, 100).size() << std::endl;
    scoot1->updateLevel(0.85f);
    std::cout << scoot1;
    std::cout << std::boolalpha << happyScooters.registerClient("louis.tobback@leuven.be") << std::endl;
    auto scoot2 = happyScooters.rentOne(Stuk, "louis.tobback@leuven.be");
    scoot2->updateLevel(0.1f);
    scoot2->updatePosition(std::make_pair<std::string, std::string>("50.885021","4.6994844"));
    std::cout << scoot2->endRenting(momentInFuture.addSecs(7205)) << std::endl;
    std::cout << scoot2;
    std::cout << std::boolalpha << scoot2->startRenting(momentInFuture.addSecs(8000)) << std::endl;
    if (happyScooters.registerClient("louis.tobback@leuven.be"))
      std::cout << "this should not happen..." << std::endl;
  }
  catch (std::runtime_error * exc)
  {
    std::cout << exc->what() << std::endl;
  }

}
*/

// main for part2
int main()
{
  Management happyScooters(600);
  GPSPos GTBuilding = std::make_pair<std::string, std::string>("50.8760969","4.705526");
  GPSPos Stuk = std::make_pair<std::string, std::string>("50.8757496","4.6990844");
  GPSPos ESAT = std::make_pair<std::string, std::string>("50.8636907","4.6886372");
  happyScooters.addPreferredLocation(GTBuilding);
  happyScooters.addPreferredLocation(Stuk);
  happyScooters.addPreferredLocation(ESAT);
  happyScooters.addScooter(GTBuilding);
  happyScooters.addScooter(GTBuilding);
  happyScooters.addScooter(Stuk);
  auto candidates = happyScooters.giveAvailableScooters(GTBuilding, 100);
  candidates[0]->updateLevel(96.0f);
  candidates = happyScooters.giveAvailableScooters(GTBuilding, 100);
  std::cout << candidates.size() << " possible scooters found" << std::endl;
  for (auto & s : candidates)
    std::cout << s;
  try
  {
    auto lonebiker = std::make_shared<Client>("lone.biker@gmail.com");
    lonebiker->addCredit(25.0f);
    std::cout << std::boolalpha << happyScooters.registerClient(lonebiker) << std::endl;
    auto scoot1 = happyScooters.rentOne(GTBuilding, lonebiker);
    QDateTime momentInFuture = QDateTime::currentDateTime().addSecs(4600);
    scoot1->updateLevel(90.0f);
    scoot1->updatePosition(Stuk);
    std::cout << scoot1;
    std::cout << scoot1->endRenting(momentInFuture) << std::endl;
    std::cout << lonebiker->getEmail() << " has still " << lonebiker->getCredit() << " € credit" << std::endl;
    std::cout << happyScooters.giveAvailableScooters(GTBuilding, 100).size() << std::endl;
    scoot1->updateLevel(85.0f);
    std::cout << scoot1;
    auto lowie = std::make_shared<Client>("louis.tobback@leuven.be");
    lowie->addCredit(1.0f);
    std::cout << std::boolalpha << happyScooters.registerClient(lowie) << std::endl;
    auto scoot2 = happyScooters.rentOne(Stuk, lowie);
    scoot2->updateLevel(10.0f);
    scoot2->updatePosition(std::make_pair<std::string, std::string>("50.885021","4.6994844"));
    std::cout << scoot2->endRenting(momentInFuture.addSecs(7205)) << std::endl;
    lowie->addCredit(5.0f);
    std::cout << scoot2->endRenting(momentInFuture.addSecs(7210)) << std::endl;
    std::cout << scoot2;
    std::cout << std::boolalpha << scoot2->startRenting(lowie, momentInFuture.addSecs(8000)) << std::endl;
    auto pipo = std::make_shared<Client>("louis.tobback@leuven.be");
    if (happyScooters.registerClient(pipo))
      std::cout << "this should not happen..." << std::endl;

    std::string lines[] = {"one.biker@gmail.com",
                           "rubbish89@telenet.be",
                           "x@test",
                           "45#!bb@hotmail.com",
                           "louis.tobback@LEUVEN.be"};

    for (const auto &line : lines) {
            std::cout << line << ": " << std::boolalpha
                      << happyScooters.registerClient(
                             std::make_shared<Client>(line)) << '\n';
    }
  }
  catch (std::runtime_error & exc)
  {
    std::cout << exc.what() << std::endl;
  }

}


/* main for part5
int main()
{
  Management happyVehicles(600);
  GPSPos GTBuilding = std::make_pair<std::string, std::string>("50.8760969","4.705526");
  GPSPos Stuk = std::make_pair<std::string, std::string>("50.8757496","4.6990844");
  GPSPos ESAT = std::make_pair<std::string, std::string>("50.8636907","4.6886372");
  happyVehicles.addPreferredLocation(GTBuilding);
  happyVehicles.addPreferredLocation(Stuk);
  happyVehicles.addPreferredLocation(ESAT);
  //following calls need to be adapted...
  happyVehicles.addVehicle(GTBuilding);
  happyVehicles.addVehicle(GTBuilding);
  happyVehicles.addVehicle(Stuk);
  auto candidates = happyVehicles.giveAvailableVehicles(GTBuilding, 100);
  std::cout << candidates.size() << " possible Vehicles found" << std::endl;
  for (auto & s : candidates)
    std::cout << s;
  try
  {
    auto lonebiker = std::make_shared<Client>("lone.biker@gmail.com", QDate(1996, 5, 23));
    lonebiker->addCredit(25.0f);
    std::cout << std::boolalpha << happyVehicles.registerClient(lonebiker) << std::endl;
    //following call needs to be adapted...
    auto vehic1 = happyVehicles.rentOne(GTBuilding, lonebiker);
    //suppose I wanted to rent a scooter
    std::shared_ptr<Scooter> scoot1 = std::dynamic_pointer_cast<Scooter>(vehic1);
    if (scoot1  != nullptr)
      {
        QDateTime momentInFuture = QDateTime::currentDateTime().addSecs(4600);
        scoot1->updateLevel(90.0f);
        scoot1->updatePosition(Stuk);
        std::cout << std::dynamic_pointer_cast<Vehicle>(scoot1);
        std::cout << scoot1->endRenting(momentInFuture) << std::endl;
        std::cout << lonebiker->getEmail() << " has still " << lonebiker->getCredit() << " € credit" << std::endl;
        std::cout << happyVehicles.giveAvailableVehicles(GTBuilding, 100).size() << std::endl;
        scoot1->updateLevel(85.0f);
        std::cout << std::dynamic_pointer_cast<Vehicle>(scoot1);
      }
    auto lowie = std::make_shared<Client>("louis.tobback@leuven.be", QDate(2002, 1, 14));
    lowie->addCredit(1.0f);
    std::cout << std::boolalpha << happyVehicles.registerClient(lowie) << std::endl;
    //following call needs to be adapted...
    auto vehic2 = happyVehicles.rentOne(Stuk, lowie);
    //suppose I want to rent a motorbike
    std::shared_ptr<MotorBike> scoot2 = std::dynamic_pointer_cast<MotorBike>(vehic2);
    if (scoot2 != nullptr)
      {
        QDateTime momentInFuture = QDateTime::currentDateTime().addSecs(4600);
        scoot2->updatePosition(std::make_pair<std::string, std::string>("50.885021","4.6994844"));
        std::cout << scoot2->endRenting(momentInFuture.addSecs(7205)) << std::endl;
        lowie->addCredit(5.0f);
        std::cout << scoot2->endRenting(momentInFuture.addSecs(7210)) << std::endl;
        std::cout << std::dynamic_pointer_cast<Vehicle>(scoot2);
        std::cout << std::boolalpha << scoot2->startRenting(lowie, momentInFuture.addSecs(8000)) << std::endl;
      }
    auto pipo = std::make_shared<Client>("louis.tobback@leuven.be", QDate(1985, 12, 4));
    if (happyVehicles.registerClient(pipo))
      std::cout << "this should not happen..." << std::endl;
  }
  catch (std::runtime_error & exc)
  {
    std::cout << exc.what() << std::endl;
  }

}
*/
