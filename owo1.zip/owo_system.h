#ifndef OWO_SYSTEM_H
#define OWO_SYSTEM_H
#include <string>
#include <map>
#include <memory>
#include <vector>

class CoursePart;

class OWO_system
{
public:
  OWO_system(std::string name, const int credits);
  bool importCourses(std::string fileName);
  const std::string &getProgramName() const;
  void setProgramName(const std::string &newProgramName);

  int getNrOfCredits() const;
  bool checkCredits() const;
  std::unique_ptr<CoursePart> &getCoursePart(std::string courseCode);
  void addCoursePart(std::string cCode, std::string cName, int sem, int cu, int groups, int cr);

private:
  std::string programName;
  const int nrOfCredits;
  std::map<std::string, std::unique_ptr<CoursePart>> courseParts;
  int convert_helper(std::vector<std::string> & data, int index, std::string err_message);
};

#endif // OWO_SYSTEM_H
