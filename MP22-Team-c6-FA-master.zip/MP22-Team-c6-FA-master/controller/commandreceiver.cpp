#include "commandreceiver.h"

CommandReceiver::CommandReceiver(const QString command, std::pair<int, int> noOfParams, std::function<bool (QStringList)> action, const QString description)
    : command{command}, noOfParams{noOfParams}, action{action}, description{description}
{

}

const QString CommandReceiver::getDescription() const
{
    return QString(command + " - " + description);
}

const QString & CommandReceiver::getCommand() const
{
    return command;
}

bool CommandReceiver::call(const QString message) const
{
    auto list = message.split(u' ');

    if (!list.isEmpty())
    {
        if (list[0].compare(command, Qt::CaseInsensitive) == 0)
        {
            list.removeFirst();

            if (noOfParams.first <= list.size() && list.size() <= noOfParams.second)
                return action(list);
            else
                return false;
        }
        else
            return false;
    }
    else
        return false;
}

QTextStream &operator<<(QTextStream &stream, const CommandReceiver &command)
{
    stream << command.getDescription();
    return stream;
}
