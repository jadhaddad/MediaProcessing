#include "astar.h"
#include "compare.h"
#include <iostream>

AStar::AStar(GameEngine *g) : g{g}
{
    const auto & a = g->getTiles();
    height = g->getWorld()->getRows();
    width = g->getWorld()->getCols();
    matrix.reserve(a.size());

    for(const auto &tile : a)
    {
        auto root = std::make_shared<Node> ();

        root->x = tile->getXPos();
        root->y = tile->getYPos();
        root->cost = tile->getValue() == std::numeric_limits<float>::infinity()?
                    INFINITY : 1 - tile->getValue();
        root->finaldistance = INFINITY;
        root->startdistance = INFINITY;
        root->visited = false;
        root->parent = nullptr;

        matrix.push_back(std::move(root));
    }
}

std::vector<std::unique_ptr<Tile>> AStar::findPath(const QPoint end)
{
    // reset back to original
    std::for_each(matrix.begin(), matrix.end(), [](auto &node)
    {
       node->finaldistance = INFINITY;
       node->startdistance = INFINITY;
       node->visited = false;
       node->parent = nullptr;
    });

    QPoint start = g->getProtagonistLocation();

    //TODO: replace to unique ptr
    auto start_node = findnode(start.x(), start.y());
    auto end_node = findnode(end.x(),end.y());

    start_node->startdistance=0;
    start_node->finaldistance=weight*distance(end_node,start_node);
    int counter = 0;

    std::priority_queue<std::shared_ptr<Node>, std::vector<std::shared_ptr<Node>>,
            compare> listnotvisited;
    listnotvisited.push(start_node);

    while(!listnotvisited.empty() && start_node != end_node)
    {
        start_node = listnotvisited.top();
        if(!listnotvisited.empty() && listnotvisited.top()->visited) listnotvisited.pop();



        start_node->visited=true;
        for (int i= std::max(start_node->x-1,0);i<=std::min(start_node->x+1,width-1);i++){
            for(int j= std::max(start_node->y-1,0);j<=std::min(start_node->y+1,height-1);j++){
                if (((i==start_node->x && j==start_node->y) ||
                        ((i==start_node->x-1 && j==start_node->y-1) ||
                        (i==start_node->x-1 && j==start_node->y+1) ||
                        (i==start_node->x+1 && j==start_node->y-1) ||
                        (i==start_node->x+1 && j==start_node->y+1))) ||                     // no diagonal
                        (i != end_node->x && j != end_node->y && g->hasGameObject(i, j)))   // avoid game object
                    continue;
                auto neighbor = findnode(i,j);
                if(neighbor->cost >5)continue;




                float shorterdistance = start_node->startdistance+ neighbor->cost;

                if(shorterdistance < neighbor->startdistance)
                {
                    counter++;
                    neighbor->parent = start_node;
                    neighbor->startdistance=shorterdistance;
                    neighbor->finaldistance= weight*neighbor->startdistance+ ((1-weight)*distance(neighbor,end_node));
                    //std::cout<<"xpos"<<neighbor->x<<"ypos"<<neighbor->y<<std::endl;
                    //std::cout<<"xpos"<<end_node->x<<"ypos"<<end_node->y<<std::endl;
                    if(!neighbor->visited ) listnotvisited.push(neighbor);
                    neighbor->visited=true;


               }


           }
       }
    }

    std::vector<std::unique_ptr<Tile>> path;
    path.reserve(counter);

    auto p = end_node.get();
    do
    {
        std::unique_ptr<Tile> element = std::make_unique<Tile>(p->x, p->y, p->cost);

        path.push_back(std::move(element));
        p = p->parent.get();
    } while(p != nullptr && p->parent != nullptr);

    return path;
}

float AStar::distance(std::shared_ptr<Node> a, std::shared_ptr<Node> b)
{
    float res = sqrt(pow(a->x - b->x,2)+pow(a->y - b->y,2));
     //std::cout<<"distance calculated:"<<res<<std::endl;
    return res;


}

const std::shared_ptr<Node> AStar::findnode(int posx, int posy)
{
    int pos = posy * width + posx;

    try
    {
        return matrix.at(pos);
    }
    catch (...)
    {
        std::cout << "Crashed at trying to get pos at " << posx << ", " << posy << std::endl;
        return nullptr;
    }
}

void AStar::becomeWall(int index)
{
    matrix.at(index)->cost = INFINITY;
}


