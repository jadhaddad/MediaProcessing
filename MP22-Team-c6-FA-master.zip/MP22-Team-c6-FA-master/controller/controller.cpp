#include "astar.h"
#include "controller.h"

#include <iostream>
#include <string>
#include <algorithm>
#include <ctime>
#include <stdexcept>

void Controller::createHelp()
{
    QString help;
    QTextStream stream(&help);

    stream << "List of commands:";
    for (const auto &command : commands)
        stream << "\n" << *command.second;

    emit appendHistory(help, false);
}

bool Controller::helpSpecific(const QString &command)
{
    try
    {
        const auto &cmd = commands.at(command.toLower());
        emit appendHistory(cmd.get()->getDescription(), false);
        return true;
    }
    catch (...)
    {
        return false;
    }
}

bool Controller::enoughHealthToAttack(float health, const std::unique_ptr<Enemy> &enemy)
{
    float threshold = 0.0f;

    if (dynamic_cast<PEnemy *> (enemy.get()))
        threshold = 3.0f;   // to have enough health from poison damage

    return health > enemy->getValue() + threshold;
}

float Controller::pathCost(const std::vector<std::unique_ptr<Tile> > &path)
{
    if (path.empty()) return 0.0f;

    float sum = 0.0f;
    std::for_each(path.begin(), path.end(), [&sum] (const auto &tile)
    {
        sum += tile->getValue();
    });

    return sum;
}

Controller::Controller(GameEngine *engine) :
    engine{engine}
{
    commands.emplace("up",
                std::make_unique<CommandReceiver>(
                         "up", std::pair<int,int>(0, 1),
                    [=] (QStringList params)
    {
        if (params.size() == 0)
            engine->setProtagonistDirection(1);
        else
        {
            bool ok;
            int n = params.at(0).toInt(&ok);

            if (ok)
                engine->setProtagonistDirection(1, n);
            else
                return false;
        }
        return true;
    },
    "move up. Parameters:\n"
    "\tn number of steps in this direction (Optional)."));

    commands.emplace("left",
                std::make_unique<CommandReceiver>(
                    "left", std::pair<int,int>(0, 1),
                    [=] (QStringList params)
    {
        if (params.size() == 0)
            engine->setProtagonistDirection(4);
        else
        {
            bool ok;
            int n = params.at(0).toInt(&ok);

            if (ok)
                engine->setProtagonistDirection(4, n);
            else
                return false;
        }
        return true;
    },
    "move down. Parameters:\n"
    "\tn number of steps in this direction (Optional)."));

    commands.emplace("right",
                std::make_unique<CommandReceiver>(
                    "right", std::pair<int,int>(0, 1),
                    [=] (QStringList params)
    {
        if (params.size() == 0)
            engine->setProtagonistDirection(2);
        else
        {
            bool ok;
            int n = params.at(0).toInt(&ok);

            if (ok)
                engine->setProtagonistDirection(2, n);
            else
                return false;
        }
        return true;
    },
    "move right. Parameters:\n"
    "\tn number of steps in this direction (Optional)."));

    commands.emplace("down",
                std::make_unique<CommandReceiver>(
                    "down", std::pair<int,int>(0, 1),
                    [=] (QStringList params)
    {
        if (params.size() == 0)
            engine->setProtagonistDirection(3);
        else
        {
            bool ok;
            int n = params.at(0).toInt(&ok);

            if (ok)
                engine->setProtagonistDirection(3, n);
            else
                return false;
        }
        return true;
    },
    "move down. Parameters:\n"
    "\tn number of steps in this direction (Optional)."));

    commands.emplace("goto",
                std::make_unique<CommandReceiver>(
                    "goto", std::pair<int,int>(2, 2),
                    [=] (QStringList params)
    {
        bool ok1, ok2;
        int x = params.at(0).toInt(&ok1);
        int y = params.at(1).toInt(&ok2);

        if (ok1 && ok2)
        {
            if (x < 0 || x >= engine->getWorld()->getCols() ||
                    y < 0 || y >= engine->getWorld()->getRows())
            {
                emit appendHistory("Invalid coordinates.", true);
                return true;
            }

            engine->setPath(findPath(x, y));
            return true;
        }
        else
            return false;
    },
    "go to coordinates. Parameters:\n"
    "\tx x-coordinate (Mandatory).\n"
    "\ty y-coordinate (Mandatory)."));

    commands.emplace("attack",
                     std::make_unique<CommandReceiver>(
                         "attack", std::pair<int,int>(0, 1),
                         [=] (QStringList params)
    {
        if (!params.empty())
        {
            if (params.at(0) == "--safe" || params.at(0) == "-s")
                attackNearestEnemy(true);
            else
                return false;
        }
        else
            attackNearestEnemy(false);

        return true;
    },
    "attack nearest enemy. Flags:\n"
    "\t--safe/-s to also check for health before attacking."));

    commands.emplace("heal",
                     std::make_unique<CommandReceiver>(
                         "heal", std::pair<int,int>(0,1),
                         [=] (QStringList params)
    {
        if (!params.empty())
        {
            QString flag = params.at(0);

            if (flag == "--best" || flag == "-b")
                findBestHealthPack();
            else if (flag == "--nearest" || flag == "-n")
                findNearestHealthPack();
            else
                return false;
        }
        else
            findNearestHealthPack();

        return true;
    },
    "consume a health pack. Flags:\n"
    "\t--nearest/-n to find the nearest health pack (default).\n"
    "\t--best/-b to find the best health pack given protagonist's health."));

    commands.emplace("clear",
                std::make_unique<CommandReceiver>(
                    "clear", std::pair<int,int>(0, 0),
                    [=] (QStringList)
    {
        emit clearHistory();
        return true;
    },
    "clears the terminal."));

    commands.emplace("exit",
                     std::make_unique<CommandReceiver>(
                         "exit", std::pair<int,int>(0, 0),
                         [=] (QStringList)
    {
        emit closeTerminal();
        return true;
    },
    "closes the terminal."));

    commands.emplace("help",
                std::make_unique<CommandReceiver>(
                    "help", std::pair<int,int>(0, 1),
                    [=] (QStringList list)
    {
        if (list.size() == 0)
        {
            createHelp();
            return true;
        }
        else
            return helpSpecific(list.at(0));
    },
    "return a list of commands."));
}

Controller::~Controller()
{
    pathFinders.clear();
    commands.clear();
}

void Controller::openFile(const QString fileName, int noOfEnemies, int noOfHealthPacks)
{
    std::cout << "Opening " << fileName.toStdString() << " with " << noOfEnemies << " enemies and " << noOfHealthPacks << " health packs." << std::endl;
    engine->createWorld(fileName, noOfEnemies, noOfHealthPacks);

    // create path finders
    pathFinders.clear();
    pathFinders.reserve(1);

    auto astar = std::make_unique<AStar>(engine);
    connect(engine, SIGNAL(becomeWall(int)), astar.get(), SLOT(becomeWall(int)));
    pathFinders.emplace_back(std::move(astar));

    if (!manualMode)
        nextMove();
}

void Controller::switchControllerMode(bool manualMode)
{
    this->manualMode = manualMode;

    if (!manualMode)
        nextMove();
}

void Controller::changeWeight(float weight)
{
    for ( auto & pathfinder : pathFinders)
        pathfinder->setWeight(weight/100.0f);
}

std::vector<std::unique_ptr<Tile>> Controller::findPath(int x, int y)
{
    if (engine->isWall(x, y))
    {
        emit appendHistory("Cannot find path to this location.", true);
        return {};  // empty list
    }

    try
    {
        std::cout << "Finding path to " << x << ", " << y << std::endl;

        std::time_t begin = std::clock();

        std::vector<std::unique_ptr<Tile>> path = pathFinders.at(0)->findPath(QPoint(x, y));
        auto duration = 1000 * (std::clock() - begin) / CLOCKS_PER_SEC;

        emit appendHistory(QString("Found path in " + QString::number(duration) + " ms."), false);
        return path;
    }
    catch (...)
    {
        return {};
    }
}

bool Controller::enoughEnergyToGo(int x, int y, float energy)
{
    auto path = findPath(x, y);

    if (path.empty())
        return false;
    else
    {
        float energyCost = pathCost(path);
        if (energyCost > energy)
            return false;
        else
        {
            engine->setPath(std::move(path));
            return true;
        }
    }
}

void Controller::attackNearestEnemy(bool safe)
{
    const auto & enemies = engine->getEnemies();

    if (enemies.empty())
    {
        emit appendHistory("No enemies to attack!", true);
        return;
    }

    std::vector<std::unique_ptr<ObjectDistance>> enemyDistances;
    enemyDistances.reserve(enemies.size());

    // calculate distances
    unsigned int counter = 0;
    for (const auto & enemy : enemies)
    {
        if (!enemy->getDefeated())
        {
            auto path = findPath(enemy->getXPos(), enemy->getYPos());
            if (!path.empty())
                enemyDistances.emplace_back(std::make_unique<ObjectDistance>(counter, path));
        }

        counter++;
    }

    if (enemyDistances.empty())
    {
        emit appendHistory("Found no path to any enemy or all enemies defeated.", true);
        return;
    }

    // sort by cost, ascending
    std::sort(enemyDistances.begin(), enemyDistances.end(), [=] (auto & enemy1, auto & enemy2)
    {
        return pathCost(enemy1->getPathReference()) < pathCost(enemy2->getPathReference());
    });

    // decide which enemy to attack

    float energy = engine->getProtagonistEH().first;
    float health = engine->getProtagonistEH().second;

    for (auto & enemyDistance : enemyDistances)
    {
        if (pathCost(enemyDistance->getPathReference()) < energy)
        {
            if (safe)   // check health before attacking
            {
                const auto & enemy = enemies.at(enemyDistance->getIndex());

                if (enoughHealthToAttack(health, enemy))
                {
                    engine->setPath(enemyDistance->returnPath());
                    return;
                }
            }
            else        // attack no matter health
            {
                engine->setPath(enemyDistance->returnPath());
                return;
            }
        }
    }

    // did not attack any enemy due to out of energy
    emit appendHistory("Not enough health or energy to attack any enemies!", true);
}

bool Controller::findBestHealthPack()
{
    const auto & healthPacks = engine->getHealthPacks();

    if (healthPacks.empty())
    {
        emit appendHistory("No health pack to consume.", true);
        return false;
    }

    const auto energyHealth = engine->getProtagonistEH();
    auto healthDifferences = std::vector<std::unique_ptr<HealthPackDiference>>();
    healthDifferences.reserve(healthPacks.size());

    // create a sorted list of best health packs to choose
    unsigned int counter = 0;
    for (const auto & health : healthPacks)
    {
        if (health->getValue() != 0)    // not already consumed
            healthDifferences.emplace_back(std::make_unique<HealthPackDiference>(counter,
                                                                                 health->getValue(),
                                                                                 energyHealth.second));
        counter++;
    }

    std::sort(healthDifferences.begin(), healthDifferences.end(), [](auto &health1, auto &health2)
    {
       return health1->healthDifference < health2->healthDifference;
    });

    for (const auto &healthDifference : healthDifferences)
    {
        const auto &healthPack = healthPacks.at(healthDifference->healthPackIndex);
        if (enoughEnergyToGo(healthPack->getXPos(), healthPack->getYPos(), energyHealth.first))
        {
            emit appendHistory("Getting health at " +
                               QString::number(healthPack->getXPos()) + ", " +
                               QString::number(healthPack->getYPos()), false);
            return true;
        }
    }

    emit appendHistory("Not enough energy to consume any health pack!", true);
    return false;   // found nothing
}

void Controller::findNearestHealthPack()
{
    const auto & healthPacks = engine->getHealthPacks();

    if (healthPacks.empty())
    {
        emit appendHistory("No health pack to consume.", true);
        return;
    }

    std::vector<std::unique_ptr<ObjectDistance>> healthDistances;
    healthDistances.reserve(healthPacks.size());

    unsigned int count = 0;
    for (const auto & healthPack : healthPacks)
    {
        if (healthPack->getValue() != 0)
        {
            auto path = findPath(healthPack->getXPos(), healthPack->getYPos());
            if (!path.empty())
                healthDistances.emplace_back(std::make_unique<ObjectDistance>(count, path));
        }

        count++;
    }

    // check
    if (healthDistances.empty())
    {
        emit appendHistory("Found no path to any health packs or all health packs consume.", true);
        return;
    }

    // find closest health pack
    auto closest = std::min_element(healthDistances.begin(), healthDistances.end(), [=] (auto &health1, auto &health2)
    {
       return pathCost(health1->getPathReference()) < pathCost(health2->getPathReference());
    })->get();

    if (pathCost(closest->getPathReference()) < engine->getProtagonistEH().first)
    {
        const auto & healthPack = healthPacks.at(closest->getIndex());
        emit appendHistory("Getting health at " +
                           QString::number(healthPack->getXPos()) + ", " +
                           QString::number(healthPack->getYPos()),
                           false);

        engine->setPath(closest->returnPath());
    }
    else
        emit appendHistory ("Don't have enough energy to go to the nearest health pack.", true);
}

void Controller::nextMove()
{
    if (!manualMode && engine->isRunning())
    {
        const auto & enemies = engine->getEnemies();    // list of enemies already sorted by strength, descending
        const auto energyHealth = engine->getProtagonistEH();

        for (const auto & enemy : enemies)
        {
            if (enemy->getDefeated()) continue; // already defeated

            if (enoughHealthToAttack(energyHealth.second, enemy))    // enough health, find path to enemy
            {
                if (enoughEnergyToGo(enemy->getXPos(), enemy->getYPos(), energyHealth.first))    // enough energy to go and attack enemy
                {
                    emit appendHistory("Attacking enemy at " +
                                       QString::number(enemy->getXPos()) + ", " +
                                       QString::number(enemy->getYPos()),
                                       false);
                    return;
                }
                else
                    continue;  // not enough energy to go to enemy, find next enemy
            }
            else if (energyHealth.second < GameEngine::maxEH)  // find a health pack
            {
                if (findBestHealthPack())
                    return;
            }
        }

        emit appendHistory("No more moves available!", true);
        emit exitAutoMode();    // switch back to manual mode
        manualMode = true;
    }
}

void Controller::commandLine(const QString command)
{
    try
    {
        auto list = command.split(u' ');
        const auto &cmd = commands.at(list.at(0).toLower());
        if (!cmd->call(command))
            throw std::invalid_argument("Command failed.");
    }
    catch (...)
    {
        emit appendHistory("Unkown command.", false);
        createHelp();
    }
}

void Controller::autoComplete(const QString command)
{
    int length = command.length();
    if (length > 0)
    {
        bool full = false;
        auto found = std::find_if(commands.begin(), commands.end(), [&command, &length, &full](const auto & receiver)
        {
            auto compare = receiver.second->getCommand();

            if (compare == command) // full command already written, show specific help
            {
                full = true;
                return true;
            }
            else if (compare.left(length) == command)   // not full, autocomplete
                return true;
            else
                return false;
        });

        if (found == commands.end())
            emit appendHistory("Unkown command. Enter help for full list of commands", true);
        else if (full)
            helpSpecific(command);
        else
            emit setCommand(found->second->getCommand());
    }
}
