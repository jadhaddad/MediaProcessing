#ifndef COMMANDRECEIVER_H
#define COMMANDRECEIVER_H

#include <functional>
#include <tuple>
#include <any>

#include <QStringList>
#include <QString>
#include <QTextStream>

class CommandReceiver
{
public:
    CommandReceiver(const QString command,
                    std::pair<int, int> noOfParams,
                    std::function<bool(QStringList)> action,
                    const QString description);

    const QString getDescription() const;
    const QString & getCommand() const;
    bool call(const QString message) const;

private:
    const QString command;
    std::pair<int, int> noOfParams; // first: lower bounds, inclusive. second: upper bounds, inclusive
    std::function<bool(QStringList)> action;
    const QString description;
};

QTextStream &operator<<(QTextStream &stream, const CommandReceiver &command);

#endif // COMMANDRECEIVER_H
