#ifndef NODE_H
#define NODE_H
#include <world.h>

class Node
{
public:
    Node()
    {

    }

    int x;
    int y;
    float cost;
    bool visited = false;  //is this tile visited before
    float  finaldistance{} ; //distance to  the destination tile
    float startdistance{};  //distance to the start tile

    std::shared_ptr<Node> parent = nullptr;

};

#endif // NODE_H
