#ifndef CONTROLLER_H
#define CONTROLLER_H

#include "model/gameengine.h"
#include "commandreceiver.h"
#include "pathfinder.h"

#include <QObject>
#include <map>

/**
 * @brief The HealthPackDiference class For autoplay. Want to find the best health pack, i.e. not too small/too big to reach
 * back to maximum health.
 */
struct HealthPackDiference
{
    HealthPackDiference(unsigned int index, float healthPackValue, float protagonistHealth)
        : healthPackIndex {index},
          healthDifference{abs((GameEngine::maxEH - protagonistHealth) - healthPackValue)} { }

    unsigned int healthPackIndex;      // where the health pack is in the vector
    float healthDifference;             // desired health - health pack value. The smaller, the better
                                        // math.abs((100.0f - protagonistHealth) - healthValue
};

/**
 * @brief The EnemyDistance class Store the index of the game object and its energy cost to get there.
 */
class ObjectDistance
{
public:
    ObjectDistance(unsigned int index, std::vector<std::unique_ptr<Tile>> &path) :
        enemyIndex{index}, path{std::move(path)} { }

    unsigned int getIndex() const { return enemyIndex; }
    std::vector<std::unique_ptr<Tile>> returnPath() { return std::move(path); }
    const std::vector<std::unique_ptr<Tile>> &getPathReference() const { return path; }

private:
    unsigned int enemyIndex;
    std::vector<std::unique_ptr<Tile>> path;
};

class Controller : public QObject
{
    Q_OBJECT

private:
    bool manualMode = true;
    GameEngine *engine;
    std::map<QString, std::unique_ptr<CommandReceiver>> commands;
    std::vector<std::unique_ptr<PathFinder>> pathFinders;

    /**
     * @brief createHelp Iterate through the commands description and append to command history.
     */
    void createHelp();

    /**
     * @brief helpSpecific Return the description of given command.
     * @param command Name of command.
     * @return False if no command with that name.
     */
    bool helpSpecific(const QString &command);

    /**
     * @brief enoughHealthToAttack Checks protagonist health and type of enemy and decide if it's safe to attack.
     * @param health Health of protagonist.
     * @param enemy Reference to enemy.
     * @return True if safe to attack.
     */
    bool enoughHealthToAttack(float health, const std::unique_ptr<Enemy> &enemy);

    /**
     * @brief pathCost Calculate the energy cost of a given path
     * @param path Reference to path
     * @return the total cost for the path
     */
    float pathCost(const std::vector<std::unique_ptr<Tile>> &path);

    /**
     * @brief enoughEnergyToGo Find a path to x and y while checking its energy cost before going.
     * Calls the setPath function if valid.
     * @param x
     * @param y
     * @param energy Energy of the protagonist
     * @return True if protagonist has enough energy, false if invalid path/not enough energy.
     */
    bool enoughEnergyToGo(int x, int y, float energy);

    /**
     * @brief attackNearestEnemy Find the nearest enemy (energy wise) and attack it
     * @param safe If true, attack the nearest enemy that is defeatable.
     */
    void attackNearestEnemy(bool safe);

    /**
     * @brief findBestHealthPack Find the best health pack and go to it.
     * @return Returns true if found the best health pack.
     */
    bool findBestHealthPack();

    /**
     * @brief findNearestHealthPack Find closest unconsumed health pack in terms of cost.
     */
    void findNearestHealthPack();

public:
    Controller(GameEngine* engine);
    ~Controller();

    std::vector<std::unique_ptr<Tile>> findPath(int x, int y);

public slots:
    /**
     * @brief openFile Initialise world and set up path finding
     * @param fileName The absolute path of the map file
     * @param noOfEnemies Number of enemies that will spawn
     * @param noOfHealthPacks Number of healthpacks that will spawn
     */
    void openFile(const QString fileName, int noOfEnemies, int noOfHealthPacks);

    void switchControllerMode(bool manualMode);

    void changeWeight(float weight);
    /**
     * @brief nextMove Communicate with the game engine to find the next move in auto play mode.
     *
     * Called when:
     * 1. manualMode set to false
     * 2. Protagonist attacked an enemy
     * 3. Protagonist consumed a health pack
     * 4. Protagonist finished a path.
     *
     * Method:
     * 1. Get a list of enemies sorted by strength descending. Always try to fight the hardest enemies first when have a lot of health packs.
     * 2. Iterate through the undefeated enemy list. For each enemy:
     *  a. If enough health to attack enemy:
     *      i. Find path to enemy
     *      ii. Check if protagonist have enough energy to complete the path to enemy
     *          > If enough energy, go to the enemy and attack, exit function
     *          > If not enough energy, continue on the enemy list.
     *  b. If not enough health to attack this enemy:
     *      i. Get a list of unconsumed health packs
     *      ii. Sort list into best to worst health packs.
     *          > Best health packs are the ones that replenish the health closest to 100
     *          > Prevent wasting big health packs for no reason
     *          > Formula: |(current_health - 100) - health_pack_value|
     *          > The smaller the result from formula, the better the health pack.
     *      iii. Iterate through health pack
     *          > Find path to health pack
     *          > Calculate energy required to go
     *          > If have enough energy, go to that health pack, exit function
     *          > If not, continue down the list.
     * 3. If it got to this point, cannot find a good next move, exit auto mode.
     */
	void nextMove();

    /**
     * @brief commandLine Called when the command line has a new command entered
     * @param command The command entered
     */
    void commandLine(const QString command);

    /**
     * @brief autoComplete Autocomplete the given command.
     * @param command The command tabbed
     */
    void autoComplete(const QString command);

signals:    
    // signals below connected to visualisation, see visualisation.h.
    void setCommand(QString string);
    void appendHistory(QString string, bool critical);
    void clearHistory();
    void closeTerminal();
    void exitAutoMode(bool manualMode = true);
};

#endif
