#ifndef ASTAR_H
#define ASTAR_H

#include  <world.h>
#include <memory>
#include "node.h"
#include "pathfinder.h"
#include "model/gameengine.h"
#include <queue>

class AStar : public PathFinder
{
    Q_OBJECT
public:
    AStar(GameEngine * g);
    std::vector<std::unique_ptr<Tile>> findPath(const QPoint end) override;

    float distance(std::shared_ptr<Node> x, std::shared_ptr<Node> y);
    const std::shared_ptr<Node> findnode(int posx,int posy);
    std::vector<std::shared_ptr<Node>> matrix;

    float getWeight() const;
    void setWeight(float newWeight);

public slots:
    void becomeWall(int index) override;

private:
    GameEngine * g;

    int height{4};
    int width{4};

};

#endif
