#ifndef COMPARE_H
#define COMPARE_H
#include "node.h"

class compare
{
public:
    bool operator()( const std::shared_ptr<Node> current, const std::shared_ptr<Node> end)
    {
        return current->finaldistance > end->finaldistance;
    }
};

#endif // COMPARE_H
