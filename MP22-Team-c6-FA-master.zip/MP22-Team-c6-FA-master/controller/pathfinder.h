#ifndef PATHFINDER_H
#define PATHFINDER_H

#include <QObject>
#include <world.h>

class PathFinder : public QObject
{
    Q_OBJECT

public:
    virtual std::vector<std::unique_ptr<Tile>> findPath(const QPoint end) = 0;
    float weight = 0;

    float getWeight() const;
    void setWeight(float newWeight);

public slots:
    virtual void becomeWall(int index) = 0;
};

inline float PathFinder::getWeight() const
{
    return weight;
}

inline void PathFinder::setWeight(float newWeight)
{
    weight = newWeight;
}

#endif
