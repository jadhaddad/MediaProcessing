#ifndef GAMEENGINE_H
#define GAMEENGINE_H

#include <QObject>
#include <QTimer>

#include <memory>

#include <world.h>

#include "visualisation/visualisation.h"
#include "tileeffect.h"

class GameEngine : public QObject
{
    Q_OBJECT
private:
    std::unique_ptr<World> world;
    std::vector<std::unique_ptr<Tile>> tiles;
    /**
     * @brief tileEffects Same size as tiles.
     * If a game object is at that tile position, puts the index of that game object from own vector.
     * If tile is poisoned/on fire, set effect flag
     */
    std::vector<std::unique_ptr<TileContainer>> tileEffects;
    std::vector<std::unique_ptr<Enemy>> enemiesList;
    std::vector<std::unique_ptr<Tile>> healthPackList;
    std::unique_ptr<Protagonist> protagonist;
    /**
     * @brief path The tiles the protagonist will take.
     */
    std::vector<std::unique_ptr<Tile>> path;
    /**
     * @brief poisonedTile Tiles that are poisoned around the PEnemy.
     * Value used as poison lifetime (4 at start), decreases each game cycle.
     */
    std::vector<std::unique_ptr<Tile>> poisonedTiles;

    /**
     * @brief fireTile Tile on fire from XEnemy.
     * Moved with slot onXEnemyMoved and set with onXEnemyFire.
     */
    std::unique_ptr<Tile> fireTile;

    QTimer * gameLoop;
    Visualisation *visualisation;

    // previous position of protagonist
    int oldX, oldY;

    /**
     * @brief protagonistDirection
     * 0 - stay still, 1 - up, 2 - right, 3 - down, 4 - left.
     */
    int protagonistDirection = 0;
    /**
     * @brief directionCounter How many steps in that direction.
     */
    int directionCounter = 0;

    bool gameRunning = false;

    /**
     * @brief getPosition Get the index of a tile from the x y coordinate
     * @param x x coordinates
     * @param y y coordinates
     * @return index in vector
     */
    int getPosition(int x, int y) const;

    /**
     * @brief spawnProtagonist
     * Spawn protagonist in a tile where the value is not inf
     */
    void spawnProtagonist();

    /**
     * @brief moveProtagonist
     * Move protagonist with WASD or if there is a path, move with path.
     * If current tile the protagonist is on is a wall (e.g. just defeated an enemy), move back to previous position.
     */
    void moveProtagonist();

    /**
     * @brief moveProtagonist Move protagonist to new position, save old position
     * @param x game coordinate x
     * @param y game coordinate y
     */
    void moveProtagonist(int x, int y);

    /**
     * @brief visualiseMap Initialise game manager and map background
     */
    void visualiseMap();

    void spawnHealthPacks();

    /**
     * @brief spawnEnemies
     * Sorts enemy by strength
     * Spawn all enemies and convert an Enemy to XEnemy if possible.
     */
    void spawnEnemies();

    /**
     * @brief reset Reset the whole world by resetting all pointers.
     * Calls the visualisation reset.
     */
    void reset();

    /**
     * @brief findCollision Check if there are any other items the protagonist is on.
     * Uses the tileEffects vector to check what type of tile the enemy is on.
     * Sends flags to the visualisation (check tileeffect.h)
     */
    void findCollision();

    /**
     * @brief checkGameStatus Check if game win / lose.
     */
    void checkGameStatus();

    /**
     * @brief updatePoison Goes through the poisoned tile list, decrease its lifetime clear if necessary
     */
    void updateEffects();

public:
    GameEngine(Visualisation *visualisation);
    ~GameEngine();
    void createWorld(const QString filename, unsigned int nrOfEnemies, unsigned int nrOfHealthpacks);

    static float maxEH;
    bool godmode = false;
    QPoint getProtagonistLocation() const;

    /**
     * @brief getProtagonistEH
     * @return returns a pair: first energy and second health of protagonist
     */
    const std::pair<int,int> getProtagonistEH() const;

    const std::vector<std::unique_ptr<Tile>> &getTiles() const;

    /**
     * @brief isWall Check if a given tile is a wall.
     * @param x game coordinate x
     * @param y game coordinate y
     * @return  True if wall
     */
    bool isWall(int x, int y) const;

    /**
     * @brief hasGameObject Check if tile has game object (health pack/enemy)
     * @param x game coordinate x
     * @param y game coordinate y
     * @return True if has game object
     */
    bool hasGameObject(int x, int y) const;

    const std::unique_ptr<World> &getWorld() const;

    const std::vector<std::unique_ptr<Enemy>> &getEnemies() const;

    const std::vector<std::unique_ptr<Tile>> &getHealthPacks() const;

    /**
     * @brief isRunning
     * @return True if game is running
     */
    bool isRunning() const;

    /**
     * @brief setPath Sets the path the protagonist will take.
     * @param path Vector of tiles the protagonist will move to.
     * Vector is reversed: the back of the vector is where the protagonist will move to next.
     * Path is moved into the path member variable.
     */
    void setPath(std::vector<std::unique_ptr<Tile>> path);

    /**
     * @brief setProtagonistDirection move protagonist in direction
     * @param direction 0 stay still, 1 up, 2 right, 3 down, 4 left
     * @param count How long it will stay in this direction
     */
    void setProtagonistDirection(int direction, int count = 1);

    bool getGodmode() const;
    void setGodmode(bool newGodmode);

signals:
    /**
     * @brief consumeHealth Sends the coordinates of a health pack when it is consumed.
     * @param gameCoors Coordinates of the health pack.
     */
    void consumeHealth(const QPoint gameCoors);
    /**
     * @brief becomeWall Tile on where enemies die becomes impassable, used to update pathfinding.
     * @param index Index of the tile
     */
    void becomeWall(const int index);

    /**
     * @brief moveDone Signals when move is done, i.e. enemy attacked or health pack consumed.
     */
    void moveDone();

public slots:
    /**
     * @brief gameUpdate
     * Does all necessary game updates, called every game loop
     */
    void gameUpdate();
    /**
     * @brief changeRefreshRate updates how quickly the objects move in the world
     * @param refreshRate default 100 ms
     */
    void changeRefreshRate(int refreshRate);
    /**
     * @brief poisonSurrounding gets the sender object, add (or reuse) surrounding tiles to poisonedTiles
     * @param poisonLevel poisonLevel of PEnemy
     */
    void poisonSurrounding(int poisonLevel);
    /**
     * @brief onXEnemyMoved moves fire tiles above XEnemy. Also update the tileEffects vector.
     * @param x game coordinate x
     * @param y game coordinate y
     */
    void godModeEnergy(bool godmode);
    void onXEnemyMoved(int x, int y);
    void onXEnemyFire();
};

#endif
