#include "xenemy.h"
#include "gameengine.h"

#include <iostream>

XEnemy::XEnemy(int xPosition, int yPosition, float strength, const GameEngine *engine):
    Enemy(xPosition, yPosition, strength), engine{engine}
{
    nextMove();
}

void XEnemy::nextMove() {
    srand(time(nullptr));

    if (getDefeated())
        return;

    int walk = rand() % 2;  // 50% walk, 50% stay still and fire

    if (walk)
    {
        emit walkChanged(true);
        direction = rand() % (4 - 1 + 1) + 1;   // directions (1 to 4)
        count = 0;
        countTo = rand() % (30 - 5 + 1) + 5;    // how many steps in this direction
    }
    else
    {
        emit fire();
        direction = 0;  // stay still
    }

    int t = rand() % (5 - 2 + 1) + 2;  // random time 2 - 5 seconds
    QTimer::singleShot(t*1000, this, SLOT(nextMove()));
}

void XEnemy::nextLoop()
{
    if (getDefeated())
        disconnect(sender(), 0, this, 0);

    if (count >= countTo)
    {
        emit walkChanged(false);
        count = 0;
        direction = 0;
    }

    if (direction != 0)
    {
        int newX = xPos, newY = yPos;

        switch (direction)
        {
        case 1: // up
            newY--;
            break;
        case 2: // right
            newX++;
            break;
        case 3: // down
            newY++;
            break;
        case 4: // left
            newX--;
            break;
        }

        if (newX < 0 || newX >= engine->getWorld()->getCols() ||     // out of bounds
                newY < 1 || newY >= engine->getWorld()->getRows() ||    // don't want fire out of bounds
                engine->hasGameObject(newX, newY))                   // don't go over game object
        {
            direction = (direction + 2) % 4;    // opposite direction
            if (direction == 0) direction = 4;
            return;
        }

        int pos = newY * engine->getWorld()->getCols() + newX;
        auto &tile = engine->getTiles().at(pos);

        if (tile->getValue() != std::numeric_limits<float>::infinity())
        {
            this->setPos(newX, newY);
            count++;
        }
        else    // hit a wall
        {
            direction = (direction + 2) % 4;
            if (direction == 0) direction = 4;
            return;
        }
    }
    else
        count++;
}
