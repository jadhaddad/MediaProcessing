#ifndef TILEEFFECT_H
#define TILEEFFECT_H

enum class GameObjectType : unsigned char
{
    NO_OBJECT =     0,
    HEALTH_PACK =   1,
    ENEMY =         2
};

// enemy effects
constexpr unsigned char ON_FIRE   {0b00000001};
constexpr unsigned char POISONED  {0b00000010};

// protagonist effect
constexpr unsigned char ATTACK    {0b10000000};
constexpr unsigned char HEAL      {0b01000000};
constexpr unsigned char DEAD      {0b00100000};

struct TileContainer
{
    GameObjectType type = GameObjectType::NO_OBJECT;
    unsigned int index = 0;
    unsigned char effectFlags = 0;
};

#endif // TILEEFFECT_H
