#include <iostream>
#include <algorithm>

#include "gameengine.h"
#include "xenemy.h"

float GameEngine::maxEH = 100.0f;

int GameEngine::getPosition(int x, int y) const
{
    return y * world->getCols() + x;
}

void GameEngine::spawnProtagonist()
{
    int x_protagonist = protagonist->getXPos();
    int y_protagonist = protagonist->getYPos();
    int pos = getPosition(y_protagonist, x_protagonist);
    float value = tiles.at(pos)->getValue();

    while (value == std::numeric_limits<float>::infinity())
    {
        std::cout << "Protagonist in a black tile, shifting..." << std::endl;
        x_protagonist++;
        y_protagonist++;
        pos = y_protagonist * world->getCols() + x_protagonist;
        value = tiles.at(pos)->getValue();
    }

    protagonist->setPos(x_protagonist, y_protagonist);
    oldX = x_protagonist;
    oldY = y_protagonist;

    visualisation->updateProtagonist(protagonist);
}

void GameEngine::moveProtagonist()
{
    int x = protagonist->getXPos();
    int y = protagonist->getYPos();
    int cols = world->getCols();
    int rows = world->getRows();

    if (tiles.at(cols * y + x)->getValue() == std::numeric_limits<float>::infinity())   // retract back to old pos
    {
        protagonist->setPos(oldX, oldY);
        return;
    }
    else if (path.empty() && protagonistDirection != 0 &&
             directionCounter > 0)   // move with WASD
    {
        switch (protagonistDirection)
        {
        case 1: // up
            y = (y - 1 > 0)? y - 1 : 0;
            break;
        case 2: // right
            x = (x + 1 < cols - 1)? x + 1 : cols - 1;
            break;
        case 3: // down
            y = (y + 1 < rows - 1)? y + 1 : rows - 1;
            break;
        case 4: // left
            x = (x - 1 > 0)? x - 1 : 0;
            break;
        }
        directionCounter--;
        if (directionCounter == 0)
            protagonistDirection = 0;
    }
    else if (!path.empty())    // move with path
    {
        protagonistDirection = 0;   // ignore any input
        auto &tile = path.back();
        x = tile->getXPos();
        y = tile->getYPos();
        path.pop_back();

        if (path.empty())   // finished move
            emit moveDone();
    }
    else
        return;

    int pos = getPosition(x, y);
    auto &tile = tiles.at(pos);
    float energyCost = 1.0f - tile->getValue();

    if (tile->getValue() == std::numeric_limits<float>::infinity())
    {
        std::cout << "Hit a wall" << std::endl;
    }
    else if (energyCost > protagonist->getEnergy() && !godmode)
    {
        path.clear();
        visualisation->appendHistory("Cannot move to this tile, out of energy!", true);
    }
    else
    {
        if (godmode == true)
            protagonist->setEnergy(100);
        else{
            float newEnergy = protagonist->getEnergy() - energyCost;
            protagonist->setEnergy(newEnergy);
        }
        moveProtagonist(x, y);
    }
}

void GameEngine::moveProtagonist(int x, int y)
{
    oldX = protagonist->getXPos();
    oldY = protagonist->getYPos();
    protagonist->setPos(x, y);
}

void GameEngine::visualiseMap()
{
    tileEffects.reserve(tiles.size());
    for (unsigned int i = 0; i < tiles.size(); i++)
        tileEffects.emplace_back(std::make_unique<TileContainer>());    // new blank object

    visualisation->drawMapTiles(tiles, world);
}

void GameEngine::spawnHealthPacks()
{
    if (healthPackList.empty()) return;

    int counter = 0;
    for (const auto& healthPack : healthPackList)
    {
        int pos = getPosition(healthPack->getXPos(), healthPack->getYPos());
        auto &object = tileEffects.at(pos);
        object->type = GameObjectType::HEALTH_PACK;
        object->index = counter;
        counter++;
    }

    visualisation->updateHealthPacks(healthPackList, protagonist);
}

void GameEngine::spawnEnemies()
{
    if (enemiesList.empty()) return;

    {   // sort by strength, descending
        std::sort(enemiesList.begin(), enemiesList.end(), [](auto &enemy1, auto &enemy2)
        {
            return enemy1->getValue() > enemy2->getValue();
        });
    }

    {   // add to object list
        int counter = 0;
        for (const auto& enemy : enemiesList)
        {
            int pos = getPosition(enemy->getXPos(), enemy->getYPos());
            auto &object = tileEffects.at(pos);
            object->type = GameObjectType::ENEMY;
            object->index = counter;
            counter++;
        }
    }

    {   // create XEnemy
        int random = rand() % enemiesList.size();     // get random from 0 to enemy size
        unsigned long long counter = 0;
        while (dynamic_cast<PEnemy*> (enemiesList.at(random).get()) &&  // don't convert PEnemy
               enemiesList.at(random)->getYPos() == 0 &&                // don't spawn on y = 0
               counter < enemiesList.size())                            // can't find enemy
        {
            random = rand() % enemiesList.size();
            counter++;
        }

        if (counter < enemiesList.size())
        {
            auto &oldEnemy = enemiesList.at(random);

            auto xEnemy = new XEnemy(oldEnemy->getXPos(), oldEnemy->getYPos(), oldEnemy->getValue(), this);
            connect(xEnemy, SIGNAL(posChanged(int,int)), this, SLOT(onXEnemyMoved(int,int)));
            connect(xEnemy, SIGNAL(fire()), this, SLOT(onXEnemyFire()));
            connect(gameLoop, SIGNAL(timeout()), xEnemy, SLOT(nextLoop()));

            fireTile = std::make_unique<Tile>(xEnemy->getXPos(), xEnemy->getYPos() - 1, 0);

            enemiesList.at(random).reset(xEnemy); // delete old enemy and swap with xenemy
        }
        else
            visualisation->appendHistory("Unable to create XEnemy", true);
    }

    // connect PEnemy to game engine
    for (auto &enemy : enemiesList)
    {
        if (auto pEnemy = dynamic_cast<PEnemy*> (enemy.get()))
            connect(pEnemy, SIGNAL(poisonLevelUpdated(int)), this, SLOT(poisonSurrounding(int)));
    }

    // send to visualisation
    visualisation->updateEnemies(enemiesList);
}

void GameEngine::reset()
{
    gameLoop->stop();
    gameRunning = false;

    tiles.clear();
    tileEffects.clear();
    poisonedTiles.clear();
    enemiesList.clear();
    healthPackList.clear();
    protagonist.reset();
    path.clear();
    fireTile.reset();

    visualisation->resetWorld();
}

void GameEngine::findCollision()
{
    int protagonistPos = getPosition(protagonist->getXPos(), protagonist->getYPos());
    auto & gameObject = tileEffects.at(protagonistPos);

    // on tiles with effects (can be simultaneous)
    char effect = 0;
    if (gameObject->effectFlags & POISONED)
    {
        float newHealth = protagonist->getHealth() - 1;
        if (newHealth <= 0 && !godmode)
        {
            newHealth = 0;
            effect |= DEAD;
        }
        protagonist->setHealth(newHealth);
        effect |= POISONED;
    }
    if (gameObject->effectFlags & ON_FIRE)
    {
        float newHealth = protagonist->getHealth() - 5;
        if (newHealth <= 0 && !godmode)
        {
            newHealth = 0;
            effect |= DEAD;
        }
        protagonist->setHealth(newHealth);
        effect |= ON_FIRE;
    }

    // hit game objects (unique)
    if (gameObject->type == GameObjectType::HEALTH_PACK)
    {
        auto &health = healthPackList.at(gameObject->index);
        if (health->getValue() == 0) return; // already consumed

        int newHealth = protagonist->getHealth() + health->getValue();
        if (newHealth > maxEH) newHealth = maxEH;
        protagonist->setHealth(newHealth);
        health->setValue(0);

        visualisation->refreshScene();
        effect |= HEAL;
    }
    else if (gameObject->type == GameObjectType::ENEMY)
    {
        auto &enemy = enemiesList.at(gameObject->index);
        if (!enemy->getDefeated())
        {
            if (enemy->getValue() - protagonist->getHealth() < 0)   // enemy defeated
            {
                protagonist->setEnergy(maxEH);
                protagonist->setHealth(protagonist->getHealth() - enemy->getValue());
                enemy->setDefeated(true);
                tiles.at(protagonistPos)->setValue(std::numeric_limits<float>::infinity()); // make tile impassable
                emit becomeWall(protagonistPos);

                if (auto *pEnemy = dynamic_cast<PEnemy*> (enemy.get()))
                    pEnemy->poison();   // trigger poisoning
                else
                    effect |= ATTACK;
            }
            else if (!godmode)    // protagonist defeated
            {
                protagonist->setHealth(0);
                protagonist->setPos(oldX, oldY);
                effect |= DEAD;
            }
        }

        visualisation->refreshScene();
    }

    if (godmode)
        protagonist->setHealth(100);

    if (effect != 0)
    {
        emit visualisation->onProtagonistEffect(effect);

        if (effect & ATTACK || effect & HEAL || effect & ON_FIRE || effect & POISONED)
            emit moveDone();    // damage done / heal, calculate next move
    }
}

void GameEngine::checkGameStatus()
{
    if (gameRunning)
    {
        if (protagonist->getHealth() <= 0 || protagonist->getEnergy() <= 0)
        {   // out of health, energy
            visualisation->endGame(false);
            gameRunning = false;
        }
        else if (!enemiesList.empty() &&
                 std::find_if(enemiesList.begin(), enemiesList.end(), [] (const auto &enemy) { return !enemy->getDefeated(); }) ==
                 enemiesList.end())
        {   // no more enemy left
            visualisation->endGame(true);
            gameRunning = false;
        }
    }
}

void GameEngine::updateEffects()
{
    // fire tile
    if (fireTile)
    {
        int firePos = getPosition(fireTile->getXPos(), fireTile->getYPos());
        auto &fire = tileEffects.at(firePos);

        if (fireTile->getValue() > 0)
        {
            int newValue = fireTile->getValue() - 1;
            fireTile->setValue(newValue);
            fire->effectFlags |= ON_FIRE;   // set fire flag
        }
        else
            fire->effectFlags &= ~ ON_FIRE; // reset fire flag
    }

    // poisoned tiles
    if (poisonedTiles.empty()) return;

    int count = 0;

    for (auto &tile : poisonedTiles)
    {
        int tilePos = getPosition(tile->getXPos(), tile->getYPos());

        if (tile->getValue() > 0)
        {
            int newValue = tile->getValue() - 1;
            tile->setValue(newValue);
            tileEffects.at(tilePos)->effectFlags |= POISONED;   // set poisoned flag
            count++;
        }
        else
            tileEffects.at(tilePos)->effectFlags &= ~ POISONED; // reset poisoned flag
    }

    if (count == 0)
        poisonedTiles.clear();
}

GameEngine::GameEngine(Visualisation *visualisation) :
    visualisation{visualisation}
{
    world = std::make_unique<World> ();
    gameLoop = new QTimer;
    gameLoop->setInterval(100);
    connect(gameLoop, SIGNAL(timeout()), this, SLOT(gameUpdate()));
}

GameEngine::~GameEngine()
{
    reset();
    gameLoop->deleteLater();
    world.reset();
}

void GameEngine::createWorld(const QString filename, unsigned int nrOfEnemies, unsigned int nrOfHealthpacks)
{
    reset();

    world->createWorld(filename, nrOfEnemies, nrOfHealthpacks);
    tiles = world->getTiles();
    enemiesList = world->getEnemies();
    poisonedTiles.reserve(nrOfEnemies * 0.25f * 9);      // reserve enough poison tiles for all PEnemies
    healthPackList = world->getHealthPacks();
    protagonist = world->getProtagonist();

    visualiseMap();
    spawnProtagonist();
    spawnHealthPacks();
    spawnEnemies();

    gameLoop->start();
    gameRunning = true;
}

bool GameEngine::getGodmode() const
{
    return godmode;
}

void GameEngine::setGodmode(bool newGodmode)
{
    godmode = newGodmode;
}

QPoint GameEngine::getProtagonistLocation() const
{
    return QPoint(protagonist->getXPos(), protagonist->getYPos());
}

const std::pair<int, int> GameEngine::getProtagonistEH() const
{
    return std::pair<int,int> {protagonist->getEnergy(), protagonist->getHealth()};
}

const std::vector<std::unique_ptr<Tile> > &GameEngine::getTiles() const
{
    return tiles;
}

bool GameEngine::isWall(int x, int y) const
{
    int pos = getPosition(x, y);
    if (tiles.at(pos)->getValue() == std::numeric_limits<float>::infinity())
        return true;
    else
        return false;
}

bool GameEngine::hasGameObject(int x, int y) const
{
    return tileEffects.at(getPosition(x, y))->type != GameObjectType::NO_OBJECT;
}

const std::unique_ptr<World> &GameEngine::getWorld() const
{
    return world;
}

const std::vector<std::unique_ptr<Enemy> > &GameEngine::getEnemies() const
{
    return enemiesList;
}

const std::vector<std::unique_ptr<Tile> > &GameEngine::getHealthPacks() const
{
    return healthPackList;
}

bool GameEngine::isRunning() const
{
    return gameRunning;
}

void GameEngine::setPath(std::vector<std::unique_ptr<Tile> > newPath)
{
    if (newPath.empty()) return;

    this->path.clear();
    this->path.swap(newPath);

    visualisation->setPath(this->path);
}

void GameEngine::setProtagonistDirection(int direction, int count)
{
    if (protagonistDirection == 0)  // don't overwrite existing direction
    {
        protagonistDirection = direction;
        directionCounter = count;
        path.clear();   // override pathfinder
        visualisation->clearPath();
        visualisation->switchControllerMode(true);  // interrupt auto mode
    }
}

void GameEngine::gameUpdate()
{
    if (gameRunning)
    {
        updateEffects();
        moveProtagonist();
        findCollision();
        checkGameStatus();
    }
}

void GameEngine::changeRefreshRate(int refreshRate)
{
    gameLoop->setInterval(refreshRate);
}

void GameEngine::poisonSurrounding(int poisonLevel)
{
    if (poisonLevel > 0.0f)
    {
        PEnemy* pEnemy = (PEnemy*) sender();
        std::cout << "PEnemy poisoning at " << pEnemy->serialize()
                  << " with poison level " << poisonLevel << std::endl;

        int x_start = pEnemy->getXPos() - 1;
        int y_start = pEnemy->getYPos() - 1;

        // poison surround tiles
        for (int i = 0; i < 9; i++)
        {
            int x = x_start + i % 3;
            int y = y_start + i / 3;

            if (x < 0 || x >= world->getCols() ||
                    y < 0 || y >= world->getRows())
                continue;   // tile out of bound

            auto is_tile = [&x, &y](std::unique_ptr<Tile> &tile)
            {
                return x == tile->getXPos() && y == tile->getYPos();
            };

            auto result = std::find_if(poisonedTiles.begin(), poisonedTiles.end(), is_tile);

            // poison lasts for 4 game cycles
            if (result == poisonedTiles.end())
            {
                poisonedTiles.emplace_back(std::make_unique<Tile> (x, y, 4));
//                std::cout << "Made a poison tile at " << x << "," << y << std::endl;
            }
            else
            {
                result->get()->setValue(4);
//                std::cout << "Renewed a poison tile at " << x << "," << y << std::endl;
            }

        }
    }
}

void GameEngine::godModeEnergy(bool mode)
{
    godmode = mode;
}

void GameEngine::onXEnemyMoved(int x, int y)
{
     // update XEnemy
    int posXEnemy = getPosition(fireTile->getXPos(), fireTile->getYPos() + 1);

    auto &oldObject = tileEffects.at(posXEnemy);
    int xEnemyIndex = oldObject->index;

    oldObject->type = GameObjectType::NO_OBJECT;     // reset old position
    oldObject->index = 0;

    auto &newObject = tileEffects.at(y * world->getCols() + x);  // set new position to reference XEnemy
    newObject->type = GameObjectType::ENEMY;
    newObject->index = xEnemyIndex;

    // update fire tile

    int posFire = getPosition(fireTile->getXPos(), fireTile->getYPos());
    tileEffects.at(posFire)->effectFlags &= ~ ON_FIRE;      // unset fire

    fireTile->setXPos(x);
    fireTile->setYPos(y - 1);
}

void GameEngine::onXEnemyFire()
{
    fireTile->setValue(8);  // on fire for 8 game cycles
}
