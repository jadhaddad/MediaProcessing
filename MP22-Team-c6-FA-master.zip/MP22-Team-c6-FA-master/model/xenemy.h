#ifndef XENEMY_H
#define XENEMY_H


#include <string>
#include <QObject>
#include <iostream>
#include <QTimer>
#include <random>
#include <world.h>

class GameEngine;

class XEnemy : public Enemy
{
  Q_OBJECT

public:
    XEnemy(int xPosition, int yPosition, float strength, const GameEngine *engine);
    void setXPos(int newPos) {if (xPos != newPos){xPos = newPos; emit posChanged(xPos, yPos);}}
    void setYPos(int newPos) {if (yPos != newPos){yPos = newPos; emit posChanged(xPos, yPos);}}
    void setPos(int newX, int newY) {if (xPos != newX || yPos != newY) {xPos = newX; yPos = newY; emit posChanged(xPos, yPos);}}

public slots:
    void nextMove();
    void nextLoop();

signals:
    void fire();
    void posChanged(int x, int y);
    void walkChanged(bool walking);

private:
    const GameEngine *engine;

    int count = 0;
    int countTo = 0;
    int direction = 0;
};

#endif // XENEMY_H
