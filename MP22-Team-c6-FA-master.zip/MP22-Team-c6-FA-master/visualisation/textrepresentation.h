﻿#ifndef TEXTREPRESENTATION_H
#define TEXTREPRESENTATION_H

#include <world.h>
#include "scene.h"
#include <QGraphicsTextItem>
#include <QTextEdit>
#include <iostream>
#include <tuple>
#include <QChar>
#include <QTimer>

struct HealthPackConsumption {
    HealthPackConsumption(int x, int y, bool consumed)
        : x{x}, y{y}, consumed{consumed} {};

    int x;
    int y;
    bool consumed;
};

struct EnemyDeath {
    EnemyDeath(int x, int y, bool death) : x{x}, y{y}, death{death} {};
    int x;
    int y;
    bool death;
};

struct Prot_struct {
    Prot_struct(int x, int y, bool poisoned, bool on_fire, bool dead): x{x}, y{y}, poisoned{poisoned}, on_fire{on_fire}, dead{dead} {};
    int x;
    int y;
    bool poisoned;
    bool on_fire;
    bool dead;

};

struct XEnemyPos {
    XEnemyPos(int x, int y): x{x}, y{y} {};
    int x;
    int y;
};

class TextRepresentation : public Scene
{
    Q_OBJECT
private:
    bool update = true;

    int row, col;
    int poisoned = -1;
    int on_fire = -1;
    int heal = -1;

    std::unique_ptr<QTimer> text_animation;
    std::unique_ptr<QGraphicsTextItem> text;
    std::vector<std::unique_ptr<HealthPackConsumption>> healthPacksConsume;
    std::vector<std::unique_ptr<EnemyDeath>> enemyDeath;
    std::unique_ptr<Prot_struct> protPos;
    std::unique_ptr<XEnemyPos> xenemy_pos;


    QString textRep;

public:
    TextRepresentation(Visualisation *t);
    ~TextRepresentation() override;

    void drawMapBackground(const QString filename) override;

    void drawMapTiles(const std::vector<std::unique_ptr<Tile>> &tiles, const std::unique_ptr<World> &world) override;
    void updateHealthPacks(const std::vector<std::unique_ptr<Tile>> &healthPacks,
                           const std::unique_ptr<Protagonist> &protagonist) override;
    void clearMapTiles()  override;

    void udpateEnemies(const std::vector<std::unique_ptr<Enemy>> &enemies) override;
    void updateProtagonist(const std::unique_ptr<Protagonist> &protagonist) override;
    void clearPath() override;

    void updatePath(const std::vector<std::unique_ptr<Tile>> &path) override;
    void reset() override;

public slots:
    void changeRefreshRate_text(int refreshRate);
    void consume(int x, int y);
    void death();
    void moveProtagonistPosition(int x, int y);
    void XEnemyMove(int x, int y);
    void protEffect (char flags);
    void nextFrameText();
    void onUpdateChange(bool update);
};

#endif
