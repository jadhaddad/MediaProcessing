#include "textrepresentation.h"
#include <iterator>
#include <map>
#include <QPalette>
#include "model/xenemy.h"
#include "visualisation.h"
#include "model/tileeffect.h"

TextRepresentation::TextRepresentation(Visualisation *t) :
    Scene(t)
{
    text = std::make_unique<QGraphicsTextItem>(textRep);
    text_animation = std::make_unique<QTimer> (this);
    text_animation->setInterval(100);
    text_animation->start();
    connect(v, SIGNAL(onRefreshRateUpdate(int)), this, SLOT(changeRefreshRate_text(int)));

}

TextRepresentation::~TextRepresentation()
{
    text.reset();
    this->clear();
    text_animation->deleteLater();

}

void TextRepresentation::drawMapBackground(const QString)
{

}



void TextRepresentation::drawMapTiles(const std::vector<std::unique_ptr<Tile> > &, const std::unique_ptr<World> &world)
{

   row = world ->getRows();
   col = world ->getCols();

   textRep = QString("");
   QTextStream textStream(&textRep);
   for (int y=0; y<col; y++) {
       for (int x=0; x<row; x++) {
           textStream << "+---";
       }
       textStream << "+\r\n";
       for (int x = 0; x<row;x++) {
           textStream << "|   ";
       }
       textStream << "|\r\n";
   }
   for (int x=0; x<row;x++) {
       textStream<<"+---";
   }


   textStream<<"+\r\n";
   textRep = textStream.readAll();
   this -> addItem(text.get());

   QFont font("New Courier");
   font.setStyleHint(QFont::Monospace);
   text -> setFont(font);

}

void TextRepresentation::updateHealthPacks(const std::vector<std::unique_ptr<Tile> > &healthPacks, const std::unique_ptr<Protagonist> &protagonist)
{
    this->healthPacksConsume.reserve(healthPacks.size());
         for (const auto &health : healthPacks) {
             int x = health -> getXPos();
             int y = health -> getYPos();

             int x_ = x*4 + 2;
             int y_ = (2*y+1)*(4*col+3);
             this -> healthPacksConsume.emplace_back(std::make_unique<HealthPackConsumption>(x, y, false));

             int potion =  x_ +  y_;
             textRep[potion] = QChar('H');

             healthPacksConsume.clear();


         }
         connect(protagonist.get(), SIGNAL(posChanged(int,int)), this, SLOT(consume(int,int)));
}

void TextRepresentation::clearMapTiles()
{

}

void TextRepresentation::udpateEnemies(const std::vector<std::unique_ptr<Enemy> > &enemies)
{
    this ->enemyDeath.reserve(enemies.size());
    for (const auto &enemy : enemies) {


        if (auto *pEnemy = dynamic_cast<PEnemy*> (enemy.get())) {
            int p_x = pEnemy ->getXPos();
            int p_y = pEnemy ->getYPos();
            int p_x_ = p_x*4 + 2;
            int p_y_ = (2*p_y+1)*(4*col+3);
            int p_e = p_x_ + p_y_;
            this -> enemyDeath.emplace_back(std::make_unique<EnemyDeath>(p_x, p_y, false));
            textRep[p_e] = QChar('K');

            enemyDeath.clear();

        }

        else if (auto *xEnemy = dynamic_cast<XEnemy*> (enemy.get())) {
            int x_x = xEnemy ->getXPos();
            int x_y = xEnemy -> getYPos();
            int x_x_ = x_x*4 + 2;
            int x_y_ = (2*x_y+1)*(4*col+3);
            int x_e = x_x_ + x_y_;
            xenemy_pos.reset(new XEnemyPos(x_x, x_y));
            this -> enemyDeath.emplace_back(std::make_unique<EnemyDeath>(x_x, x_y, false));
            connect(xEnemy, SIGNAL(posChanged(int,int)), this, SLOT(XEnemyMove(int,int)));
            textRep[x_e] = QChar('X');

            enemyDeath.clear();


        }

        else{
            int e_x = enemy ->getXPos();
            int e_y = enemy -> getYPos();
            int e_x_ = e_x*4 + 2;
            int e_y_ = (2*e_y+1)*(4*col+3);
            int e_e = e_x_ + e_y_;
            this -> enemyDeath.emplace_back(std::make_unique<EnemyDeath>(e_x, e_y, false));
            textRep[e_e] = QChar('E');

            enemyDeath.clear();
        }
        connect(enemy.get(), SIGNAL(dead()), this, SLOT(death()));
    }
}

void TextRepresentation::updateProtagonist(const std::unique_ptr<Protagonist> &protagonist)
{

    int x = protagonist -> getXPos();
    int y = protagonist -> getYPos();
    int prot_x = x*4 + 2;
    int prot_y = (2*y+1)*(4*col+3);
    int prot = prot_x + prot_y;
    textRep[prot] = QChar('P');
    protPos.reset(new Prot_struct(x, y, false, false ,false));
    connect(protagonist.get(), SIGNAL(posChanged(int,int)), this, SLOT(moveProtagonistPosition(int,int)));
    connect(v, SIGNAL(onProtagonistEffect(char)), this, SLOT(protEffect(char)));
    connect(text_animation.get(), SIGNAL(timeout()), this, SLOT(nextFrameText()));

}

void TextRepresentation::clearPath()
{

}

void TextRepresentation::updatePath(const std::vector<std::unique_ptr<Tile> > &)
{

}

void TextRepresentation::reset()
{
    text.reset();
    this->clear();
    text = std::make_unique<QGraphicsTextItem>(textRep);
}

void TextRepresentation::changeRefreshRate_text(int refreshRate)
{
    text_animation->setInterval(refreshRate);

}

void TextRepresentation::consume(int x, int y)
{
    Protagonist * prot = (Protagonist*) sender();
   for(auto &health : healthPacksConsume) {
       if (health->x == x && health->y == y)
       {

           if(health->consumed == false)
           {
                health->consumed = true;
               if (health->x == prot->getXPos() && health->y == prot->getYPos()) {
                   int x_ = x*4 + 2;
                   int y_ = (2*y+1)*(4*col+3);
                   int potion =  x_ +  y_;
                   textRep[potion] = QChar('P');

               }
               else {
               int x_ = x*4 + 2;
               int y_ = (2*y+1)*(4*col+3);
               int potion =  x_ +  y_;
               textRep[potion] = QChar(' ');
               }
            }
        }
    }
}

void TextRepresentation::death()
{
    Enemy * enemy = (Enemy*) sender();
    PEnemy * penemy = (PEnemy*) sender();
    XEnemy * xenemy = (XEnemy*) sender();
    for (auto &enemy_death : enemyDeath) {
        if((enemy->getXPos() == enemy_death->x && enemy->getYPos() == enemy_death ->y) ||
                (penemy ->getXPos() == enemy_death ->x && penemy ->getYPos() == enemy_death ->y) ||
                (xenemy->getXPos() == enemy_death -> x && xenemy -> getYPos() == enemy_death->y)) {
            if(enemy_death ->death == false) {
                enemy_death -> death = true;
                int x_ = (enemy_death->x)*4 +2;
                int y_ = (2*enemy_death ->y +1)*(4*col+3);
                int enemy_pos = x_ + y_;
                textRep[enemy_pos] = QChar(' ');
            }
        }

    }

}

void TextRepresentation::moveProtagonistPosition(int x, int y)
{
    Protagonist * protagonist = (Protagonist*) sender();

    {
        x = protPos->x;
        y = protPos->y;
        int prot_x = x*4 + 2;
        int prot_y = (2*y+1)*(4*col+3);
        int prot = prot_x + prot_y;
        textRep[prot] = QChar(' ');
    }
     {
        protPos -> x = protagonist->getXPos();
        protPos -> y  = protagonist->getYPos();
        x = protPos->x;
        y = protPos->y;
        int prot_x = x*4 + 2;
        int prot_y = (2*y+1)*(4*col+3);
        int prot = prot_x + prot_y;
        textRep[prot] = QChar('P');


    }

    if (protagonist->getHealth() == 0 || protagonist->getEnergy() == 0) {
                protPos ->dead = true;
                int x_ = (protagonist->getXPos())*4+2;
                int y_ = (2*(protagonist->getYPos())+1)*(4*col+3);
                int prot = x_ + y_;
                textRep[prot] = QChar('L');
    }
}

void TextRepresentation::XEnemyMove(int x, int y)
{
      XEnemy * xenemy = (XEnemy*) sender();
      {
          x = xenemy_pos->x;
          y = xenemy_pos->y;
          int x_x = x*4 + 2;
          int x_y = (2*y+1)*(4*col+3);
          int xenemy_pos = x_x + x_y;
          textRep[xenemy_pos] = QChar(' ');
      }
    {
      xenemy_pos -> x = xenemy ->getXPos();
      xenemy_pos -> y = xenemy ->getYPos();
      x = xenemy_pos -> x;
      y = xenemy_pos -> y;
      int x_x = x*4+2;
      int x_y = (2*y+1)*(4*col+3);
      int xenemy_pos = x_x + x_y;
      textRep[xenemy_pos] = QChar('X');
    }
}

void TextRepresentation::protEffect(char flags)
{
    if(flags & POISONED) {
        poisoned = 0;
    }

    if(flags & ON_FIRE) {
        on_fire = 0;
    }

    if(flags & HEAL) {
        heal = 0;
    }
}


void TextRepresentation::nextFrameText()
{
    if (protPos->dead == false && poisoned > -1 && poisoned < 9) {
        poisoned++;
        int x_ = (protPos->x)*4+2;
        int y_ = (2*(protPos->y)+1)*(4*col+3);
        int prot = x_ + y_;
        textRep[prot] = QChar(0x2C23);
    }
    else if(poisoned == 9) {
        poisoned = -1;
    }

    if(protPos->dead == false && heal > -1 && heal < 9) {
        heal++;
        int x_ = (protPos->x)*4+2;
        int y_ = (2*(protPos->y)+1)*(4*col+3);
        int prot = x_ + y_;
        textRep[prot] = QChar(43);
    }
    else if(heal == 9) {
        heal = -1;
    }


    if (protPos->dead == false && on_fire > -1 && on_fire < 9) {
        on_fire++;
        int x_ = (protPos->x)*4+2;
        int y_ = (2*(protPos->y)+1)*(4*col+3);
        int prot = x_ + y_;
        textRep[prot] = QChar(0x01A4);
    }
    else if(on_fire == 9) {
        on_fire = -1;
    }

    // ONLY UPDATE HERE!
    if (update)
        text->setPlainText(textRep);
}

void TextRepresentation::onUpdateChange(bool update)
{
    this->update = update;
}
