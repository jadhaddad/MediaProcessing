#ifndef SCENE_H
#define SCENE_H

#include <world.h>

#include <QGraphicsScene>
#include <QObject>

class Visualisation;

class Scene : public QGraphicsScene
{
    Q_OBJECT
public:
    Scene(Visualisation *v) : v{v} { };
    virtual ~Scene() = default;

    virtual void drawMapBackground(const QString filename) = 0;
    virtual void drawMapTiles(const std::vector<std::unique_ptr<Tile>> &tiles, const std::unique_ptr<World> &world) = 0;
    virtual void clearMapTiles() = 0;

    virtual void updateHealthPacks(const std::vector<std::unique_ptr<Tile>> &healthPacks,
                                   const std::unique_ptr<Protagonist> &protagonist) = 0;
    virtual void udpateEnemies(const std::vector<std::unique_ptr<Enemy>> &enemies) = 0;
    virtual void updateProtagonist(const std::unique_ptr<Protagonist> &protagonist) = 0;

    virtual void updatePath(const std::vector<std::unique_ptr<Tile> > &tiles) = 0;
    virtual void clearPath() = 0;

    virtual void reset() = 0;

protected:
    Visualisation *v;
};

#endif // SCENE_H
