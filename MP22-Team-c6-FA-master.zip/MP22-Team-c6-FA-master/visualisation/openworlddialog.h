#ifndef OPENWORLDDIALOG_H
#define OPENWORLDDIALOG_H

#include <QDialog>

namespace Ui {
class OpenWorldDialog;
}

class OpenWorldDialog : public QDialog
{
    Q_OBJECT

public:
    explicit OpenWorldDialog(QWidget *parent = nullptr);
    ~OpenWorldDialog();

    void selectMap(QString path);

signals:
    void openWorld(QString filename, int noOfEnemies, int noOfHealthPacks);

private slots:
    void on_buttonBox_accepted();

    void on_buttonMaze1_clicked();

    void on_buttonMaze2_clicked();

    void on_buttonMaze3_clicked();

    void on_buttonWorldMap_clicked();

    void on_buttonWorldMap4_clicked();

    void on_buttonOpenWorld_clicked();

private:
    Ui::OpenWorldDialog *ui;
    QString selectedMap;
};

#endif // OPENWORLDDIALOG_H
