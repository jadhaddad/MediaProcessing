#ifndef VISUALISATION_H
#define VISUALISATION_H

#include "scene.h"
#include "openworlddialog.h"

#include <QMainWindow>
#include <QGraphicsView>
#include <QPushButton>
#include <QLineEdit>
#include <QInputDialog>
#include <QEvent>
#include <QKeyEvent>
#include <QScrollBar>

#include <memory>

#include <world.h>

QT_BEGIN_NAMESPACE
namespace Ui { class Visualisation; }
QT_END_NAMESPACE

class Visualisation : public QMainWindow
{
    Q_OBJECT

public:
    explicit Visualisation(QWidget *parent = 0);
    ~Visualisation();

public:
    bool eventFilter(QObject * object, QEvent * event) override;

    /**
     * @brief resetWorld Reset scenes and bars.
     */
    void resetWorld();

    /**
     * @brief drawBackground Calls the scene to draw the background.
     * @param filename Absolute path to the image map.
     */
    void drawBackground(const QString filename);

    /**
     * @brief drawMapTiles Sends to the scenes, called once per game.
     * @param tile Reference to tiles.
     * @param world Reference to world.
     */
    void drawMapTiles(const std::vector<std::unique_ptr<Tile>> &tile,  const std::unique_ptr<World> &world);

    /**
     * @brief updateHealthPacks Sends to scenes, called once per game.
     * @param healthPacks Reference to the health packs.
     * @param protagonist Reference to protagonist. Used to get the protagonist position update.
     */
    void updateHealthPacks(const std::vector<std::unique_ptr<Tile>> &healthPacks,
                           const std::unique_ptr<Protagonist> &protagonist);
    /**
     * @brief updateEnemies Sends to scenes, called once per game.
     * @param enemies Reference to the enemies.
     */
    void updateEnemies(const std::vector<std::unique_ptr<Enemy>> &enemies);

    /**
     * @brief updateProtagonist Sends to scenes, called once per game.
     * @param protagonist Reference to protagonist.
     */
    void updateProtagonist(const std::unique_ptr<Protagonist> &protagonist);

    /**
     * @brief setPath Visualise the path the protagonist will take.
     * @param tiles Reference to the path.
     * @param protagonist Reference to protagonist, used to get protagonist position update to remove tiles it walked on.
     */
    void setPath(const std::vector<std::unique_ptr<Tile>> &tiles);

    /**
     * @brief clearPath Sends to scenes to clear the whole path.
     */
    void clearPath();

    /**
     * @brief refreshScene Update current scene. Necessary to prevent image artefacts.
     */
    void refreshScene();

    /**
     * @brief endGame Ends the game. Sets game running to false
     * @param win If win display win message.
     */
    void endGame(bool win);

public slots:
    /**
     * @brief openWorldResult Open the world from the result of OpenWorldDialog.
     * @param filename Absolute path to the world.
     * @param noOfEnemies Number of enemies.
     * @param noOfHealthPacks Number of health packs.
     */
    void openWorldResult(QString filename, int noOfEnemies, int noOfHealthPacks);
    /**
     * @brief on_commandLineReturn When command line pressed enter.
     * Emit command_entered signal which sends the command text to the controller.
     */
    void on_commandLineReturn();

    /**
     * @brief setCommand Set the text of the command line. Used for autocompelte.
     * @param string String on the text.
     */
    void setCommand(QString string);

    /**
     * @brief appendHistory Add a new line on the command history above the command line.
     * @param string Line to be added.
     * @param critical If true, show terminal if it's closed.
     */
    void appendHistory(QString string, bool critical);

    /**
     * @brief clearHistory Clears the history.
     */
    void clearHistory();

    /**
     * @brief closeTerminal Close the command line and command history.
     */
    void closeTerminal();

    /**
     * @brief on_worldTileClicked Connected to the graphics view and receive where the mouse is clicked.
     * emits a goto function using command_entered
     * @param gameCoor Game coordinates of the tile
     * @param value Weight of tile (-1 if unknown)
     */
    void on_worldTileClicked(QPoint gameCoor, float value);

    /**
     * @brief protagonistMoved Connected to gameengine. Used to centre on the view to protagonist depending on selected scene.
     * @param x Game x coordinate.
     * @param y Game y coordinate.
     */
    void protagonistMoved(int x, int y);

    /**
     * @brief onHealthChanged Change the health bar value.
     * @param health Health value.
     */
    void onHealthChanged(int health);

    /**
     * @brief onEnergyChanged Change energy bar value.
     * @param energy Energy value.
     */
    void onEnergyChanged(int energy);

    /**
     * @brief switchControllerMode Switches the UI for automatic and manual mode.
     * Emits signal to controller.
     * @param manualMode True if switch to manual mode.
     */
    void switchControllerMode(bool manualMode);

private slots:
    void on_actionToggle_Terminal_triggered();

    void on_actionShow_Settings_triggered();

    void on_actionGraphical_triggered(bool checked);

    void on_actionText_triggered(bool checked);

    void on_actionManual_triggered(bool checked);

    void on_actionAuto_triggered(bool checked);

    void on_actionOpen_image_triggered();

    void on_zoomSpin_valueChanged(int arg1);

    void on_zoomSlider_valueChanged(int value);

    void on_speedSpin_valueChanged(int arg1);

    void on_speedSlider_valueChanged(int value);

    void on_resetButton_clicked();

    void on_weightSpin_valueChanged(double arg1);

    void on_weightSlider_valueChanged(int value);

    void on_actionToggle_Centre_triggered();

    void on_actionDisable_Text_Update_triggered(bool checked);

    void on_actionGodMode_triggered(bool checked);

    void on_zoomSpin_editingFinished();

    void on_speedSpin_editingFinished();

    void on_weightSpin_editingFinished();

signals:
    /**
     * @brief file_name_entered Opening of a new world.
     * @param fileName Absolute path of the world map image file.
     * @param enemies Number of enemies.
     * @param healthPacks Number of health packs.
     */
    void file_name_entered(const QString fileName, int enemies, int healthPacks);

    /**
     * @brief switchMode Connected to controller to switch between manual and auto mode.
     * @param manualMode
     */
    void switchMode(bool manualMode);

    /**
     * @brief command_entered Connected to controller to send command that has been entered.
     * Called when pressed enter on the command line.
     * @param command Command string.
     */
    void command_entered(const QString command);

    /**
     * @brief autoComplete Connected to controller to autocomplete the command line.
     * Called when press tab on the command line (use of event filter).
     * @param command Incomplete command.
     */
    void autoComplete(const QString command);

    /**
     * @brief onZoomChange Change the zoom of the world.
     * @param zoom 0.01 - 2.00.
     */
    void onZoomChange(float zoom);

    /**
     * @brief onRefreshRateUpdate Change animation speed.
     * @param refreshRate Interval of the timers in ms.
     */
    void onRefreshRateUpdate(int refreshRate);

    /**
     * @brief onProtagonistEffect Flags of the effects on protagonist (see tileeffect.h). Connected to the scenes.
     * @param flag
     */
    void onProtagonistEffect(char flag);

    /**
     * @brief onWeightChange Change the heuristic weight for the pathfinding
     * @param weight 0.00 - 1.00
     */
    void onWeightChange(float weight);

    /**
     * @brief updateTextView Used to disable setText on text representaiton for performance.
     * @param update
     */
    void updateTextView(bool update);

    void onGodMode(bool mode );

private:
    Ui::Visualisation *ui;
    std::vector<std::unique_ptr<Scene>> scenes;
    bool gameRunning = false;
    bool terminalShown = false;
    bool settingsShown = false;
    bool centreOnProtagonist = true;
    int chosenScene = 0;
    float zoom = 1.0f;
    QPoint protagonistPos;
    std::unique_ptr<OpenWorldDialog> worldDialog;

    /**
     * @brief switchScene Switches scenes.
     * @param i 0 - 2D, 1 - text
     */
    void switchScene(int i);

    /**
     * @brief protagonistMoved Centre on protagonist.
     * @param protagonistPos Position of protagonist in game coordinates.
     */
    void protagonistMoved(QPoint protagonistPos);
};

#endif
