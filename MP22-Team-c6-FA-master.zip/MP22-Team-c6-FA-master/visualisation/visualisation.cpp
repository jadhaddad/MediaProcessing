#include "visualisation.h"
#include "./ui_visualisation.h"

#include "graphical/graphicalrepresentation.h"
#include "textrepresentation.h"

#include <QMessageBox>
#include <iostream>

Visualisation::Visualisation(QWidget * parent) :
    QMainWindow(parent),
    ui(new Ui::Visualisation)
{
    ui->setupUi(this);

    // hide views
    ui->textHistory->hide();
    ui->editCommand_Line->hide();
    ui->editCommand_Line->setFocusPolicy(Qt::NoFocus);
    ui->settingsBox->hide();

    ui->actionGraphical->setEnabled(false);
    ui->actionManual->setEnabled(false);

    // set up scenes
    scenes.reserve(2);
    auto graphics = std::make_unique<GraphicalRepresentation>(this);
    scenes.push_back(std::move(graphics));
    auto text = std::make_unique<TextRepresentation>(this);
    connect(this, SIGNAL(updateTextView(bool)), text.get(), SLOT(onUpdateChange(bool)));
    scenes.push_back(std::move(text));

    // set up graphic view area
    ui->viewPlay_Area->setScene(scenes.at(0).get());
    ui->viewPlay_Area->scale(zoom, zoom);
    ui->viewPlay_Area->verticalScrollBar()->setEnabled(false);
    ui->viewPlay_Area->horizontalScrollBar()->setEnabled(false);
    ui->viewPlay_Area->setFocusPolicy(Qt::NoFocus);
}

Visualisation::~Visualisation()
{
    worldDialog.reset();
    delete ui;
    scenes.clear();
}

bool Visualisation::eventFilter(QObject *object, QEvent *event)
{
    if (event->type() == QEvent::KeyRelease)
    {
        if (!ui->editCommand_Line->hasFocus())
        {
            QKeyEvent *keyEvent = static_cast<QKeyEvent*> (event);
            Qt::Key key = (Qt::Key)keyEvent->key();

            if (gameRunning && keyEvent->modifiers() == Qt::NoModifier)    // only when game runs
            {
                if (key == Qt::Key_W || key == Qt::Key_Up)
                {
                    emit command_entered("up");
                    return true;    // filtered
                }
                else if (key == Qt::Key_A || key == Qt::Key_Left)
                {
                    emit command_entered("left");
                    return true;
                }
                else if (key == Qt::Key_S || key == Qt::Key_Down)
                {
                    emit command_entered("down");
                    return true;
                }
                else if (key == Qt::Key_D || key == Qt::Key_Right)
                {
                    emit command_entered("right");
                    return true;
                }
            }

            // commands that runs whenever
            if (keyEvent->modifiers() == Qt::ControlModifier)
            {
                if (key == Qt::Key_T)  // show terminal
                {
                    terminalShown = false;
                    on_actionToggle_Terminal_triggered();
                    return true;
                }
                else if (key == Qt::Key_S) // toggle settings
                {
                    on_actionShow_Settings_triggered();
                    return true;
                }
                else if (key == Qt::Key_O)  // open world
                {
                    on_actionOpen_image_triggered();
                    return true;
                }
            }
        } 
    }
    else if (event->type() == QEvent::KeyPress)
    {
        if (ui->editCommand_Line->hasFocus())
        {
            QKeyEvent *keyEvent = static_cast<QKeyEvent*> (event);
            Qt::Key key = (Qt::Key)keyEvent->key();

            if (key == Qt::Key_Tab)
            {
                emit autoComplete(ui->editCommand_Line->text());
                return true;
            }
        }
    }
    else if (event->type() == QEvent::MouseButtonRelease)
    {
        // reset focus when necessary
        if (!ui->resetButton->hasFocus() && !ui->editCommand_Line->hasFocus() &&
                !ui->speedSpin->hasFocus() && !ui->weightSpin->hasFocus() && !ui->zoomSpin->hasFocus())
            this->setFocus();
    }

    return QObject::eventFilter(object, event);
}

void Visualisation::resetWorld()
{
    ui->textHistory->clear();
    ui->viewPlay_Area->resetTransform();
    zoom = 1.0f;
    ui->zoomSlider->setValue(100);
    onHealthChanged(100);
    onEnergyChanged(100);

    for (auto &scene : scenes)
    {
        scene->reset();
        scene->clearMapTiles();
        scene->clear();
    }
}

void Visualisation::drawBackground(const QString filename)
{
    for (const auto &scene : scenes)
        scene->drawMapBackground(filename);
}

void Visualisation::drawMapTiles(const std::vector<std::unique_ptr<Tile>> &tile, const std::unique_ptr<World> &world)
{
    for (const auto &scene : scenes)
    {
        scene->drawMapTiles(tile, world);
    }
}

void Visualisation::updateHealthPacks(const std::vector<std::unique_ptr<Tile> > &healthPacks, const std::unique_ptr<Protagonist> &protagonist)
{
    for (const auto &scene : scenes)
        scene->updateHealthPacks(healthPacks, protagonist);
}

void Visualisation::updateEnemies(const std::vector<std::unique_ptr<Enemy> > &enemies)
{
    for (const auto &scene : scenes)
        scene->udpateEnemies(enemies);
}

void Visualisation::updateProtagonist(const std::unique_ptr<Protagonist> &protagonist)
{
    QString text = "Spawning protagonist at "
            + QString::number(protagonist->getXPos()) + ", "
            + QString::number(protagonist->getYPos());
    appendHistory(text, false);

    connect(protagonist.get(), SIGNAL(healthChanged(int)), this, SLOT(onHealthChanged(int)));
    connect(protagonist.get(), SIGNAL(energyChanged(int)), this, SLOT(onEnergyChanged(int)));

    connect(protagonist.get(), SIGNAL(posChanged(int,int)), this, SLOT(protagonistMoved(int,int)));
    protagonistMoved(protagonist->getXPos(), protagonist->getYPos());

    for (auto &scene : scenes)
        scene->updateProtagonist(protagonist);

    gameRunning = true;
}

void Visualisation::setPath(const std::vector<std::unique_ptr<Tile> > &tiles)
{
    for (const auto &scene : scenes)
        scene->updatePath(tiles);

    refreshScene();
}

void Visualisation::clearPath()
{
    for (auto &scene : scenes)
        scene->clearPath();

    refreshScene();
}

void Visualisation::refreshScene()
{
    ui->viewPlay_Area->scene()->update();
}

void Visualisation::endGame(bool win)
{
    gameRunning = false;
    clearPath();

    if (win)
        QMessageBox::information(this, "Winner!", "You win!");
    else
        QMessageBox::information(this, "Loser!", "You lose!");
}

void Visualisation::openWorldResult(QString filename, int noOfEnemies, int noOfHealthPacks)
{
    emit file_name_entered(filename, noOfEnemies, noOfHealthPacks);
    drawBackground(filename);
}

void Visualisation::on_actionToggle_Terminal_triggered()
{
    if (terminalShown)
    {
        ui->actionToggle_Terminal->setText("Show Terminal");
        ui->textHistory->hide();
        ui->editCommand_Line->hide();
        ui->editCommand_Line->setFocusPolicy(Qt::NoFocus);
        ui->viewPlay_Area->setFocus();
    }
    else
    {
        ui->actionToggle_Terminal->setText("Hide Terminal");
        ui->textHistory->show();
        ui->editCommand_Line->show();
        ui->editCommand_Line->setFocusPolicy(Qt::ClickFocus);
        ui->editCommand_Line->setFocus();
    }
    terminalShown = !terminalShown;
    protagonistMoved(protagonistPos);
}


void Visualisation::on_actionShow_Settings_triggered()
{
    if (settingsShown)
    {
        ui->actionShow_Settings->setText("Show Settings");
        ui->settingsBox->hide();
    }
    else
    {
        ui->actionShow_Settings->setText("Hide Settings");
        ui->settingsBox->show();
    }
    settingsShown = !settingsShown;
    protagonistMoved(protagonistPos);
}


void Visualisation::on_actionGraphical_triggered(bool checked)
{
    if (checked) switchScene(0);
}


void Visualisation::on_actionText_triggered(bool checked)
{
    if (checked) switchScene(1);
}


void Visualisation::on_actionManual_triggered(bool checked)
{
    switchControllerMode(checked);
}


void Visualisation::on_actionAuto_triggered(bool checked)
{
    switchControllerMode(!checked);
}


void Visualisation::on_actionOpen_image_triggered()
{
    if (!worldDialog)
    {
        worldDialog = std::make_unique<OpenWorldDialog>(this);
        connect(worldDialog.get(), SIGNAL(openWorld(QString,int,int)), this, SLOT(openWorldResult(QString,int,int)));
    }

    worldDialog->show();
    worldDialog->raise();
    worldDialog->activateWindow();
}

void Visualisation::switchScene(int i)
{
    chosenScene = i;
    ui->actionGraphical->setChecked(i == 0);
    ui->actionGraphical->setEnabled(i == 1);
    ui->actionText->setChecked(i == 1);
    ui->actionText->setEnabled(i == 0);
    terminalShown = i == 0;
    on_actionToggle_Terminal_triggered();
    ui->viewPlay_Area->setScene(scenes.at(i).get());
}

void Visualisation::protagonistMoved(QPoint newProtagonistPos)
{
    protagonistPos = newProtagonistPos;
    if (centreOnProtagonist)
        ui->viewPlay_Area->centerOn(newProtagonistPos);
    refreshScene();
}

void Visualisation::onHealthChanged(int health)
{
    ui->healthBar->setValue(health);
    ui->healthLabel->setText("Health: " + QString::number(health));
}

void Visualisation::onEnergyChanged(int energy)
{
    ui->energyBar->setValue(energy);
    ui->energyLabel->setText("Energy: " + QString::number(energy));
}

void Visualisation::switchControllerMode(bool manualMode)
{
    ui->actionManual->setChecked(manualMode);
    ui->actionManual->setEnabled(!manualMode);
    ui->actionAuto->setChecked(!manualMode);
    ui->actionAuto->setEnabled(manualMode);
    emit switchMode(manualMode);
}

void Visualisation::on_commandLineReturn()
{
    QString command = ui->editCommand_Line->text();
    appendHistory(command, false);
    ui->editCommand_Line->clear();
    emit command_entered(command);
}

void Visualisation::setCommand(QString string)
{
    ui->editCommand_Line->setText(string);
}

void Visualisation::appendHistory(QString string, bool critical)
{
    if (!terminalShown && critical)
        on_actionToggle_Terminal_triggered();
    ui->textHistory->append(string);
}

void Visualisation::clearHistory()
{
    ui->textHistory->clear();
}

void Visualisation::closeTerminal()
{
    terminalShown = true;
    on_actionToggle_Terminal_triggered();
}

void Visualisation::on_worldTileClicked(QPoint gameCoor, float value)
{
    if (gameRunning)
    {
        QString result;

        if (value == std::numeric_limits<float>::infinity())
            result = "Unable to go to tile " + QString::number(gameCoor.x()) + ", "
                    + QString::number(gameCoor.y());
        else
        {
            result = "Going to tile " + QString::number(gameCoor.x()) + ", "
                    + QString::number(gameCoor.y())
                    + (value < 0? "" :  // unknown weight
                                  " with value " + QString::number(value))
                    + ".";

            emit command_entered(QString("goto " + QString::number(gameCoor.x()) + " " + QString::number(gameCoor.y())));
        }
        appendHistory(result, false);
        switchControllerMode(true); // interrupt auto mode
    }
}

void Visualisation::protagonistMoved(int x, int y)
{
    protagonistMoved(QPoint(x, y) * 50);
}


void Visualisation::on_zoomSpin_valueChanged(int arg1)
{
    ui->zoomSlider->setValue(arg1);
}


void Visualisation::on_zoomSlider_valueChanged(int value)
{
    ui->zoomSpin->setValue(value);
    ui->viewPlay_Area->resetTransform();
    zoom = value / 100.0f;
    ui->viewPlay_Area->scale(zoom, zoom);
    protagonistMoved(protagonistPos);
    emit onZoomChange(zoom);
}


void Visualisation::on_speedSpin_valueChanged(int arg1)
{
    ui->speedSlider->setValue(arg1);
}


void Visualisation::on_speedSlider_valueChanged(int value)
{
    ui->speedSpin->setValue(value);
    emit onRefreshRateUpdate(value);
}


void Visualisation::on_resetButton_clicked()
{
    ui->zoomSlider->setValue(100);
    ui->speedSlider->setValue(100);
    ui->weightSlider->setValue(0);
}


void Visualisation::on_weightSpin_valueChanged(double arg1)
{
    ui->weightSlider->setValue(arg1);
}


void Visualisation::on_weightSlider_valueChanged(int value)
{
    ui->weightSpin->setValue(value);
    emit onWeightChange(value);
}


void Visualisation::on_actionToggle_Centre_triggered()
{
    if (centreOnProtagonist)
    {
        ui->actionToggle_Centre->setText("Centre on Protagonist");
        ui->viewPlay_Area->verticalScrollBar()->setEnabled(true);
        ui->viewPlay_Area->horizontalScrollBar()->setEnabled(true);
        ui->viewPlay_Area->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        ui->viewPlay_Area->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        ui->viewPlay_Area->setFocusPolicy(Qt::ClickFocus);
    }
    else
    {
        ui->actionToggle_Centre->setText("Move Map");
        ui->viewPlay_Area->verticalScrollBar()->setEnabled(false);
        ui->viewPlay_Area->horizontalScrollBar()->setEnabled(false);
        ui->viewPlay_Area->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        ui->viewPlay_Area->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        ui->viewPlay_Area->setFocusPolicy(Qt::NoFocus);
    }
    centreOnProtagonist = !centreOnProtagonist;
    protagonistMoved(protagonistPos);
}


void Visualisation::on_actionDisable_Text_Update_triggered(bool disable)
{
    emit updateTextView(!disable);
}


void Visualisation::on_actionGodMode_triggered(bool checked)
{
    emit onGodMode(checked);

}


void Visualisation::on_zoomSpin_editingFinished()
{
    this->setFocus();
}


void Visualisation::on_speedSpin_editingFinished()
{
    this->setFocus();
}


void Visualisation::on_weightSpin_editingFinished()
{
    this->setFocus();
}

