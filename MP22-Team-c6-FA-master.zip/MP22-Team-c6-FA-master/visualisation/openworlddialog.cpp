#include "openworlddialog.h"
#include "ui_openworlddialog.h"

#include <iostream>
#include <QFileDialog>

OpenWorldDialog::OpenWorldDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::OpenWorldDialog)
{
    ui->setupUi(this);

    setFixedSize(size());
}

OpenWorldDialog::~OpenWorldDialog()
{
    delete ui;
}

void OpenWorldDialog::selectMap(QString path)
{
    ui->labelSelectedMap->setText("Map: " + path);
    selectedMap = path;
}

void OpenWorldDialog::on_buttonBox_accepted()
{
    if (selectedMap != "")
    {
        std::cout << "From world dialogue:"
                  << " map: " << selectedMap.toStdString()
                  << " no of enemies: " << ui->spinEnemies->value()
                  << " no of health packs: " << ui->spinHealthPacks->value()
                  << std::endl;

        emit openWorld(selectedMap, ui->spinEnemies->value(), ui->spinHealthPacks->value());
    }
}


void OpenWorldDialog::on_buttonMaze1_clicked()
{
    selectMap(":/images/maps/maze1.png");
}


void OpenWorldDialog::on_buttonMaze2_clicked()
{
    selectMap(":/images/maps/maze2.png");
}


void OpenWorldDialog::on_buttonMaze3_clicked()
{
    selectMap(":/images/maps/maze3.png");
}


void OpenWorldDialog::on_buttonWorldMap_clicked()
{
    selectMap(":/images/maps/worldmap.png");
}


void OpenWorldDialog::on_buttonWorldMap4_clicked()
{
    selectMap(":/images/maps/worldmap4.png");
}


void OpenWorldDialog::on_buttonOpenWorld_clicked()
{
    const QString file = QFileDialog::getOpenFileName(this,
                                                      "Open map",
                                                      "",
                                                      "Image Files (*.png *.jpg *.bmp)");

    if (!file.isEmpty())
        selectMap(file);
}

