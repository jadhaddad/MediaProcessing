#include "protagonistpixel.h"
#include "model/tileeffect.h"

void ProtagonistPixel::hideAllPictures()
{
    idlePicture->setVisible(false);
    std::for_each(walkAnimation.begin(), walkAnimation.end(), [](auto &n)
    {
        n->setVisible(false);
        n->resetTransform();
    });

    std::for_each(deadAnimation.begin(), deadAnimation.end(), [](auto &n)
    {
        n->setVisible(false);
        n->resetTransform();
    });

    std::for_each(attackAnimation.begin(), attackAnimation.end(), [](auto &n)
    {
        n->setVisible(false);
        n->resetTransform();
    });

    std::for_each(healAnimation.begin(), healAnimation.end(), [](auto &n)
    {
        n->setVisible(false);
        n->resetTransform();
    });

    idlePoisoned->setVisible(false);
    std::for_each(poisonedAnimation.begin(), poisonedAnimation.end(), [](auto &n)
    {
        n->setVisible(false);
    });

    std::for_each(fireAnimation.begin(), fireAnimation.end(), [](auto &n)
    {
        n->setVisible(false);
    });
}

QTransform ProtagonistPixel::leftTransformation()
{
    QTransform transform;
    transform.scale(-1, 1);
    transform.translate(-50, 0);
    return transform;
}

ProtagonistPixel::ProtagonistPixel(int health, QPoint gameCoords):
    health{health}, gameCoords{gameCoords}
{
    idlePicture = std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/pikachu/pikachu_idle.png"), this);

    walkAnimation.reserve(4);
    walkAnimation.emplace_back(std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/pikachu/pikachu_walk_1.png"), this));
    walkAnimation.emplace_back(std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/pikachu/pikachu_walk_2.png"), this));
    walkAnimation.emplace_back(std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/pikachu/pikachu_walk_3.png"), this));
    walkAnimation.emplace_back(std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/pikachu/pikachu_walk_4.png"), this));
    std::for_each(walkAnimation.begin(), walkAnimation.end(), [](auto &n) {  n->setVisible(false); });

    // TODO: dead animation
    deadAnimation.emplace_back(std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/pikachu/pikachu_dead.png"), this));
    std::for_each(deadAnimation.begin(), deadAnimation.end(), [](auto &n) { n->setVisible(false); });

    // TODO: attack animation
    attackAnimation.emplace_back(std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/pikachu/pikachu_attack_1.png"), this));
    std::for_each(attackAnimation.begin(), attackAnimation.end(), [](auto &n) { n->setVisible(false); });

    healAnimation.reserve(4);
    healAnimation.emplace_back(std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/pikachu/pikachu_heal_1.png"), this));
    healAnimation.emplace_back(std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/pikachu/pikachu_heal_2.png"), this));
    healAnimation.emplace_back(std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/pikachu/pikachu_heal_3.png"), this));
    healAnimation.emplace_back(std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/pikachu/pikachu_heal_4.png"), this));
    std::for_each(healAnimation.begin(), healAnimation.end(), [](auto &n) { n->setVisible(false); });

    idlePoisoned = std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/pikachu/pikachu_poisoned.png"), this);
    idlePoisoned -> setVisible(false);

    poisonedAnimation.reserve(4);
    poisonedAnimation.emplace_back(std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/pikachu/pikachu_walk_1_poisoned.png"), this));
    poisonedAnimation.emplace_back(std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/pikachu/pikachu_walk_2_poisoned.png"), this));
    poisonedAnimation.emplace_back(std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/pikachu/pikachu_walk_3_poisoned.png"), this));
    poisonedAnimation.emplace_back(std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/pikachu/pikachu_walk_4_poisoned.png"), this));
    std::for_each(poisonedAnimation.begin(), poisonedAnimation.end(), [](auto &n) { n->setVisible(false); });

    fireAnimation.reserve(2);
    fireAnimation.emplace_back(std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/pikachu/pikachu_fire_1.png"), this));
    fireAnimation.emplace_back(std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/pikachu/pikachu_fire_2.png"), this));
    std::for_each(fireAnimation.begin(), fireAnimation.end(), [](auto &n) { n->setVisible(false); n->setZValue(2.1); });

    healSound = std::make_unique<QSoundEffect>(this);
    healSound->setSource(QUrl::fromLocalFile(":/soundeffects/pikachu/pikachu_heal.wav"));
    healSound->setVolume(0.2f);

    attackSound = std::make_unique<QSoundEffect>(this);
    attackSound->setSource(QUrl::fromLocalFile(":/soundeffects/pikachu/pikachu_attack.wav"));
    attackSound->setVolume(0.125);

    deadSound = std::make_unique<QSoundEffect>(this);
    deadSound->setSource(QUrl::fromLocalFile(":/soundeffects/pikachu/pikachu_dead.wav"));
    deadSound->setVolume(0.2f);

    healthLabel = std::make_unique<HealthLabel>(QString::number(health), this);

    this->setZValue(2);
    this->setPos(gameCoords * 50);
}

void ProtagonistPixel::moveProtagonist(int x, int y)
{
    if (x >= gameCoords.x())
        walkingLeft = false;
    else
        walkingLeft = true;

    gameCoords = QPoint(x, y);
    setPos(gameCoords * 50);
    walking = 0;
}

void ProtagonistPixel::onHealthChange(int health)
{
    this->health = health;
    healthLabel->setPlainText(QString::number(health));
}

void ProtagonistPixel::nextFrame()
{
    hideAllPictures();

    // has died an fallen off
    if (isDead)
    {
        deadAnimation.at(0)->setVisible(true);
        disconnect(sender(), 0, this, 0);
        return;
    }

    if (dead != -1)
    {
        if (dead < 3)
        {
            // TODO: do falling animation
            deadAnimation.at(0)->setVisible(true);
            dead++;
        }
        else
            isDead = true;

        return;
    }

    // attack animation
    if (attack != -1)
    {
        if (attack < 31)
        {
            //TODO: attack animation
            if (attack == 4)        // retract
                walkingLeft = !walkingLeft;

            attackAnimation.at(0)->setVisible(true);
            if (walkingLeft)
                attackAnimation.at(0)->setTransform(leftTransformation());

            attack++;
        }
        else
            attack = -1;    // finish animation
    }
    // heal animation
    else if (heal != -1)
    {
        if (heal < 39)
        {
            healAnimation.at(heal % 4)->setVisible(true);
            heal++;
        }
        else
            heal = -1;
    }
    // walking animation
    else if (walking != -1)
    {
        if (poisoned == -1)
            walkAnimation.at(walking)->setVisible(true);
        else
            poisonedAnimation.at(walking)->setVisible(true);

        if (walkingLeft)
        {
            if (poisoned == -1)
                walkAnimation.at(walking)->setTransform(leftTransformation());
            else
                poisonedAnimation.at(walking)->setTransform(leftTransformation());
        }

        walking++;
        if (walking > 3) walking = -1;
    }
    // idle
    else
        if (poisoned == -1)
            idlePicture->setVisible(true);
        else
            idlePoisoned->setVisible(true);

    // cycle through poisoned
    if (poisoned > -1 && poisoned < 39)
        poisoned++;
    else if (poisoned == 39)
        poisoned = -1;


    // cycle through fire
    if (onFire > -1 && onFire < 39)
    {
        fireAnimation.at(onFire % 2)->setVisible(true);
        onFire++;
    }
    else if (onFire == 39)
        onFire = -1;
}

void ProtagonistPixel::effect(char flags)
{
    if (flags & POISONED)
        poisoned = 0;
    if (flags & ON_FIRE)
        onFire = 0;
    if (flags & HEAL)
    {
        heal = 0;
        healSound->play();
    }
    if (flags & ATTACK)
    {
        attack = 0;
        attackSound->play();
    }
    if (flags & DEAD)
    {
        dead = 0;
        deadSound->play();
    }
}

