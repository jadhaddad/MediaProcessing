#ifndef HEALTHLABEL_H
#define HEALTHLABEL_H

#include <QFont>
#include <QGraphicsTextItem>

class HealthLabel : public QGraphicsTextItem
{
public:
    HealthLabel(QString health, QGraphicsItem * parent)
        : QGraphicsTextItem(health, parent)
    {
        setPos(0, -25);
        setDefaultTextColor(QColor(Qt::red));
        setFont(QFont("Times", 18, QFont::Bold));
    }
};

#endif // HEALTHLABEL_H
