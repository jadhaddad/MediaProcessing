#ifndef ENEMYPIXEL_H
#define ENEMYPIXEL_H

#include <QObject>
#include <QGraphicsItemGroup>
#include <QGraphicsPixmapItem>
#include <QGraphicsTextItem>
#include <QSoundEffect>
#include <QFont>

#include "healthlabel.h"

class EnemyPixel : public QObject, public QGraphicsItemGroup
{
    Q_OBJECT

protected:
    int strength;
    QPoint gameCoords;
    bool defeated = false;

    std::unique_ptr<HealthLabel> healthLabel;

    std::unique_ptr<QGraphicsPixmapItem> enemy_idle;
    std::unique_ptr<QGraphicsPixmapItem> enemy_dead;

    std::unique_ptr<QSoundEffect> deadSound;

public:
    EnemyPixel(QPoint gameCoord, int strength,
               QString idle = ":/images/meowth/meowth_idle.png",
               QString dead = ":/images/meowth/meowth_dead.png",
               QString deadSound = ":/soundeffects/meowth/meowth_dead.wav");

public slots:
    virtual void onDead();
};

#endif
