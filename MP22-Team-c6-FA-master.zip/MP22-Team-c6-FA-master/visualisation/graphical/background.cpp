#include "background.h"
#include <iostream>
#include <math.h>

Background::Background(QPixmap image)
    : QGraphicsPixmapItem{image}
{
    setZValue(0);
}

void Background::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
    {
        QPointF point = event->scenePos();
        int x = floor(point.x() / 50);
        int y = floor(point.y() / 50);
        emit backgroundClicked(QPoint(x, y), -1.0f);
    }
}
