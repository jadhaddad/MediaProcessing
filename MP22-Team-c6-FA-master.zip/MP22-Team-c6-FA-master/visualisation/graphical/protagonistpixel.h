#ifndef PROTAGONISTPIXEL_H
#define PROTAGONISTPIXEL_H

#include <QObject>
#include <QSoundEffect>
#include "healthlabel.h"

class ProtagonistPixel : public QObject, public QGraphicsItemGroup
{
    Q_OBJECT
private:
    int health;
    bool isDead = false;

    bool walkingLeft = false;
    int walking = -1;

    int dead = -1;
    int heal = -1;
    int attack = -1;

    // effects
    int poisoned = -1;
    int onFire = -1;

    QPoint gameCoords;

    std::unique_ptr<HealthLabel> healthLabel;

    // idle
    std::unique_ptr<QGraphicsPixmapItem> idlePicture;
    std::unique_ptr<QGraphicsPixmapItem> idlePoisoned;

    // walking
    std::vector<std::unique_ptr<QGraphicsPixmapItem>> walkAnimation;
    std::vector<std::unique_ptr<QGraphicsPixmapItem>> poisonedAnimation;

    // special
    std::vector<std::unique_ptr<QGraphicsPixmapItem>> deadAnimation;
    std::vector<std::unique_ptr<QGraphicsPixmapItem>> attackAnimation;
    std::vector<std::unique_ptr<QGraphicsPixmapItem>> healAnimation;

    // mask
    std::vector<std::unique_ptr<QGraphicsPixmapItem>> fireAnimation;

    // soundeffects
    std::unique_ptr<QSoundEffect> healSound;
    std::unique_ptr<QSoundEffect> attackSound;
    std::unique_ptr<QSoundEffect> deadSound;

    void hideAllPictures();
    QTransform leftTransformation();

public:
    ProtagonistPixel(int health, QPoint gameCoords);

public slots:
    void moveProtagonist(int x, int y);
    void onHealthChange(int health);
    void nextFrame();
    void effect(char flags);
};

#endif
