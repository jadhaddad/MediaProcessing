#ifndef PENEMYPIXEL_H
#define PENEMYPIXEL_H

#include <QObject>
#include "enemypixel.h"

class PEnemyPixel : public EnemyPixel
{
    Q_OBJECT

private:
    int poisoning = -1;
    int deadCall = 0;

    std::unique_ptr<QGraphicsPixmapItem> enemy_attack;
    std::unique_ptr<QGraphicsPixmapItem> enemy_poison_cloud;

    std::unique_ptr<QSoundEffect> poisonSound;
    std::unique_ptr<QSoundEffect> attackSound;

public:
    PEnemyPixel(QPoint gameCoord, int poisonLevel);

public slots:
    void onDead() override;
    void onAttack(int poisonLevel);
    void nextFrame();
};

#endif
