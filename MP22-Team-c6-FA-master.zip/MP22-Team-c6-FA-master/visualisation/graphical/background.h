#ifndef BACKGROUND_H
#define BACKGROUND_H

#include <QObject>
#include <QGraphicsPixmapItem>
#include <QGraphicsSceneMouseEvent>

class Background : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT

public:
    Background(QPixmap image);

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;

signals:
    /**
     * @brief pictureClicked give game coordinates from picture clicked
     * @param point Game coordinate of tile
     * @param weight Weight of tile clicked, unknown for picture
     */
    void backgroundClicked(QPoint point, float weight);

};

#endif // BACKGROUND_H
