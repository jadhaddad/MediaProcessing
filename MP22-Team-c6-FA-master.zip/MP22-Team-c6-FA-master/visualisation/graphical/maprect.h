#ifndef MAPRECT_H
#define MAPRECT_H

#include <QGraphicsRectItem>
#include <QObject>
#include <QGraphicsSceneMouseEvent>

class MapRect : public QObject, public QGraphicsRectItem
{
    Q_OBJECT
private:
    QPoint gameCoor;
    float value;

    QColor getGreen(float value);

public:
    MapRect(QPoint gameCoor, float value);

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;

signals:
    void tileClicked(QPoint gameCoor, float value);
};

#endif
