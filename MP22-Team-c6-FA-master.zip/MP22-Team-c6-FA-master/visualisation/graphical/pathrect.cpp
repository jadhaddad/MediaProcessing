#include "pathrect.h"
#include <QBrush>

PathRect::PathRect(QPoint gameCoords)
    : QGraphicsRectItem(gameCoords.x() * 50, gameCoords.y() * 50, 50, 50),
      gameCoords{gameCoords}
{
    setBrush(QBrush(QColor(255, 0, 0, 127)));   // semi-transparent red

    this->setZValue(1.25);
}
