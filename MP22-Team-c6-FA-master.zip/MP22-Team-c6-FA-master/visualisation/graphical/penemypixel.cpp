#include "penemypixel.h"

PEnemyPixel::PEnemyPixel(QPoint gameCoords, int poisonLevel):
    EnemyPixel(gameCoords, poisonLevel, ":/images/koffing/koffing_idle.png", ":/images/koffing/koffing_dead.png", ":/soundeffects/koffing/koffing_dead.wav")
{
    enemy_attack = std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/koffing/koffing_poison.png"), this);
    enemy_attack->setVisible(false);

    enemy_poison_cloud = std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/koffing/koffing_poison_cloud.png"), this);
    enemy_poison_cloud->setVisible(false);
    enemy_poison_cloud->setPos(QPoint(-50, -50));   // cloud is 150 * 150. Start on tile top left of PEnemy

    attackSound = std::make_unique<QSoundEffect>(this);
    attackSound->setSource(QUrl::fromLocalFile(":/soundeffects/koffing/koffing_attack.wav"));
    attackSound->setVolume(0.2f);

    poisonSound = std::make_unique<QSoundEffect>(this);
    poisonSound->setSource(QUrl::fromLocalFile(":/soundeffects/koffing/koffing_poison.wav"));
    poisonSound->setVolume(0.2f);
}

void PEnemyPixel::onDead()
{
    deadCall++;

    // 1st death attacked by protagonist, 2nd death out of poison
    if (deadCall == 1)
        attackSound->play();
    else if (deadCall == 2)
    {
        defeated = true;
        deadSound->play();
    }
}

void PEnemyPixel::onAttack(int poisonLevel)
{
    strength = poisonLevel;
    healthLabel->setPlainText(QString::number(poisonLevel));
    poisoning = 0;

    poisonSound->play();

    enemy_idle->setVisible(false);
    enemy_attack->setVisible(true);
}

void PEnemyPixel::nextFrame()
{
    if (!defeated && poisoning != -1)
    {
        if (poisoning < 15) // 4 cycles
        {
            enemy_poison_cloud->setVisible(true);
            poisoning++;
        }
        else
        {
            enemy_poison_cloud->setVisible(false);
            poisoning = -1;
        }
    }
    else if (defeated)
    {
        healthLabel->setVisible(false);
        enemy_idle->setVisible(false);
        enemy_attack->setVisible(false);
        enemy_poison_cloud->setVisible(false);
        enemy_dead->setVisible(true);

        deadSound->play();

        disconnect(sender(), 0, this, 0);
    }
}
