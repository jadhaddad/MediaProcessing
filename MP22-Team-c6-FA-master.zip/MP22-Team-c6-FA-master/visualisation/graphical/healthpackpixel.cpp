#include "healthpackpixel.h"

HealthPackPixel::HealthPackPixel(QPoint gameCoords, int health):
    health(health), gameCoords(gameCoords)
{
    healthPack = std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/potion.png"), this);

    healthLabel = std::make_unique<HealthLabel>(QString::number(health), this);

    this->setZValue(1.5);
    this->setPos(gameCoords * 50);
}

void HealthPackPixel::consume(int x, int y)
{
    if (gameCoords.x() == x && gameCoords.y() == y)
    {
        this->setVisible(false);
        disconnect(sender(), 0, this, 0);
    }
}
