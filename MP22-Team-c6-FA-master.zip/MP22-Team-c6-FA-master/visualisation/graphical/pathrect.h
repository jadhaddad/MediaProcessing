#ifndef PATHRECT_H
#define PATHRECT_H

#include <QObject>
#include <QGraphicsRectItem>

class PathRect : public QObject, public QGraphicsRectItem
{
    Q_OBJECT

private:
    QPoint gameCoords;

public:
    PathRect(QPoint gameCoords);
};

#endif
