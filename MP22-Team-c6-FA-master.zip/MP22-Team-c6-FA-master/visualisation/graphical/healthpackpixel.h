#ifndef HEALTHPACKPIXEL_H
#define HEALTHPACKPIXEL_H

#include <QObject>
#include <QGraphicsItemGroup>
#include <QGraphicsPixmapItem>

#include "healthlabel.h"

class HealthPackPixel : public QObject, public QGraphicsItemGroup
{
    Q_OBJECT

private:
	int health;
    QPoint gameCoords;

    std::unique_ptr<HealthLabel> healthLabel;
    std::unique_ptr<QGraphicsPixmapItem> healthPack;

public:
    HealthPackPixel(QPoint gameCoord, int health);


public slots:
    void consume(int x, int y);
};

#endif
