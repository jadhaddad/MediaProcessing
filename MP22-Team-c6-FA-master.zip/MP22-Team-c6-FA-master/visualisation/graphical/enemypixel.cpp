#include "enemypixel.h"

EnemyPixel::EnemyPixel(QPoint gameCoords, int strength,
                       QString idle, QString dead, QString deadSound):
    strength{strength}, gameCoords{gameCoords}
{
    enemy_idle = std::make_unique<QGraphicsPixmapItem>(QPixmap(idle), this);
    enemy_dead = std::make_unique<QGraphicsPixmapItem>(QPixmap(dead), this);
    enemy_dead->setVisible(false);

    this->deadSound = std::make_unique<QSoundEffect>(this);
    this->deadSound->setSource(QUrl::fromLocalFile(deadSound));
    this->deadSound->setVolume(0.25f);

    healthLabel = std::make_unique<HealthLabel>(QString::number(strength), this);

    this->setZValue(1.75);
    this->setPos(gameCoords * 50);
}

void EnemyPixel::onDead()
{
    defeated = true;
    healthLabel->setVisible(false);

    enemy_idle->setVisible(false);
    enemy_dead->setVisible(true);

    deadSound->play();

    disconnect(sender(), 0, this, 0);
}
