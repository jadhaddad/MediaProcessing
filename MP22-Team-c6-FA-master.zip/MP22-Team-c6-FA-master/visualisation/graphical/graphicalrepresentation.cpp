#include <iostream>
#include <world.h>
#include <memory>

#include <QImage>

#include "graphicalrepresentation.h"
#include "visualisation/visualisation.h"
#include "model/xenemy.h"

#include "background.h"
#include "healthpackpixel.h"
#include "enemypixel.h"
#include "penemypixel.h"
#include "xenemypixel.h"
#include "protagonistpixel.h"

GraphicalRepresentation::GraphicalRepresentation(Visualisation *v):
    Scene(v)
{
    animationLoop = std::make_unique<QTimer> (this);
    animationLoop->setInterval(25);
    animationLoop->start();

    drawnTiles.reserve(TileVisualisationManager::MAX_TILES);
    path.reserve(50000);

    connect(v, SIGNAL(onRefreshRateUpdate(int)), this, SLOT(changeRefreshRate(int)));
}

GraphicalRepresentation::~GraphicalRepresentation()
{
    this->clear();
    animationLoop->deleteLater();
}

void GraphicalRepresentation::drawMapBackground(const QString filename)
{
    QPixmap image(filename);
    auto background = new Background{image};

    background->setScale(50);

    connect(background, SIGNAL(backgroundClicked(QPoint,float)), v, SLOT(on_worldTileClicked(QPoint,float)));
    this->addItem(std::move(background));
}

void GraphicalRepresentation::drawMapTiles(const std::vector<std::unique_ptr<Tile>> &tiles, const std::unique_ptr<World> &world)
{
    tileManager = std::make_unique<TileVisualisationManager>(world->getCols(),
                                                             world->getRows(),
                                                             tiles,
                                                             this,
                                                             this);

    connect(v, SIGNAL(onZoomChange(float)), tileManager.get(), SLOT(zoomChanged(float)));
}

void GraphicalRepresentation::drawMapTile(const std::unique_ptr<Tile> &tile)
{
    auto mapRect = std::make_unique<MapRect>(
                QPoint(tile->getXPos(), tile->getYPos()),
                tile->getValue());

    connect(mapRect.get(), SIGNAL(tileClicked(QPoint,float)), v, SLOT(on_worldTileClicked(QPoint,float)));

    this->addItem(mapRect.get());
    this->drawnTiles.push_back(std::move(mapRect));
}

void GraphicalRepresentation::clearMapTiles()
{
    drawnTiles.clear();
}

void GraphicalRepresentation::updateHealthPacks(const std::vector<std::unique_ptr<Tile>> &healthPacks, const std::unique_ptr<Protagonist> &protagonist)
{
    for (const auto &health : healthPacks)
    {
        auto healthPixel = new HealthPackPixel(QPoint(health->getXPos(),
                                                      health->getYPos()),
                                               health->getValue());

        connect(protagonist.get(), SIGNAL(posChanged(int,int)), healthPixel, SLOT(consume(int,int)));
        this->addItem(std::move(healthPixel));
    }
}

void GraphicalRepresentation::udpateEnemies(const std::vector<std::unique_ptr<Enemy>> &enemies)
{
    for (const auto &enemy : enemies)
    {
        if (const auto *pEnemy = dynamic_cast<PEnemy*> (enemy.get()))
        {
             auto pEnemyPixel = new PEnemyPixel(QPoint(pEnemy->getXPos(),
                                                    pEnemy->getYPos()),
                                             pEnemy->getPoisonLevel());

            connect(pEnemy, SIGNAL(poisonLevelUpdated(int)), pEnemyPixel, SLOT(onAttack(int)));
            connect(pEnemy, SIGNAL(dead()), pEnemyPixel, SLOT(onDead()));
            connect(animationLoop.get(), SIGNAL(timeout()), pEnemyPixel, SLOT(nextFrame()));

            this->addItem(std::move(pEnemyPixel));
        }
        else if (const auto *xEnemy = dynamic_cast<XEnemy*> (enemy.get()))
        {
            auto xEnemyPixel = new XEnemyPixel(QPoint(enemy->getXPos(),
                                                      enemy->getYPos()),
                                               enemy->getValue());

            connect(xEnemy, SIGNAL(fire()), xEnemyPixel, SLOT(onAttack()));
            connect(xEnemy, SIGNAL(posChanged(int,int)), xEnemyPixel, SLOT(onMove(int,int)));
            connect(xEnemy, SIGNAL(dead()), xEnemyPixel, SLOT(onDead()));
            connect(xEnemy, SIGNAL(walkChanged(bool)), xEnemyPixel, SLOT(walkChanged(bool)));
            connect(animationLoop.get(), SIGNAL(timeout()), xEnemyPixel, SLOT(nextFrame()));

            this->addItem(std::move(xEnemyPixel));
        }
        else
        {
            auto enemyPixel = new EnemyPixel(QPoint(enemy->getXPos(),
                                                    enemy->getYPos()),
                                             enemy->getValue());

            connect(enemy.get(), SIGNAL(dead()), enemyPixel, SLOT(onDead()));
            this->addItem(std::move(enemyPixel));
        }
    }
}

void GraphicalRepresentation::updateProtagonist(const std::unique_ptr<Protagonist> &protagonist)
{
    tileManager->protagonistMoved(protagonist->getXPos(), protagonist->getYPos());
    connect(protagonist.get(), SIGNAL(posChanged(int,int)), tileManager.get(), SLOT(protagonistMoved(int,int)));

    auto protagonistPixel = new ProtagonistPixel(protagonist->getHealth(),
                                                  QPoint(protagonist->getXPos(),
                                                         protagonist->getYPos()));

    connect(protagonist.get(), SIGNAL(posChanged(int,int)), protagonistPixel, SLOT(moveProtagonist(int,int)));
    connect(protagonist.get(), SIGNAL(posChanged(int,int)), this, SLOT(onProtagonistMoved(int,int)));
    connect(protagonist.get(), SIGNAL(healthChanged(int)), protagonistPixel, SLOT(onHealthChange(int)));
    connect(animationLoop.get(), SIGNAL(timeout()), protagonistPixel, SLOT(nextFrame()));
    connect(v, SIGNAL(onProtagonistEffect(char)), protagonistPixel, SLOT(effect(char)));

    this->addItem(std::move(protagonistPixel));
}

void GraphicalRepresentation::updatePath(const std::vector<std::unique_ptr<Tile> > &tiles)
{
    clearPath();
    if (tiles.size() > path.max_size())
        path.reserve(tiles.size());

    targetX = tiles.at(0)->getXPos();
    targetY = tiles.at(0)->getYPos();

    for (const auto &tile : tiles)
    {
        auto pathTile = std::make_unique<PathRect> (QPoint(tile->getXPos(), tile->getYPos()));
        this->addItem(pathTile.get());
        path.push_back(std::move(pathTile));
    }
}

void GraphicalRepresentation::clearPath()
{
    path.clear();
}

void GraphicalRepresentation::reset()
{
    clearPath();
    tileManager.reset();
}

void GraphicalRepresentation::changeRefreshRate(int refreshRate)
{
    animationLoop->setInterval(refreshRate / 4);
}

void GraphicalRepresentation::onProtagonistMoved(int x, int y)
{
    if (x == targetX && y == targetY)
    {
        clearPath();
        targetX = -1;
        targetY = -1;
    }
    if (!path.empty())
        path.pop_back();
}
