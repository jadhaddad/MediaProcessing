#ifndef GRAPHICALREPRESENTATION_H
#define GRAPHICALREPRESENTATION_H

#include "visualisation/scene.h"
#include "maprect.h"
#include "pathrect.h"
#include "tilevisualisationmanager.h"

#include <QTimer>

class GraphicalRepresentation : public Scene
{
    Q_OBJECT
private:
    std::unique_ptr<QTimer> animationLoop;
    std::vector<std::unique_ptr<MapRect>> drawnTiles;
    std::vector<std::unique_ptr<PathRect>> path;
    std::unique_ptr<TileVisualisationManager> tileManager;

    int targetX = -1, targetY = -1;

public:
    GraphicalRepresentation(Visualisation *v);
    ~GraphicalRepresentation() override;

    void drawMapBackground(const QString filename) override;
    void drawMapTiles(const std::vector<std::unique_ptr<Tile>> &tiles, const std::unique_ptr<World> &world) override;
    void drawMapTile(const std::unique_ptr<Tile> &tile);
    void clearMapTiles() override;

    void updateHealthPacks(const std::vector<std::unique_ptr<Tile>> &healthPacks,
                           const std::unique_ptr<Protagonist> &protagonist) override;
    void udpateEnemies(const std::vector<std::unique_ptr<Enemy>> &enemies) override;
    void updateProtagonist(const std::unique_ptr<Protagonist> &protagonist) override;

    void updatePath(const std::vector<std::unique_ptr<Tile> > &tiles) override;
    void clearPath() override;

    void reset() override;

public slots:
    void changeRefreshRate(int refreshRate);
    void onProtagonistMoved(int x, int y);
};

#endif
