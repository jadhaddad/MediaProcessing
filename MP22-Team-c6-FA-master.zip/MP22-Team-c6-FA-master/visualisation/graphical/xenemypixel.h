#ifndef XENEMYPIXEL_H
#define XENEMYPIXEL_H

#include <QObject>
#include "enemypixel.h"

class XEnemyPixel : public EnemyPixel
{
    Q_OBJECT

private:
    int fireSpread = -1;
    int walking = -1;
    bool walkingLeft = false;

    std::vector<std::unique_ptr<QGraphicsPixmapItem>> enemy_walking;

    std::unique_ptr<QGraphicsPixmapItem> enemy_attack;
    std::unique_ptr<QGraphicsPixmapItem> enemy_fire;

    std::unique_ptr<QSoundEffect> fireSound;
    std::unique_ptr<QSoundEffect> walkSound;

    void hideAllPixels();

public:
    XEnemyPixel(QPoint gameCoords, int strength);

public slots:
    void onDead() override;
    void onMove(int x, int y);
    void onAttack();
    void nextFrame();
    void walkChanged(bool walking);

};

#endif
