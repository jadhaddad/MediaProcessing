#ifndef TILEVISUALISATIONMANAGER_H
#define TILEVISUALISATIONMANAGER_H

#include <QObject>
#include <world.h>


class GraphicalRepresentation;

class TileVisualisationManager : public QObject
{
    Q_OBJECT  
public:
    explicit TileVisualisationManager(int cols, int rows,
                                      const std::vector<std::unique_ptr<Tile>> &tiles,
                                      GraphicalRepresentation *visualisation,
                                      QObject *parent = nullptr);
    ~TileVisualisationManager();
    /**
     * @brief MAX_TILES Maximum tiles drawn at once
     */
    static int MAX_TILES;

private:
    std::vector<bool> tileDrawn;
    const std::vector<std::unique_ptr<Tile>> &tiles;
    GraphicalRepresentation *visualisation;
    int drawRadius = 50;

    int cols, rows;
    int x_protagonist, y_protagonist;
    bool enabled = true;

    /**
     * @brief checkTiles Count number of tiles drawn. Clear if above max tiles
     */
    void checkTiles();
    void clearTiles();

public slots:
    /**
     * @brief protagonistMoved
     * Find the tiles in range of drawRadius, keeps track of it, and send it to visualisation to draw it
     */
    void protagonistMoved(int x_protagonist, int y_protagonist);
    void zoomChanged(float zoom);

};

#endif // TILEVISUALISATIONMANAGER_H
