#include <algorithm>
#include <iostream>

#include "tilevisualisationmanager.h"
#include "graphicalrepresentation.h"

static int MAX_RADIUS = 200;    // max radius
int TileVisualisationManager::MAX_TILES = 50000;

TileVisualisationManager::TileVisualisationManager(int cols, int rows,
                                                   const std::vector<std::unique_ptr<Tile>> &tiles,
                                                   GraphicalRepresentation *visualisation,
                                                   QObject *parent) :
    QObject{parent}, tiles{tiles}, visualisation{visualisation}, cols{cols}, rows{rows}
{
    tileDrawn = std::vector<bool> (tiles.size(), false);
}

TileVisualisationManager::~TileVisualisationManager()
{
    tileDrawn.clear();
}

void TileVisualisationManager::checkTiles()
{
    if (tileDrawn.empty()) return;

    int count = std::count(tileDrawn.begin(), tileDrawn.end(), true);

    if (count >= MAX_TILES)
    {
        std::cout << "Max tiles reached, clearing." << std::endl;
        clearTiles();
    }
}

void TileVisualisationManager::clearTiles()
{
    std::for_each(tileDrawn.begin(), tileDrawn.end(), [](auto &&drawn)
    {
        drawn = false;
    });

    visualisation->clearMapTiles();
}

void TileVisualisationManager::protagonistMoved(int x_protagonist, int y_protagonist)
{
    if (!enabled) return;   // don't draw when not enabled
    checkTiles();

    this->x_protagonist = x_protagonist;
    this->y_protagonist = y_protagonist;

    int limit = std::min(cols, rows);
    if (drawRadius > limit)
        drawRadius = limit;

    int x_start = (x_protagonist - drawRadius / 2 > 0)?
                ((x_protagonist + drawRadius / 2 < cols)?
                     x_protagonist - drawRadius / 2 :    // protagonist in middle of world
                     cols - drawRadius)  // protagonist at the end
              : 0;  // protagonist at the start

    int y_start = (y_protagonist - drawRadius / 2 > 0)?
                ((y_protagonist + drawRadius / 2 < rows)?
                     y_protagonist - drawRadius / 2 :
                     rows - drawRadius)
              : 0;

    for (int i = 0; i < drawRadius * drawRadius; i++)
    {
        int x = x_start + i % drawRadius;
        int y = y_start + i / drawRadius;
        int pos = y * cols + x;

        try
        {
            if (!tileDrawn.at(pos))
            {
                auto &tile = tiles.at(pos);
                visualisation->drawMapTile(tile);
                tileDrawn.at(pos) = true;
            }
        }
        catch (...)
        {
            break;
        }
    }
}

void TileVisualisationManager::zoomChanged(float zoom)
{
    drawRadius = 50 / zoom;

    if (drawRadius > MAX_RADIUS) drawRadius = MAX_RADIUS;

    if (zoom < 0.2f) // zoomed out, just show background
    {
        enabled = false;
        clearTiles();
    }
    else
    {
        enabled = true;
        protagonistMoved(x_protagonist, y_protagonist);
    }
}
