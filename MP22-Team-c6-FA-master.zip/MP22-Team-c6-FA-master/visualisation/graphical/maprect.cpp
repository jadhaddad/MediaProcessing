#include "maprect.h"

#include <QBrush>
#include <QColor>

MapRect::MapRect(QPoint gameCoor, float value)
    : QGraphicsRectItem(gameCoor.x() * 50, gameCoor.y() * 50, 50, 50),
      gameCoor{gameCoor}, value{value}
{
    setZValue(1.1);
    QColor color = value == std::numeric_limits<float>::infinity()?
                QColor(0,0,0) : getGreen(value);
    setBrush(QBrush(color));
}

void MapRect::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
    {
        emit tileClicked(gameCoor, value);
    }
}

QColor MapRect::getGreen(float value)
{
    QColor green = Qt::green;
    green.setGreenF(value);
    return green;
}
