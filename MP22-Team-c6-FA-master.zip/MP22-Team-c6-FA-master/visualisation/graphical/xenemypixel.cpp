#include "xenemypixel.h"


void XEnemyPixel::hideAllPixels()
{
    enemy_idle->setVisible(false);
    std::for_each(enemy_walking.begin(), enemy_walking.end(), [](auto &n)
    {
        n->setVisible(false);
        n->resetTransform();
    });
    enemy_attack->setVisible(false);
    enemy_fire->setVisible(false);
    enemy_dead->setVisible(false);
}

XEnemyPixel::XEnemyPixel(QPoint gameCoords, int strength):
    EnemyPixel(gameCoords, strength, ":/images/charizard/charizard_idle.png", ":/images/charizard/charizard_dead.png", ":/soundeffects/charizard/charizard_dead.wav")
{
    enemy_walking.reserve(4);
    enemy_walking.emplace_back(std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/charizard/charizard_walking_1.png"), this));
    enemy_walking.emplace_back(std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/charizard/charizard_walking_2.png"), this));
    enemy_walking.emplace_back(std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/charizard/charizard_walking_3.png"), this));
    enemy_walking.emplace_back(std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/charizard/charizard_walking_4.png"), this));
    std::for_each(enemy_walking.begin(), enemy_walking.end(), [](auto &n) {  n->setVisible(false); });

    enemy_attack = std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/charizard/charizard_attack.png"), this);
    enemy_attack->setVisible(false);

    enemy_fire = std::make_unique<QGraphicsPixmapItem>(QPixmap(":/images/charizard/charizard_fire.png"),this);
    enemy_fire->setVisible(false);
    enemy_fire->setPos(0, -50);    // fire above xenemy

    deadSound->setVolume(0.5f);

    fireSound = std::make_unique<QSoundEffect>(this);
    fireSound->setSource(QUrl::fromLocalFile(":/soundeffects/charizard/charizard_fire.wav"));
    fireSound->setVolume(0.2f);

    walkSound = std::make_unique<QSoundEffect>(this);
    walkSound->setSource(QUrl::fromLocalFile(":/soundeffects/charizard/charizard_walk.wav"));
    walkSound->setVolume(0.1f);
}

void XEnemyPixel::onDead() {
    defeated = true;
    fireSpread = -1;
    walking = -1;

    fireSound->stop();
    walkSound->stop();
}

void XEnemyPixel::onMove(int x, int y)
{
    if (!defeated)
    {
        if (x > gameCoords.x()) // going right
            walkingLeft = false;
        else
            walkingLeft = true;

        gameCoords = QPoint(x, y);
        this->setPos(gameCoords * 50);
        walking = 0;
    }
}

void XEnemyPixel::onAttack()
{
    if (!defeated) fireSpread = 0;
    fireSound->play();
}

void XEnemyPixel::nextFrame()
{
    if (!defeated)
    {
        hideAllPixels();

        if (fireSpread != -1)
        {
            enemy_attack->setVisible(true);
            enemy_fire->setVisible(true);

            fireSpread++;
            if (fireSpread > 31)    // 8 game cycles
            {
                fireSpread = -1;
                fireSound->stop();
            }
        }
        else if (walking != -1)
        {
            enemy_walking.at(walking)->setVisible(true);

            if (walkingLeft)
            {
                QTransform transform;
                transform.scale(-1, 1);
                transform.translate(-50, 0);
                enemy_walking.at(walking)->setTransform(transform);
            }

            walking++;
            if (walking > 3)
                walking = -1;
        }
        else
            enemy_idle->setVisible(true);
    }
    else
    {
        healthLabel->setVisible(false);
        hideAllPixels();
        enemy_dead->setVisible(true);
        disconnect(sender(), 0, this, 0);
    }

}

void XEnemyPixel::walkChanged(bool walking)
{
    if (walking)
        walkSound->play();
    else
        walkSound->stop();
}
