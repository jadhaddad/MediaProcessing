Kshitiz Bhattrai, Jad Haddad, Yonathan Irawan

# Team C-6 Final Assignment Media Processing

This is the final assignment of team C6 for Media Processing. The project is themed after the game Pokémon. Here you play as the protagonist, Pikachu and fight against enemies such as Meowth (Enemy), Koffing (PEnemy), and Charizard (XEnemy).

## UML

![UML diagram of the project](UML.png "UML diagram of the project")

Above is the UML that is generated from the code.

## Features

Below are the features implemented from the requirements:

- Graphical representation
    
    - Animation on protagonist idle, movement, attack, heal, poisoned, 
    fire, and dying
    
    - Enemy idle and dying animation
    
    - PEnemy idle, poisoning, and dying animation
    
    - XEnemy idle, flying, attacking, and dying animation.

- Text representation
    
    - Displays the whole world in a grid
    
    - Shows the protagonist effetcs (poison, fire, and death).

- Movement using arrows (or WASD) and on click for pathfinding

    - Shows the path in graphical representation.

- Terminal that can be oppened or closed
    
    - Move using up, right, down, left; can also put number of steps
    
    - Go to x and y
    
    - Attack nearest enemy with the option of only attacking enemies the protagonist can defeat
    
    - Consume nearest health pack, or the best health pack
    
    - Help, with possibility on a specific command
    
    - Clear
    
    - Exit to close the terminal.

- Autoplay mode
    
    - Each turn, the protagonist takes the next best move to try and complete the game
    
    - The protagonist attacks the strongest enemy first
    
    - The protagonist finds the best health pack each time, i.e. the health pack that replenish the health closest to 100.

- Show protagonist's health and energy.

- Setting the zoom, animation speed, and heuristic weight of the pathfinder.

- PEnemy

    - When triggered, poisons the surround tiles (radius 3)
    
    - Shown by a cloud
    
    - Protagonist turns pink in graphical view when poisoned.

- XEnemy

    - Moves around randomly while also shoots fire above

    - Protagonist gets damaged and shown on fire.

- Switches easily to a new world.

Below are the extra features:

- An open world dialog

    - Shows the default world maps

    - Open another image using file dialog

    - Configure number of enemies and health packs with a spinner.

- Sound effects for each actor.

- Shortcuts
    
    - Ctrl-T to open terminal
    
    - Ctrl-O to open a new world

    - Ctrl-S to open the settings.

- God mode

    - No energy and health change.
    
- Centre the screen on the protagonist or move around the map.

## Known Issues

- The text representation is slow with large maps as it is showing the whole world. To improve performance, there is a button to disable the text update.

- The protagonist may not be centred on screen while on text representation mode. Use the move map feature. 