#include "visualisation/visualisation.h"
#include "controller/controller.h"
#include "model/gameengine.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Visualisation w;
    GameEngine g(&w);
    Controller c(&g);

    a.installEventFilter(&w);

    // connect signal and slots
    w.connect(&w, SIGNAL(file_name_entered(QString,int,int)), &c, SLOT(openFile(QString,int,int)));
    w.connect(&w, SIGNAL(switchMode(bool)), &c, SLOT(switchControllerMode(bool)));
    w.connect(&w, SIGNAL(command_entered(QString)), &c, SLOT(commandLine(QString)));
    w.connect(&w, SIGNAL(autoComplete(QString)),&c, SLOT(autoComplete(QString)));
    w.connect(&w, SIGNAL(onWeightChange(float)),&c, SLOT(changeWeight(float)));

    w.connect(&w, SIGNAL(onGodMode(bool)),&g, SLOT(godModeEnergy(bool)));
    w.connect(&w, SIGNAL(onRefreshRateUpdate(int)), &g, SLOT(changeRefreshRate(int)));

    c.connect(&c, SIGNAL(appendHistory(QString,bool)), &w, SLOT(appendHistory(QString,bool)));
    c.connect(&c, SIGNAL(clearHistory()), &w, SLOT(clearHistory()));
    c.connect(&c, SIGNAL(closeTerminal()), &w, SLOT(closeTerminal()));
    c.connect(&c, SIGNAL(setCommand(QString)), &w, SLOT(setCommand(QString)));
    c.connect(&c, SIGNAL(exitAutoMode(bool)), &w, SLOT(switchControllerMode(bool)));

    c.connect(&g, SIGNAL(moveDone()), &c, SLOT(nextMove()));

    w.show();
    return a.exec();
}
