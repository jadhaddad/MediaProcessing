#include "coursepart.h"
#include <numeric>

CoursePart::CoursePart(const std::string cCode, const std::string cName, const int sem, const int cu, int groups, int cr):
  code{cCode}, name{cName}, semester{sem}, cuGroup{cu}, nrOfGroups{groups}, credits{cr}

{

}

const std::string &CoursePart::getCode() const
{
  return code;
}

const std::string &CoursePart::getName() const
{
  return name;
}

int CoursePart::getSemester() const
{
  return semester;
}

int CoursePart::getCuGroup() const
{
  return cuGroup;
}

int CoursePart::getNrOfGroups() const
{
  return nrOfGroups;
}

void CoursePart::setNrOfGroups(int newNrOfGroups)
{
  nrOfGroups = newNrOfGroups;
}

int CoursePart::getCredits() const
{
  return credits;
}

bool CoursePart::addCooperator(std::string name, unsigned int cu) // dit moet dan Cooperator object worden ipv naam
{
  if (cu % cuGroup == 0)
    {
    auto [it, res] = cooperators.insert_or_assign(name, std::make_pair(cu, cu/cuGroup));
    return res;
    }
  throw std::logic_error("wrong number of contact hours for " + name + " : " + std::to_string(cu));

}

bool CoursePart::removeCooperator(std::string name)
{
  return cooperators.erase(name) != 0;
}

bool CoursePart::checkComplete()
{
  return std::accumulate(cooperators.begin(), cooperators.end(), 0, [](int sum, auto & cp){return sum + cp.second.second;}) == nrOfGroups;
}

const std::map<std::string, std::pair<unsigned int, unsigned int> > &CoursePart::getCooperators() const
{
  return cooperators;
}

std::ostream & operator<<(std::ostream & os, const std::unique_ptr<CoursePart> & cp)
{
  os << "Info for " << cp->getCode() << " : " << cp->getName() << std::endl;
  os << "Contact hours/group : " << cp->getCuGroup() << " - #groups : " << cp->getNrOfGroups() << std::endl;
  os << "Currently assigned cooperators" << std::endl;
  for (auto const& [key, val] : cp->getCooperators())
    {
      os << "\t" << key << " : " << val.second << " groups" << std::endl;
    }
}
