#include <iostream>
#include <fstream>
#include "owo_system.h"
#include "coursepart.h"
int main()
{
  std::ofstream result{"result1.txt"};
  OWO_system test{"Ba 1 IIW", 60};
  test.importCourses("courseinfo");
  test.getProgramName();
  result << "Program complete ? " << std::boolalpha << test.checkCredits() << std::endl;
  try {
    auto & ola = test.getCoursePart("T1pCD1");
    ola->addCooperator("Jeroen Wauters", 36);
    ola->addCooperator("Ruben Vanhoof", 72);
    result << std::boolalpha << ola->checkComplete() << std::endl;
    result << ola;
    ola->addCooperator("Nigel Vinckier", 36);
    ola->addCooperator("Stef Desmet", 36);
    result << std::boolalpha << ola->checkComplete() << std::endl;
    result << ola;
    ola->removeCooperator("Ruben Vanhoof");
    result << std::boolalpha << ola->checkComplete() << std::endl;
    result << ola;
    }
  catch (std::logic_error& e)
  {
    result << e.what() << std::endl;
  }
  try
  {
    auto & ola = test.getCoursePart("T1oWB1");
    ola->addCooperator("Nigel Vinckier", 24);
    ola->addCooperator("Karen Vanderloock", 52);
    result << std::boolalpha << ola->checkComplete() << std::endl;
    result << ola;
  }
  catch (std::logic_error& e)
  {
    result << e.what() << std::endl;
  }
  test.addCoursePart("T1pIB1", "Ingenieursbeleving 1", 12, 24, 5);
  result << "Program complete ? " << std::boolalpha << test.checkCredits() << std::endl;
  result.close();
  //will only work if more is a valid command...
  system("more result1.txt");
}

