# Fix errors (owo_start)
- Basic shit
- Don't forget to copy input file to build folder.
- Credits for EE1 is 9 as want 60 total credits.

# Add Cooperator (owo_second)
- For `Cooperator::checkLoad()`, check for each semester and add using `std::accumulate()`.

```C++
bool Cooperator::checkLoad()
{
    std::set<unsigned int> semesters({1, 2});

    for (auto semester : semesters)
    {
        unsigned int sum = std::accumulate(assignedCourses.begin(), assignedCourses.end(), 0,
                                  [&semester] (unsigned int sum, auto & course)
        {
            auto courseSemester = std::get<2> (course);

            if (semester == courseSemester)
                return sum + std::get<1> (course);
            else if (courseSemester == 12)
                return sum + (std::get<1> (course) / 2);    // full year course divide by 2
            else
                return sum;
        });

        if (sum > MAX_HOURS) return false;
    }

    return true;
}
```

- In `Cooperator::addCourse()`, check with `checkLoad()`. If it return false, remove the course again.

# Types of Cooperators (owo_third)

- `Assistant`, `ATPO`, `ZAP` is a subclass of `Cooperator`.
- `Cooperator::checkLoad()` & `Cooperator::showInfo()` becomes virtual.
- `checkLoad()` uses protected variable `hoursPerSemester` set by subclasses as limit.
- `ATPO` and `ZAP` has own implementation of `showInfo()`. Calls `Cooperator::showInfo()` and then add their own fields.

# Multithreading
- The lines in `CoursePart::addCooperator()` can be mutex locked:

```C++
coop->addCourse(code, cu, semester);
if (coop->checkLoad())  // enough space
{
    auto [it, res] = cooperators.insert_or_assign(coop->getName(), std::make_pair(cu, cu/cuGroup));
    return res;
}
```

- These are the critical lines where you check if the load is enough and adding the course to the cooporator.