#ifndef COOPERATOR_H
#define COOPERATOR_H

#include <string>
#include <memory>
#include <vector>

class Cooperator
{
public:
    static unsigned int MAX_HOURS;

    Cooperator(const std::string coopName, const std::string coopUnr, char cat);

    void addCourse(std::string cCode, unsigned int cu, unsigned int sem);
    void removeCourse(std::string cCode);
    bool checkLoad();
    std::string showInfo();

    const std::string &getName() const;

private:
    std::string name;
    std::string u_nr;
    char category;
    std::vector<std::tuple<std::string, unsigned int, unsigned int>> assignedCourses;
};

#endif // COOPERATOR_H
