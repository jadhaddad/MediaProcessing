#include <iostream>
#include <fstream>
#include "owo_system.h"
#include "coursepart.h"
#include "cooperator.h"

/*
int main()
{
  std::ofstream result{"result1.txt"};
  OWO_system test{"Ba 1 IIW", 60};
  test.importCourses("courseinfo");
  test.getProgramName();
  result << "Program complete ? " << std::boolalpha << test.checkCredits() << std::endl;
  try {
    auto & ola = test.getCoursePart("T1pCD1");
    ola->addCooperator("Jeroen Wauters", 36);
    ola->addCooperator("Ruben Vanhoof", 72);
    result << std::boolalpha << ola->checkComplete() << std::endl;
    result << ola;
    ola->addCooperator("Nigel Vinckier", 36);
    ola->addCooperator("Stef Desmet", 36);
    result << std::boolalpha << ola->checkComplete() << std::endl;
    result << ola;
    ola->removeCooperator("Ruben Vanhoof");
    result << std::boolalpha << ola->checkComplete() << std::endl;
    result << ola;
    }
  catch (std::logic_error& e)
  {
    result << e.what() << std::endl;
  }
  try
  {
    auto & ola = test.getCoursePart("T1oWB1");
    ola->addCooperator("Nigel Vinckier", 24);
    ola->addCooperator("Karen Vanderloock", 52);
    result << std::boolalpha << ola->checkComplete() << std::endl;
    result << ola;
  }
  catch (std::logic_error& e)
  {
    result << e.what() << std::endl;
  }
  test.addCoursePart("T1pIB1", "Ingenieursbeleving 1", 12, 24, 5, 9);
  result << "Program complete ? " << std::boolalpha << test.checkCredits() << std::endl;
  result.close();
  //will only work if more is a valid command...
  system("more result1.txt");
}
*/

int main()
{
  std::ofstream result{"result2.txt"};
  OWO_system test{"Ba 1 IIW", 60};
  test.importCourses("courseinfo");
  test.getProgramName();
  result << "Program complete ? " << std::boolalpha << test.checkCredits() << std::endl;
  auto jw = std::make_shared<Cooperator>("Jeroen Wauters", "u00112233", 'A');
  auto nv = std::make_shared<Cooperator>("Nigel Vinckier", "u00123456", 'A');
  auto rv = std::make_shared<Cooperator>("Ruben Vanhoof", "u00555555", 'A');
  auto sd = std::make_shared<Cooperator>("Stef Desmet", "u00111000", 'Z');
  auto kv = std::make_shared<Cooperator>("Karen Vanderloock", "u00112233", 'T');
  try {
    auto & ola = test.getCoursePart("T1pCD1");
    ola->addCooperator(jw, 36);
    ola->addCooperator(rv, 72);
    result << std::boolalpha << ola->checkComplete() << std::endl;
    result << ola;
    ola->addCooperator(nv, 36);
    ola->addCooperator(sd, 36);
    result << std::boolalpha << ola->checkComplete() << std::endl;
    result << ola;
    ola->removeCooperator(rv);
    result << std::boolalpha << ola->checkComplete() << std::endl;
    result << ola;
    }
  catch (std::logic_error& e)
  {
    result << e.what() << std::endl;
  }
  result << nv->showInfo();
  try
  {
    auto & ola = test.getCoursePart("T1oWB1");
    ola->addCooperator(nv, 24);
    ola->addCooperator(kv, 52);
    result << std::boolalpha << ola->checkComplete() << std::endl;
    result << ola;
  }
  catch (std::logic_error& e)
  {
    result << e.what() << std::endl;
  }
  test.addCoursePart("T1pIB1", "Ingenieursbeleving 1", 12, 24, 5, 9);
  result << "Program complete ? " << std::boolalpha << test.checkCredits() << std::endl;
  try
  {
    auto & ola = test.getCoursePart("T1pIB1");
    if (ola->addCooperator(nv, 240))
        result << nv->getName() << " given extra " << 240 << " hours" << std::endl;
    if (ola->addCooperator(nv, 24))
        result << nv->getName() << " given extra " << 12 << " hours" << std::endl;
    result << std::boolalpha << ola->checkComplete() << std::endl;
    result << ola;
  }
  catch (std::logic_error& e)
  {
    result << e.what() << std::endl;
  }
  try
  {
    auto & ola = test.getCoursePart("T1pIB1");
    if (ola->addCooperator(kv, 48))
        result << kv->getName() << " given extra " << 48 << " hours" << std::endl;
    result << std::boolalpha << ola->checkComplete() << std::endl;
    result << ola;
  }
  catch (std::logic_error& e)
  {
    result << e.what() << std::endl;
  }
  result << nv->showInfo();
  result.close();
  system("more result2.txt");
}

/* main if part 3 is finished
int main()
{
  std::ofstream result{"result3.txt"};
  OWO_system test{"Ba 1 IIW", 60};
  test.importCourses("courseinfo");
  test.getProgramName();
  result << "Program complete ? " << std::boolalpha << test.checkCredits() << std::endl;
  auto jw = std::make_shared<Assistant>("Jeroen Wauters", "u00112233");
  auto nv = std::make_shared<Assistant>("Nigel Vinckier", "u00123456");
  auto rv = std::make_shared<Assistant>("Ruben Vanhoof", "u00555555");
  auto sd = std::make_shared<ZAP>("Stef Desmet", "u00111000", "associate professor");
  auto kv = std::make_shared<ATPO>("Karen Vanderloock", "u00112233");
  kv->addCoordTask("masters thesis coordinator");
  try {
    auto & ola = test.getCoursePart("T1pCD1");
    ola->addCooperator(jw, 36);
    ola->addCooperator(kv, 72);
    result << std::boolalpha << ola->checkComplete() << std::endl;
    result << ola;
    ola->addCooperator(nv, 36);
    ola->addCooperator(sd, 36);
    result << std::boolalpha << ola->checkComplete() << std::endl;
    result << ola;
    ola->removeCooperator(rv);
    result << std::boolalpha << ola->checkComplete() << std::endl;
    result << ola;
    }
  catch (std::logic_error& e)
  {
    result << e.what() << std::endl;
  }
  result << nv->showInfo();
  try
  {
    auto & ola = test.getCoursePart("T1oWB1");
    ola->addCooperator(nv, 24);
    ola->addCooperator(kv, 120);
    result << std::boolalpha << ola->checkComplete() << std::endl;
    result << ola;
  }
  catch (std::logic_error& e)
  {
    result << e.what() << std::endl;
  }
  test.addCoursePart("T1pIB1", "Ingenieursbeleving 1", 12, 24, 5, 9);
  result << "Program complete ? " << std::boolalpha << test.checkCredits() << std::endl;
  try
  {
    auto & ola = test.getCoursePart("T1pIB1");
    if (ola->addCooperator(nv, 240))
        result << nv->getName() << " given extra " << 240 << " hours" << std::endl;
    if (ola->addCooperator(nv, 24))
        result << nv->getName() << " given extra " << 12 << " hours" << std::endl;
    result << std::boolalpha << ola->checkComplete() << std::endl;
    result << ola;
  }
  catch (std::logic_error& e)
  {
    result << e.what() << std::endl;
  }
  try
  {
    auto & ola = test.getCoursePart("T1pIB1");
    if (ola->addCooperator(kv, 48))
        result << kv->getName() << " given extra " << 48 << " hours" << std::endl;
    result << std::boolalpha << ola->checkComplete() << std::endl;
    result << ola;
  }
  catch (std::logic_error& e)
  {
    result << e.what() << std::endl;
  }
  result << nv->showInfo();
  result << kv->showInfo();
}
*/
