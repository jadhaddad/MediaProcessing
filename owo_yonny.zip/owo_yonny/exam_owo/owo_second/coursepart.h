#ifndef COURSEPART_H
#define COURSEPART_H
#include <string>
#include <map>
#include <memory>
#include <iostream>

class Cooperator;

class CoursePart
{
public:
  CoursePart(const std::string cCode, const std::string cName, const int sem, const int cu, int groups, int cr);

  const std::string &getCode() const;

  const std::string &getName() const;

  int getSemester() const;

  int getCuGroup() const;

  int getNrOfGroups() const;
  void setNrOfGroups(int newNrOfGroups);

  int getCredits() const;
  bool addCooperator(std::shared_ptr<Cooperator> coop, unsigned int cu);
  bool removeCooperator(std::shared_ptr<Cooperator> coop);
  bool checkComplete();

  const std::map<std::string, std::pair<unsigned int, unsigned int> > &getCooperators() const;

private:
  const std::string code;
  const std::string name;
  const int semester;
  const int cuGroup;
  int nrOfGroups;
  const int credits;
  std::map<std::string, std::pair<unsigned int, unsigned int>> cooperators;
};

std::ostream & operator<<(std::ostream & os, const std::unique_ptr<CoursePart> & cp);

#endif // COURSEPART_H
