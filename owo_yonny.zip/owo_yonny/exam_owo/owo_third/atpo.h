#ifndef ATPO_H
#define ATPO_H

#include "cooperator.h"

class ATPO : public Cooperator
{

public:
    ATPO(const std::string coopName, const std::string coopUnr);
    void addCoordTask(const std::string);
    virtual std::string showInfo() const;

private:
    std::vector<std::string> coorTasks;
};

#endif // ATPO_H
