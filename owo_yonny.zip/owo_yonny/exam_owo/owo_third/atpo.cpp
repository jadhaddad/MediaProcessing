#include "atpo.h"
#include <sstream>

ATPO::ATPO(const std::string coopName, const std::string coopUnr)
    : Cooperator(std::move(coopName), std::move(coopUnr), 180)
{

}

void ATPO::addCoordTask(const std::string task)
{
    coorTasks.push_back(std::move(task));
}

std::string ATPO::showInfo() const
{
    std::stringstream ss;
    ss << Cooperator::showInfo()
       << "Coordination tasks: "
       << std::endl;

    for (const auto & task : coorTasks)
        ss << "\t" << task << std::endl;

    return ss.str();
}
