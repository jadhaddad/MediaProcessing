#ifndef ASSISTANT_H
#define ASSISTANT_H

#include "cooperator.h"

class Assistant : public Cooperator
{
public:
    Assistant(const std::string coopName, const std::string coopUnr);
};

#endif // ASSISTANT_H
