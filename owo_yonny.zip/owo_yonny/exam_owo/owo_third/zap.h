#ifndef ZAP_H
#define ZAP_H

#include "cooperator.h"

class ZAP : public Cooperator
{
public:
    ZAP(const std::string coopName, const std::string coopUnr, const std::string title);
    void addResearchDomains(const std::string research);

    virtual bool checkLoad() const;
    virtual std::string showInfo() const;

private:
    std::string title;
    std::vector<std::string> researchDomains;
};

#endif // ZAP_H
