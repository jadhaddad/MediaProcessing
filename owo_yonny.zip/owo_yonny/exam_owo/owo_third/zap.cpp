#include "zap.h"
#include <numeric>
#include <sstream>
#include <set>
#include <ranges>

ZAP::ZAP(const std::string coopName, const std::string coopUnr, const std::string title)
    : Cooperator(std::move(coopName), std::move(coopUnr), 2),   // 2 courses max
      title{std::move(title)}
{

}

void ZAP::addResearchDomains(const std::string research)
{
    researchDomains.push_back(std::move(research));
}

bool ZAP::checkLoad() const
{
    std::set<unsigned int> semesters({1, 2}); 

    for (auto &semester : semesters)
        {
        unsigned int sum = std::accumulate(assignedCourses.begin(), assignedCourses.end(), 0,
                                  [&semester] (unsigned int sum, auto & course)
        {
            auto courseSemester = std::get<2> (course);

            if (semester == courseSemester ||
                    courseSemester == 12)
                return sum + 1;
            else
                return sum;
        });

        if (sum > hoursPerSemester) return false;
    }

    return true;
}

std::string ZAP::showInfo() const
{
    std::stringstream ss;
    ss << Cooperator::showInfo()
       << " with title " << title
       << " and research domains on: "
       << std::endl;

    for (const auto & research : researchDomains)
        ss << "\t" << research << std::endl;

    return ss.str();
}
