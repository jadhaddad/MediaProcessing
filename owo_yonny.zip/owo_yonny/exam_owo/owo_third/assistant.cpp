#include "assistant.h"

Assistant::Assistant(const std::string coopName, const std::string coopUnr)
    : Cooperator(std::move(coopName), std::move(coopUnr), 240)
{

}
