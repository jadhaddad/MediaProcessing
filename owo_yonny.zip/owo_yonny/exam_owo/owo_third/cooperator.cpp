#include "cooperator.h"
#include <numeric>
#include <set>
#include <sstream>
#include <ranges>
#include <iostream>
#include <algorithm>

Cooperator::Cooperator(const std::string coopName, const std::string coopUnr, unsigned int hours)
    : hoursPerSemester{hours}, name{std::move(coopName)}, u_nr{std::move(coopUnr)}
{

}

void Cooperator::addCourse(std::string cCode, unsigned int cu, unsigned int sem)
{
    assignedCourses.emplace_back(std::make_tuple(std::move(cCode), cu, sem));
    if (!checkLoad())
    {
        assignedCourses.pop_back(); // cancel
        throw std::logic_error(name + " has already too much courses");
    }
}

void Cooperator::removeCourse(std::string cCode)
{
    auto iter = std::find_if(assignedCourses.begin(), assignedCourses.end(),
                               [&cCode] (auto & course)
    {
        return std::get<0> (course) == cCode;
    });

    if (iter != assignedCourses.end())
    {
        assignedCourses.erase(iter);
    }
}

bool Cooperator::checkLoad() const
{
    std::set<unsigned int> semesters({ 1, 2 });

    for (auto &semester : semesters)
        {
        unsigned int sum = std::accumulate(assignedCourses.begin(), assignedCourses.end(), 0,
                                  [&semester] (unsigned int sum, auto & course)
        {
            auto courseSemester = std::get<2> (course);

            if (semester == courseSemester)
                return sum + std::get<1> (course);
            else if (courseSemester == 12)
                return sum + (std::get<1> (course) / 2);
            else
                return sum;
        });

        if (sum > hoursPerSemester) return false;
    }

    return true;
}

std::string Cooperator::showInfo() const
{
    std::stringstream ss;
    ss << name << "(" << u_nr << ")" << std::endl;
    for (auto & course : assignedCourses)
    {
        ss << "\t"
           << std::get<0> (course) << " : "
           << std::get<1> (course) << " "
           << "(" << std::get<2> (course) << ")"
           << std::endl;
    }

    return ss.str();
}

const std::string &Cooperator::getName() const
{
    return name;
}

