#ifndef COOPERATOR_H
#define COOPERATOR_H

#include <string>
#include <memory>
#include <vector>

class Cooperator
{
public:
    Cooperator(const std::string coopName, const std::string coopUnr, unsigned int hoursPerSemester);

    void addCourse(std::string cCode, unsigned int cu, unsigned int sem);
    void removeCourse(std::string cCode);
    virtual bool checkLoad() const;
    virtual std::string showInfo() const;

    const std::string &getName() const;

protected:
    unsigned int hoursPerSemester;  // used also for courses
    std::vector<std::tuple<std::string, unsigned int, unsigned int>> assignedCourses;

private:
    std::string name;
    std::string u_nr;
    char category;
};

#endif // COOPERATOR_H
