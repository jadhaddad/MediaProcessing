#include "owo_system.h"
#include "coursepart.h"

#include <fstream>
#include <sstream>
#include <charconv>
#include <numeric>

OWO_system::OWO_system(std::string name, const int credits):
  programName{name}, nrOfCredits{credits}
{

}

int OWO_system::convert_helper(std::vector<std::string> & data, int index, std::string err_message)
{
  int result;
  auto res = std::from_chars(data[index].data(), data[index].data() + data[index].size(), result);
  if (res.ec != std::errc())
    throw std::logic_error("wrong " + err_message + " data in file");
  return result;
}

bool OWO_system::importCourses(std::string fileName)
{
  {
    std::ifstream infoFile(fileName);
    std::string csvLine;
    if (!infoFile.is_open())
      throw std::logic_error(std::string("file " + fileName + " not found (most likely)" ));
    while (!infoFile.eof())
      {
        if (!infoFile.fail())
          {
            std::getline(infoFile, csvLine);
            std::stringstream ss( csvLine);
            std::vector<std::string> data;

            while( ss.good() )
            {
                std::string substr;
                std::getline( ss, substr, ',' );
                data.push_back( substr );
            }
            if (data.size() != 6)
              throw std::logic_error("wrong data in file");
            std::string courseCode = data[0];
            std::string courseName = data[1];
            int sem, cuPerGroup, nrOfGroups, credits;
            try
            {
              sem = convert_helper(data, 2, "semester");
              cuPerGroup = convert_helper(data, 3, "contact hours per group");
              nrOfGroups = convert_helper(data, 4, "number of groups");
              credits = convert_helper(data, 5, "credits");
            }
            catch (std::logic_error & e)
            {
              throw e;
            }
            addCoursePart(courseCode, courseName, sem, cuPerGroup, nrOfGroups, credits);
          }
        else
          throw std::logic_error("error reading file - wrong data");
      }
    return true;
  }

}

const std::string &OWO_system::getProgramName() const
{
  return programName;
}

void OWO_system::setProgramName(const std::string &newProgramName)
{
  programName = newProgramName;
}

int OWO_system::getNrOfCredits() const
{
  return nrOfCredits;
}

//check if sum of all credits in courseParts equals the number of credits of the program
bool OWO_system::checkCredits() const
{
  return std::accumulate(courseParts.begin(), courseParts.end(), 0, [](int sum, auto & cp){return sum + cp.second->getCredits();}) == nrOfCredits;
}

std::unique_ptr<CoursePart> &OWO_system::getCoursePart(std::string courseCode)
{
  auto res = courseParts.find(courseCode);
  if (res != courseParts.end())
    return res->second;
  throw std::logic_error(courseCode + " not found in system");
}

void OWO_system::addCoursePart(std::string cCode, std::string cName, int sem, int cu, int groups, int cr)
{
  auto cp = std::make_unique<CoursePart>(cCode, cName, sem, cu, groups, cr);
  courseParts[cCode] = std::move(cp);
}
